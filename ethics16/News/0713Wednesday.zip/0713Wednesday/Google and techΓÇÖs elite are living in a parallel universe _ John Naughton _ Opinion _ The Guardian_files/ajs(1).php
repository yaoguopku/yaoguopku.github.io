(function(){
var s = "<"+"script src=\"//www.googletagservices.com/tag/js/gpt.js\">\n";
s += "  googletag.pubads().definePassback( \"/59666047/theguardian.com/x-passback/criteo\", [300, 600])\n";
s += "  .setTargeting(\"slot\", [\"right\"])\n";
s += "  .setTargeting(\"passback\", \"criteo\")\n";
s += "  .setTargeting(\"ab\", \"\")\n";
s += "  .setTargeting(\"hb_bidder\", \"\")\n";
s += "  .setClickUrl(\"%%CLICK_URL_UNESC%%\")\n";
s += "  .display();\n";
s += "<"+"/script>\n";
s += "<"+"div id=\'beacon_79643d53bc\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'>\n";
s += "<"+"img width=\"0\" height=\"0\" src=\"https://cat.sv.us.criteo.com/delivery/lg.php?cppv=1&cpp=UV6U3HxHWDNPRTNva083TVZrWm1kWlNTbW9UUjgrTEJoYWxYWFNhZ3JmcnhRUC9NM3U5NHRFbkR6UmNwa0IxdXl5OUYvaFlFd0JxVndodlFuTlRibU9JNll2YVNlOWUrb25mODN6UFhlemszNWQ3YU5YUzhqOVRURGh2TVNHaGRoNWl3bkRZUGhTd2NmbjlBS2l1WjZpM3NZRVBhbThMYmpNYVdoUUgrTW0zb2ZmWUlRQ0p3cW0vM2dnRExqSEQxYWtMaXk4VmV3TzlCZ04vUDIyR3Q4VWVKOEx6RVZxRGFEdWZpRUVscm9hQzgvT2pjPXw%3D\"/>\n";
s += "<"+"/div>\n";
s += "\n";
document.write(s);})();
