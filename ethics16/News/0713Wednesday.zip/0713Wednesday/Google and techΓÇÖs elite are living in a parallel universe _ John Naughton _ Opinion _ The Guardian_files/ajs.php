(function(){
var s = "<"+"script src=\"//www.googletagservices.com/tag/js/gpt.js\">\n";
s += "  googletag.pubads().definePassback( \"/59666047/theguardian.com/x-passback/criteo\", [728,90])\n";
s += "  .setTargeting(\"slot\", [\"top\"])\n";
s += "  .setTargeting(\"passback\", \"criteo\")\n";
s += "  .setTargeting(\"ab\", \"\")\n";
s += "  .setTargeting(\"hb_bidder\", \"\")\n";
s += "  .setClickUrl(\"%%CLICK_URL_UNESC%%\")\n";
s += "  .display();\n";
s += "<"+"/script>\n";
s += "<"+"div id=\'beacon_acd5aa0161\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'>\n";
s += "<"+"img width=\"0\" height=\"0\" src=\"https://cat.sv.us.criteo.com/delivery/lg.php?cppv=1&cpp=pwRbXHwwUkF0VjF0bG1DSXdKNFNoN1pybW1JWXY5cXdxWkVlQnRJQm5TUS9US2RrbWFIR1ZZR0swSVhVRWJCZ3llZnJ5cVRFdFVUSitnV2x4Y1BIaUxFOHo3WDJCbHRXWk9hcnBXWU9DQXNlRnBDOHdoWmZ0aElrdFhINjZuQkJlckRUZFdydHlndGlCNzVwQkU4MkE2MHJReVpJTTF2RGVtSUwvOXJIaE93M2dhYkh0NWg2SE80U2JyRE9sT3NWQlBMbXZxb2lOeEdta3VRY2QvQXJ3bERPMGNLdjc1aVp2Y1dMWW0vY3BpcGFid3FBPXw%3D\"/>\n";
s += "<"+"/div>\n";
s += "\n";
document.write(s);})();
