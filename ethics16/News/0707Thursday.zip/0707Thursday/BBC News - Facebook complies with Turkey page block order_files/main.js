!function(t){"use strict";function e(){}function n(t){return new RegExp("(^|\\s+)"+t+"(\\s+|$)")}var r;e.prototype={constructor:e,debug:!1,trace:function(e){this.debug&&t.console&&t.console.log(e)},timerStart:function(){r=(new Date).getTime()},timerStop:function(){var t=(new Date).getTime()-r;this.trace("seconds elapsed: "+.001*t)},preloadImages:function(t){function e(){r++,r==t.length&&o(n)}for(var n=[],r=0,o=function(){},t="object"!=typeof t?[t]:t,a=0;a<t.length;a++)n[a]=new Image,n[a].onload=function(){e()},n[a].onerror=function(){e()},n[a].src=t[a];return{done:function(t){o=t||o}}},qs:function(t,e){return(e||document).querySelector(t)},qsa:function(t,e){return(e||document).querySelectorAll(t)},on:function(t,e,n,r){var o;o="string"==typeof t?qs(t):t,o.addEventListener(e,n,r||!1)},delegate:function(t,e,n,r){function o(n){var o=n.target,i=a.qsa(e,t),c=Array.prototype.indexOf.call(i,o)>=0;c&&r.call(o,n)}var a=this,i="blur"===n||"focus"===n;this.on(t,n,o,i)},parent:function(t,e){return t.parentNode?t.parentNode.tagName.toLowerCase()===e.toLowerCase()?t.parentNode:this.parent(t.parentNode,e):void 0},makeVar:function(t,e,n){var r;return r=n?t.replace(/-(.)|_(.)/g,function(t,e,n){var r="";return e&&(r+=e.charAt(0).toUpperCase()+e.substring(1,e.length)),n&&(r+=n.toUpperCase()),r}):t.replace(/-/g,"_"),e[r]=document.getElementById(t)},makeVars:function(t,e,n,r){for(var o=t.length,a;o--;)a=this.makeVar(t[o],e,r),n.push(a)},getAllIdElements:function(t){for(var e=t.getElementsByTagName("*"),n=[],r=e.length;r--;)e[r].hasAttribute("id")&&n.push(e[r]);return n},getAllIds:function(t,e,n){for(var r=t.getElementsByTagName("*"),o=[],a=r.length;a--;)if(r[a].hasAttribute("id")&&(o.push(r[a].id),e)){var i=n||"bu",c=r[a].id.replace(/-/g,"_");this.trace("var "+c+" = "+i+".qs('#"+r[a].id+"');")}return o},makeVarsFromIds:function(e,n,r,o){var a=this.getAllIds(e);this.makeVars(a,n||t,r||[],o)},recordStates:function(t){(!t||t.length<1)&&(t=this.getAllIdElements(document));for(var e=t.length;e--;)t[e].cl="",t[e].cl+=t[e].className},resetStates:function(t,e){(!t||t.length<1)&&(t=this.getAllIdElements(document));for(var n=t.length;n--;)t[n].cl?t[n].className=t[n].cl:this.trace("initial state not recorded for: "+t[n].id);if(e){var r=10*t.length;setTimeout(function(){e.apply()},r)}}},NodeList.prototype.forEach=Array.prototype.forEach;var o,a;t.addEventListener?(o=function(t,e,n){t.addEventListener(e,n,!1)},a=function(t,e,n){t.removeEventListener(e,n,!1)}):(o=function(e,n,r){e["e"+n+r]=r,e[n+r]=function(){e["e"+n+r](t.event)},e.attachEvent("on"+n,e[n+r])},a=function(t,e,n){t.detachEvent("on"+e,t[e+n]),t[e+n]=null}),e.prototype.addListener=o,e.prototype.removeListener=a;var i;i=t.stopPropagation?function(t){t.stopPropagation(),t.preventDefault()}:function(t){t.returnValue=!1,t.cancelBubble=!0},e.prototype.stopPropagation=i;var c;c=t.requestAnimationFrame?function(e){return t.requestAnimationFrame(e)}:t.webkitRequestAnimationFrame?function(e){return t.webkitRequestAnimationFrame(e)}:t.MozRequestAnimationFrame?function(e){return t.MozRequestAnimationFrame(e)}:function(e){return t.setTimeout(e,17)},e.prototype.requestFrame=c;var s;s=t.cancelAnimationFrame?function(e){return t.cancelAnimationFrame(e)}:t.webkitCancelAnimationFrame?function(e){return t.webkitCancelAnimationFrame(e)}:t.MozCancelAnimationFrame?function(e){return t.MozCancelAnimationFrame(e)}:function(e){return t.clearTimeout(e)},e.prototype.cancelFrame=s;var u;u=t.getComputedStyle?function(e){return t.getComputedStyle(e)}:function(t){return t.currentStyle},e.prototype.getStyle=u;var l,m,f;"classList"in document.documentElement?(l=function(t,e){return t.classList.contains(e)},m=function(t,e){t.classList.add(e)},f=function(t,e){t.classList.remove(e)}):(l=function(t,e){return n(e).test(t.className)},m=function(t,e){l(t,e)||(t.className=t.className+" "+e)},f=function(t,e){t.className=t.className.replace(n(e)," ")}),e.prototype.addClass=m,e.prototype.removeClass=f,e.prototype.hasClass=l,e.prototype.replaceClass=function(t,e,n){f(t,e),m(t,n)},t.BannerUtils=e}(window);
// @codekit-prepend "BannerUtils.min.js";

//init
function initAD() {
	if (!EB.isInitialized()) {
		EB.addEventListener(EBG.EventName.EB_INITIALIZED, startAd);
	} else {
		startAd();
	}
}

function startAd() {
	'use strict';

	var bu = new BannerUtils();
		bu.debug = false; // set this to false before final publishing

	var ad = bu.qs('#ad'),
		adSeen = false,
		delay,
		replay = bu.qs('#replay'),
		cover_line = bu.qs('#cover-line'),
		img = bu.qs('#img'),
		blue_wave = bu.qs('#blue-wave'),
		logo = bu.qs('#logo'),
		t1 = bu.qs('#t1'),
		t2 = bu.qs('#t2'),
		t3 = bu.qs('#t3'),
		cta = bu.qs('#cta'),
		tag_line = bu.qs('#tag-line'),
		f1 = bu.qs('#f1'),
		f2 = bu.qs('#f2'),
		f3 = bu.qs('#f3'),
		animated = [];

	function clickthrough() {
		EB.clickthrough();
	}

	function adClickThru() {
		ad.addEventListener('touchEnd', clickthrough, false);
		ad.addEventListener('click',    clickthrough, false);
		replay.addEventListener('mouseover', replayHover, false);
		replay.addEventListener('click',  adReset, false);
		replay.addEventListener('touchEnd', adReset, false);
	}

	function replayHover(e) {
		TweenLite.from(replay, 0.5,{rotation: -360});
	}
	function adReset() {

		if(adSeen){
			TweenLite.to(['.frame',replay], 0.5,{opacity:0});
			setTimeout(function(){
				clearTimeout(delay);
				TweenLite.set(animated,{clearProps:'all'}); // reset all tweened properties
				bu.resetStates(animated, frame0); // put back the original classes
			}, 500);
		} else {
			bu.recordStates(animated);
			frame0();
		}
	}

	function frame0() {
		adSeen = true;
		delay = setTimeout(frame1, 0);
	}

	function frame1() {
		TweenLite.to(f1, 0,{opacity: 1});
		TweenLite.to(cover_line, 1, {left: 728});
		animated.push(cover_line);
		delay = setTimeout(frame2, 1000);
	}

	function frame2() {
		TweenLite.to(f2, 0,{opacity: 1});
		TweenLite.to(img, 1, {opacity: 1, delay: 0.2});
		TweenLite.to(blue_wave, 1, {left: 400});
		TweenLite.to(logo, 1.2, {opacity: 1, delay:0.2});
		animated.push(img,blue_wave,logo);
		delay = setTimeout(frame3, 2000);
	}
	function frame3 () {
		var dealy =
		TweenLite.to(f3, 0,{opacity: 1});
		TweenLite.to(t1, 0.5, {opacity: 1, top: 25});
		TweenLite.to(cta, 0.5, {opacity: 1, top: 52});
		TweenLite.to(tag_line, 0.5, {opacity: 1, top: 65});

		TweenLite.to(t1, 0.5, {opacity: 0, delay:2.5});
		TweenLite.to(t2, 0.5, {opacity: 1, delay:3});

		TweenLite.to(t2, 0.5, {opacity: 0, delay: 5});
		TweenLite.to(t3, 0.5, {opacity: 1, delay: 5.5});

		TweenLite.to(replay, 0.5, {display: 'block', delay: 6});

		animated.push(t1, t2, t3, cta, tag_line, replay);
	}

	////////////////////////////////////////////////////// INIT //////////////////////////////////////////////////////

	adClickThru();
	adReset();
}

//run script
window.onload = initAD;
