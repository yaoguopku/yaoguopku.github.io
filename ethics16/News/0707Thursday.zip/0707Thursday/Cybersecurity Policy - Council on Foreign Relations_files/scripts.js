$('.submitbutton').click(function(e){
  $(this).attr("disabled", true);
  $(this).val('Submitting your request...');
  $(this).form.submit();
});

$('.closeme').click(function(e){
	e.preventDefault();
	self.close();

});

//cache original members count
var user_type_count=[];
user_type_count["all"]=jQuery("#user_type_count").text();
user_type_count["term"]=jQuery(".directory-member-term.directory-member-visible").length+"/"+jQuery(".directory-member-term").length;
user_type_count["member"]=jQuery(".directory-member-member.directory-member-visible").length+"/"+jQuery(".directory-member-member").length;

var handleUserTypes = function( userType ){
    if($("#filter>input[type=checkbox]").is(":checked")) {
      switch(userType) {
        case "all":
          $(".directory-member-visible").show();
          $(".directory-member-invisible").hide();
          $("#user_type_count").text(user_type_count["all"]);
          break;
        case "noterm":
          $(".spotlight").hide();
          $(".directory-member-visible.directory-member-member").show();
          $("#user_type_count").text(user_type_count["member"]);
          break;
        case "term":
          $(".spotlight").hide();
          $(".directory-member-visible.directory-member-term").show();
          $("#user_type_count").text(user_type_count["term"]);
          break;
      }
    }
    else {
      switch(userType) {
        case "all":
          $(".spotlight").show();
          $("#user_type_count").text(user_type_count[0]+" result"+(user_type_count[0]==1?"":"s"));
          $("#user_type_count").text(user_type_count["all"]);
          break;
        case "noterm":
          $(".directory-member-member").show();
          $(".directory-member-term").hide();
          $("#user_type_count").text(user_type_count[2]+"/"+user_type_count[0]+" result"+(user_type_count[2]==1?"":"s"));
          $("#user_type_count").text(user_type_count["member"]);
          break;
        case "term":
          $(".directory-member-member").hide();
          $(".directory-member-term").show();
          $("#user_type_count").text(user_type_count[1]+"/"+user_type_count[0]+" result"+(user_type_count[1]==1?"":"s"));
          $("#user_type_count").text(user_type_count["term"]);
          break;
      }
    }
};
var handleSharedProfiles = function( checked ){
    if(checked) {
      switch($('#filter>input[name=filter]:checked').val()) {
        case "term":
          $(".directory-member-invisible.directory-member-term").hide();
          break;
        case "noterm":
          $(".directory-member-invisible.directory-member-member").hide();
          break;
        case "all":
          $(".directory-member-visible").show();
          $(".directory-member-invisible").hide();
          break;
      }
    } else {
      switch($('#filter>input[name=filter]:checked').val()) {
        case "term":
          $(".directory-member-term").show();
          $(".directory-member-member").hide();
          break;
        case "noterm":
          $(".directory-member-term").hide();
          $(".directory-member-member").show();
          break;
        case "all":
          $(".spotlight").show();
          break;
      }
    }
};

/* find if member index not member search by whether checkbox "public" exists
 *   which only the former has
 */
if(jQuery("#public").length>0) {
  //page is members directory

  var filters = {
      userType : 'all',
      sharedProfiles : false
  };
  
  if( $.cookie( 'f' ) ){
      filters = JSON.parse( $.cookie( 'f' ) );
  }
  
  $( '#filter > input[value="' + filters.userType + '"]' ).attr( 'checked', 'checked' );
  handleUserTypes( filters.userType );
  
  $( '#filter>input[type="checkbox"]' ).attr( 'checked', filters.sharedProfiles );
  handleSharedProfiles( filters.sharedProfiles );

  $("input[type=radio]").change(function(){
      filters.userType = this.value;
      $.cookie( 'f', JSON.stringify( filters ) );
      handleUserTypes( this.value );
  });

  $("#filter>input[type=checkbox]").click(function () {
      filters.sharedProfiles = this.checked;
      $.cookie( 'f', JSON.stringify( filters ) );
      handleSharedProfiles( this.checked );
  });
}
