// Google Analytics tracking

$(function() {
    $("#callouts * a").bind("click",calloutLinkMouseClick);
    $("#related-materials a").bind("click",relatedMaterialClick);
    $("#related-materials * a").bind("click",relatedMaterialClick);
    $('.searchG p a').live("click",dynamicSearchCalloutClickLink);
});


//Google Analystics Event Tracking


function relatedMaterialClick() {
    GAtrackEvent('Related Materials', 'Link Clicked',jQuery(this).html()+":"+$(this).attr('href'));
    //console.log('RM click');
    if(typeof(_gat)!='object')document.write('<sc'+'ript src="http'+
        (document.location.protocol=='https:'?'s://ssl':'://www')+
        '.google-analytics.com/ga.js"></sc'+'ript>')

    try {
        var gwoTracker=_gat._getTracker("UA-5985951-1");
        gwoTracker._trackPageview("/0649303862/goal");
    }catch(err){}

}


function lNavClick() {
    GAtrackEvent('Navigation', 'Left Navigation Link Clicked',jQuery(this).html());
//console.log('lNav Fired');
}


function pNavClick() {
    GAtrackEvent('Navigation', 'Primary Navigation Link Clicked',jQuery(this).attr('title'));
//console.log('pNav Fired');
}


function flipClick() {
    GAtrackEvent('Callouts', 'Flipper Link Clicked',jQuery(this).attr('href'));
//console.log('Flipper Click Fired');
}


function videoClick() {
    GAtrackEvent('Video', 'Video Clicked', location.href);
//console.log('Video Click Fired');
}



function videoClickFull() {
    GAtrackEvent('Video', 'Full Video Clicked', location.href);
//console.log('Video Click Fired');
}

function videoClickHighlights() {
    GAtrackEvent('Video', 'Highlights Video Clicked', location.href);
//console.log('Video Click Fired');
}

function resourcesBoxClick(){
    GAtrackEvent('Callouts', 'Resource Box Click',jQuery(this).html() );
}


function audioClick() {
    GAtrackEvent('Audo', 'Audio Clicked', location.href);
//console.log('Video Click Fired');
}

function calloutLinkMouseOver() {
    GAtrackEvent('Callouts', 'Link Mouse Over',jQuery(this).attr('href'));
//console.log('Callout Link Mouse Over Fired');
}



function GAtrackEvent(catg,event,value) {
    if(typeof(pageTracker)!="undefined")
        pageTracker._trackEvent(catg,event,value);
    else
        console.log('sending to GA failed');
//console.log('Callout Link Mouse Over Fired');
}


function calloutLinkMouseClick() {
    GAtrackEvent('Callouts', 'Link Mouse Click', jQuery(this).attr('href'));

    if($(this).find('h4').html()) {
        GAtrackEvent('Callouts', 'Link Mouse Click - By Callout Title', "H4 Title: "+ jQuery(this).find('h4').html());
    //console.log('Callout Link Clicked by Callout Title Fired');
    }
    else if($(this).parent().find('h4').html()) {
        GAtrackEvent('Callouts', 'Link Mouse Click - By Callout Title', "H4 Title: "+ jQuery(this).parent().find('h4').html());
    //console.log('Callout Link Clicked by Callout Title Fired');
    }
    else if($(this).parent().parent().find('h4').html()) {
        GAtrackEvent('Callouts', 'Link Mouse Click - By Callout Title', "H4 Title: "+ jQuery(this).parent().parent().find('h4').html());
    //console.log('Callout Link Clicked by Callout Title Fired');
    }
    else if($(this).parent().parent().parent().find('h4').html()) {
        GAtrackEvent('Callouts', 'Link Mouse Click - By Callout Title', "H4 Title: "+ jQuery(this).parent().parent().parent().find('h4').html());
    //console.log('Callout Link Clicked by Callout Title Fired');
    }
    else if($(this).parent().parent().parent().parent().find('h4').html()) {
        GAtrackEvent('Callouts', 'Link Mouse Click - By Callout Title', "H4 Title: "+ jQuery(this).parent().parent().parent().parent().find('h4').html());
    //console.log('Callout Link Clicked by Callout Title Fired');
    }




//console.log('Callout Link Clicked Fired');
}

function calloutMouseOver() {
    if($(this).find('h4').html()) {
        GAtrackEvent('Callouts', 'Mouse Over', "H4 Title: "+ jQuery(this).find('h4').html());
    //console.log('Callout Mouse Over Fired');
    }
}


function dynamicSearchCalloutClickLink() {
    GAtrackEvent('Search Term Callout', 'Link Clicked', "Searched on "+query+" and went to "+jQuery(this).attr('href'));
    console.log('ST Click');


    if(typeof(_gat)!='object')document.write('<sc'+'ript src="http'+
        (document.location.protocol=='https:'?'s://ssl':'://www')+
        '.google-analytics.com/ga.js"></sc'+'ript>')

    try {
        var gwoTracker=_gat._getTracker("UA-5985951-1");
        gwoTracker._trackPageview("/0649303862/goal");
    }catch(err){}


}

