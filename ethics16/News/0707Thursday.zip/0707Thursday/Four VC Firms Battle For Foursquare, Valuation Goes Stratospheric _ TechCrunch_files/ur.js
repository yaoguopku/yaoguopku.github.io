
try{var pr=decodeURIComponent(document.referrer).split('/'),pl=pr.length,gr="https://techcrunch.com/2010/03/25/four-vc-firms-battle-for-foursquare-valuation-goes-stratospheric/".split('/'),gl=gr.length;
if((decodeURIComponent(document.referrer)==="https://techcrunch.com/2010/03/25/four-vc-firms-battle-for-foursquare-valuation-goes-stratospheric/")||((3<=pl)&&(3<=gl)&&(pr[2]===gr[2])&&(pr[0]===gr[0]))){

window.affinity_page_url = "https://techcrunch.com/2010/03/25/four-vc-firms-battle-for-foursquare-valuation-goes-stratospheric/";


document.write('<iframe id="IFR_IP_225_WEB" name="IFR_IP_225_WEB" width="0" height="0" border="0" style="display:none;padding:0px;margin:0px;border:0px none;width:0px;height:0px;" src="https://backfills.ph.affinity.com/IFR_IP_WEB.html#&p=3363373&s=225&kvuniqimp=833cadd81527461596c08c67719aee630706&misc=833cadd81527461596c08c67719aee630706&kvreqseq=1&afkvads=1&kvrit=1467841406&parenturl=https%3A%2F%2Ftechcrunch.com%2F2010%2F03%2F25%2Ffour-vc-firms-battle-for-foursquare-valuation-goes-stratospheric%2F&h_rf=https%3A%2F%2Ftechcrunch.com%2Fwp-content%2Fthemes%2Fvip%2Ftechcrunch-2013%2F_uac%2Fadpage.html&d_rf=https%3A%2F%2Ftechcrunch.com%2F2010%2F03%2F25%2Ffour-vc-firms-battle-for-foursquare-valuation-goes-stratospheric%2F"></iframe>');

document.write('<scr'+'ipt language="javascript1.1" charset="utf-8" src="https://adnet.affinity.com/addyn/3.0/5359.1/3363373/0/225/ADTECH;loc=100;cookie=info;target=_blank;key=ssl_secure;grp=[group];misc=833cadd81527461596c08c67719aee630706;kvreqseq=1;kvuniqimp=833cadd81527461596c08c67719aee630706;kvrit=1467841406;kvssl_secure=1;rdclick=" id="ad_833cadd81527461596c08c67719aee630706"></scri'+'pt>');



(function(W,D){var P="https://ip.ph.affinity.com/",S="",F=!1,T=((W===W.top)||(W.self===W.top)||(this===W.top)),XR=S,XH,n=0,xn=0,DR=D.referrer||S,RH=U(DR),TN=S;function E(v){return encodeURIComponent(v)}function U(u){try{u=decodeURIComponent(u);var a=u.split("/");if(('http:'===a[0])||('https:'===a[0])){u=a[2]||u}}catch(e){u=""+e}return u}try{try{TN=top.location.href||S}catch(e){}if(F===T){do{if(TN===S){try{XR=W.document.referrer||S;if(S!==XR){XH=U(XR);if(XH===RH){XR=XH=S}else{xn=n+1}}}catch(e){}}if(((20<n++)||(W===W.top)||(W.self===W.top)||(this===W.top))){W=F;break}W=W.parent||F}while(W)}
if(S!==XR){(new Image()).src=P+"xrftrk.php?"+["pid=wwu46","uuid=833cadd81527461596c08c67719aee630706&rf="+E(DR),"xref="+E(XR),"xn="+xn,"tn="+n,"affr2=-933689703&rdclick="].join("&")}
}catch(e){(new Image()).src=P+"jslog.php?drefchk=3&affr2=-933689703&m="+E(e.message);}})(window,document);
document.write("<scr"+"ipt type='text/javascript'>window._aftrckjson={'pr':'ip','pubkey':'qad56','adunit':'wwu46','placement_id':'3363373','uuid':'833cadd81527461596c08c67719aee630706','bnrsz':'728x90','fAdServer':'1','rnd2':'-933689703'};</scr"+"ipt>");
document.write('<scr'+'ipt type="text/javascript" src="https://inms-affmatrix-afn.netdna-ssl.com/js/track.js"></scr'+'ipt>');


}else{(new Image()).src="https://ip.ph.affinity.com/jslog.php?drefchk=1&async=none&pid=wwu46&rf=https%3A%2F%2Ftechcrunch.com%2F2010%2F03%2F25%2Ffour-vc-firms-battle-for-foursquare-valuation-goes-stratospheric%2F&tw=1&td=0&pm=1&ls=1&jn=1&af=&ag=2016-7-6&affr2=-933689703&aid=&rf2="+encodeURIComponent(document.referrer)}
}catch(e){(new Image()).src="https://ip.ph.affinity.com/jslog.php?drefchk=2&async=none&pid=wwu46&rf=https%3A%2F%2Ftechcrunch.com%2F2010%2F03%2F25%2Ffour-vc-firms-battle-for-foursquare-valuation-goes-stratospheric%2F&tw=1&td=0&pm=1&ls=1&jn=1&af=&ag=2016-7-6&affr2=-933689703&aid=&rf2="+encodeURIComponent(document.referrer)+"&er="+encodeURIComponent(e.message)}