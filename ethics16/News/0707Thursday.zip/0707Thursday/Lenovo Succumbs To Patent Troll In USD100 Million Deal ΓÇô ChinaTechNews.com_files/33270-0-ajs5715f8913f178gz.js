var reiCreativeData, 
	temperature,
	cityName,
	stateName,
	weatherCondition,
	color,
	productImageURL,
	productLinkURL,
	productNameCopy,
	ap_Temp,
	ap_Weather,
	groupName,
	cloudsSpriteImage,
	category;

function initiate(){	
	//var groupName = parent.dynamicJSONData['selected-group'];
	//console.log(dynamicData);
	if(undefined != dynamicData['REIMarFeed'] && dynamicData['REIMarFeed'].length >= 1){
		groupName = dynamicData['REIMarFeed'][0]["_jvxRtnGroup"]
	}else{
		groupName = "Default_Creative"
	}
	
	//console.log(groupName);
	jvxAd.getDynamicService("REICreativeMar:REICreativeMar", "ap_REICreativeMar="+groupName,"creativeDataHandler");	
}

function creativeDataHandler(result){
	result = result[Object.keys(result)[0]];
	reiCreativeData = result;
	
	if(ap_Weather != undefined && undefined != dynamicData['REIMarFeed'] && dynamicData['REIMarFeed'].length >= 1){
		weatherCondition = ap_Weather;
	}else{
		if(undefined != dynamicData['REIMarFeed'] && dynamicData['REIMarFeed'].length >= 1){
			weatherCondition = reiCreativeData[0]['_assetKey'].split('_')[1];
		}else{
			weatherCondition = reiCreativeData[0]['_assetKey'].split('_')[0];
		}
	}

	jvxInit();
}
function jvxInit()
{
	var initiate = (function(_root, _jvxAd,_creativeDataset,_dataset,jq)
	{
		//console.log(_dataset);
		//console.log(_creativeDataset);
		
		if(_dataset['geo:geo.city'] != undefined){
			stateName = _dataset['geo:geo.state'];
			cityName = _dataset['geo:geo.city']+", "+stateName;
		}else{
			cityName = "";
		}
		if(_dataset['weather:weather.temp'] != undefined){
			temperature = Math.round(_dataset['weather:weather.temp']);
		}else{
			temperature="";
		}
		
		category = _creativeDataset[0]["category"];
		//"//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Cloudy/300x250_Cloudy_Sprite_v4.jpg"
		if(groupName.search("Cloudy_Range_50_70") != -1 && category == "General"){
			cloudsSpriteImage = "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Cloudy/300x250_Cloudy_Range_50_70_Sprite_v1.jpg";
		}else if(groupName.search("Cloudy_Greater_70") != -1 && category == "General"){
			cloudsSpriteImage = "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Cloudy/300x250_Cloudy_Greater_70_Sprite_v1.jpg";
		}else if(groupName.search("Cloudy_Less_50") != -1 && category == "General"){
			cloudsSpriteImage = "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Cloudy/300x250_Cloudy_Less_50_Sprite_v1.jpg";
		}else{
			cloudsSpriteImage = "";
		}
		
		color = _creativeDataset[0]["color"];

		//console.log("temperature : "+temperature);
		//console.log("ap_Weather : "+ap_Weather);
		//console.log("weatherCondition : "+weatherCondition);
		//console.log('cityName : ',cityName);
		//console.log('color : ',color);

		if (groupName != "Default_Creative"){
			/*
			for(var key in _dataset['REIMarFeed'][0])
			{
				_dataset['REIMarFeed'][0][key] = decodeURIComponent(_dataset['REIMarFeed'][0][key]);
			}*/

			productImageURL = _dataset['REIMarFeed'][0]["image_link"].replace('media','zoom')+"/150x118";//"//www.rei.com/media/ii/9d1ed45c-b664-4f81-8a9c-dc951e9000c6.jpg";
			productLinkURL = decodeURIComponent(_dataset['REIMarFeed'][0]["link"]);//"http://www.rei.com/product/892875/shimano-sh-m200-mountain-bike-shoes-mens?cm_mmc=ad_jivox_weather&CAWELAID=120217890001855336";
			productNameCopy = decodeURIComponent(_dataset['REIMarFeed'][0]["title"]);//"Shimano SH-M200 Mountain Bike Shoes - Men's";
			
			var productNameTemp = productNameCopy.split(" - ");
			//console.log("productNameTemp",productNameTemp);
			if(productNameTemp.length >= 2){
				productNameCopy = "<span>"+productNameTemp[0]+"</span> - <span style='color:#"+color+";'>"+productNameTemp[1]+"</span>";
			}
		}else{
			productLinkURL = "http://www.rei.com";
		}
		
		/*
				sunImg : "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Sunny/sun.png",
				sunFlareImg1 : "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Sunny/flair.png",
				sunFlareImg2 : "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Sunny/flair.png",
		*/
		var sparkREI = sparkREI || {};		
		sparkREI.defaults = {
			container:"#maincontainer",
			cloudyData: 
			{
				unitBorder : "",
				cloudsSpriteContainer:cloudsSpriteImage,
				bgImg : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_bg"],
				logo : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_logo"],
				headline : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_headline"],
				top_line :"",
				bottom_line:"",
				city : cityName,
				weatherIcon : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_weater_icon"],
				degree: temperature+"&deg;",
				productImg : productImageURL,
				productName : productNameCopy,
				showNowCTA : _creativeDataset[0]["cta_copy"]
			},
			snowyData: 
			{
				unitBorder : "",
				bgImg : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_bg"],
				snowImg : "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Snowy/snow.png",
				top_line :"",
				logo : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_logo"],
				bottom_line:"",
				headline : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_headline"],
				city : cityName,
				weatherIcon : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_weater_icon"],
				degree: temperature+"&deg;",
				productImg : productImageURL,
				productName : productNameCopy,
				showNowCTA : _creativeDataset[0]["cta_copy"]
			},
			sunnyData: 
			{
				unitBorder : "",
				bgImg : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_bg"],
				sun2:  "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Sunny/300x250_sun2.png",
				sun1:  "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Sunny/300x250_sun1.png",
				white1: "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Sunny/300x250_white1.png",
				blue2: "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Sunny/300x250_blue2.png",
				blue1: "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Sunny/300x250_blue1.png",
				top_line :"",
				logo : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_logo"],
				bottom_line:"",
				headline : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_headline"],
				city : cityName,
				weatherIcon : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_weater_icon"],
				degree: temperature+"&deg;",
				productImg : productImageURL,
				productName : productNameCopy,
				
				showNowCTA : _creativeDataset[0]["cta_copy"]
				
			},
			rainyData: 
			{
				unitBorder : "",
				bgImg : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_bg"],
				rainImg : "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Rainy/rain_long_drops_v3.png",
				rainSmudgeImg : "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Rainy/drop.png",
				top_line :"",
				logo : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_logo"],
				bottom_line:"",
				headline : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_headline"],
				city : cityName,
				weatherIcon : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_weater_icon"],
				degree: temperature+"&deg;",
				productImg : productImageURL,
				productName : productNameCopy,
				showNowCTA : _creativeDataset[0]["cta_copy"]
			},
			defaultData:
			{
				unitBorder : "",
				bgImg : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_bg"],
				logo : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_logo"],
				top_line :"",
				headline : _creativeDataset[0][parent.layoutObj.matchLayoutDim+"_headline"],
				bottom_line:"",
				product1: "//cdn.jivox.com/files/33270/REI/images/CommonAssets/default_products/884614_Garmin_Fenix_GPS_Watch.jpg",
				product2: "//cdn.jivox.com/files/33270/REI/images/CommonAssets/default_products/886299_Garmin_Vivofit.jpg",
				product3: "//cdn.jivox.com/files/33270/REI/images/CommonAssets/default_products/882144_GoPro_Hero4_1.jpg",
				
				showNowCTA : _creativeDataset[0]["cta_copy"]
			},
			totalImageCount:0,
			totalImagesLoaded:null
		};
		(function()
		{
			var self = this,
			cMacro = parent.getParameterValue(parent.window.location.href, "cMacro");
			cMacro = ((typeof cMacro !== "undefined") && cMacro != ""  && cMacro != null) ? decodeURIComponent(cMacro) : "";
			
			self.alignLayout = function () 
			{
				if(jq("#snowImg").length == 1)
				{
					var snowImg_container = document.createElement('div');
							snowImg_container.setAttribute("id", "snowImg_container");
							document.getElementById('maincontainer').appendChild(snowImg_container);
							snowImg_container.appendChild(document.getElementById('snowImg'));
				}
				else if(jq("#rainImg").length == 1)
				{
					var rainImg_container = document.createElement('div');
							rainImg_container.setAttribute("id", "rainImg_container");
							document.getElementById('maincontainer').appendChild(rainImg_container);
							rainImg_container.appendChild(document.getElementById('rainImg'));
				}
				jq('#maincontainer').css({opacity: 0});
				

				(function checkifImagesLoaded(){
					//console.log("totalImageCount",self.defaults.totalImageCount,"totalImagesLoaded",self.defaults.totalImagesLoaded);
					if(self.defaults.totalImageCount === self.defaults.totalImagesLoaded)
					{
						setTimeout(function()
						{
							jq('#bgImg').css({top: 0});
							jq('#headline').css({top: (parent.layoutObj.layoutHeight - jq('#headline').height())/2});
							jq('#top_line').css({top: parseInt(jq("#headline").css("top"))-jq("#top_line").height() -24});
							jq('#bottom_line').css({top: parseInt(jq("#headline").css("top")) + jq("#headline").height() +22});
						
							if(weatherCondition == 'Default')
							{
								jq("#product1").css({'left': -(parent.layoutObj.layoutWidth)});
								jq("#product2").css({'left': (jq("#product1").position().left)*1.5});
								jq("#product3").css({'left': (jq("#product2").position().left)*1.5});

							}else{
								jq('#degree').css({top:262, "color":"#"+color});
								jq('#weatherIcon').css({left: (parseInt(jq('#degree').css("left")) + jq('#degree').width()), top:267});
								jq('#city').css({left: (parseInt(jq('#weatherIcon').css("left")) + jq('#weatherIcon').width()), top:264});
								jq('#productName').css({left: -130});
								//jq('#productImg').css({right: -170});
							}
							jq('#showNowCTA').css({left: -124, "background-color": "#"+color });
							
							
							jq("#showNowCTA").on("click", function(e){
								e.stopPropagation();
								e.preventDefault();
								//console.log("SHOW NOW");
								self.fireEvent("Show_Now_CTA","click");
								_jvxAd.openURL(cMacro + productLinkURL);
							});
							jq('body').on("click", function(e){
								e.stopPropagation();
								e.preventDefault();
								//console.log("ClickThrough");
								_jvxAd.openClickThrough(productLinkURL);
							});
							jq('#maincontainer').css({opacity: 1});
							self.startAnimation();
						},300);
					}
					else
					{
						setTimeout(checkifImagesLoaded,500)	
					}
				}());


				
			}
			self.startAnimation = function () 
			{
				
				var backgroundAnimate = (function bgFunc()
				{
					//console.log("bg animate");
					function cloudysunnyanim()
					{
						//console.log("cloudySunny return func");
						jq("#cloudsSpriteContainer").delay(4100).animate({"top": "-190px"},7e2, "easeInOutCirc");
						jq("#bgImg").delay(4100).animate({"top": "-190px"},7e2, "easeInOutCirc", function(){
							
							jq("#productImg").animate({"right": "12px"},7e2, "easeOutExpo");
							jq("#productName").animate({"left": "12px"},7e2, "easeOutExpo");
							jq("#showNowCTA").delay(300).animate({"left": "12px"},1e3, "easeOutExpo",function(){
									jq(this).css({'z-index':'2'});
							});
						});
						//jq("#headline, #top_line, #bottom_line").delay(4100).hide();
					}
					function snowyRainyAnimation()
					{
						//console.log("snow rain anim");
						jq("#bgImg").delay(4100).animate({"top": "-190px"},{
							duration: 7e2,
							easing : "easeInOutCirc",
							step : function(now, fx)
							{
								if(parseInt(now) ==  -(jq("#bgImg > img").height() - parent.layoutObj.layoutHeight))
								{	
									jq("#productImg").animate({"right": "12px"},7e2, "easeOutExpo");
									jq("#productName").animate({"left": "12px"},7e2, "easeOutExpo");
									jq("#showNowCTA").delay(300).animate({"left": "12px"},1e3, "easeOutExpo",function(){
										jq(this).css({'z-index':'2'});
									});
								}
							}
						});
						if(jq("#snowImg_container").length == 1)
							{
								jq("#snowImg_container").delay(4100).animate({"top":"-190px"},7e2, "easeInOutCirc");
								jq("#snowImg > img").delay(4100).animate({"opacity":0},8e2, "linear");
							}
						else{
							
							jq("#rainImg_container").delay(4100).animate({"top":"-190px"},7e2, "easeInOutCirc");
							jq("#rainImg > img").delay(4200).animate({"opacity":0},9e2, "linear");
							jq("#rainSmudgeImg").delay(4100).animate({"opacity":0, "top":"-190px"},7e2, "easeInOutCirc");
						}
						
					}

					function defaultCreative() {
					    //console.log("default creative");
		
						jq('#showNowCTA').css({"top": "190px", "left":"321px","background-color": "#"+color });
						jq("#bgImg").delay(4100).animate({"top": -190},520, "easeInOutCirc", function(){
							jq("#product1").animate({"left": parent.layoutObj.layoutWidth * 3},3e3,"linear");
							jq("#product2").animate({"left": parent.layoutObj.layoutWidth * 2.5},3e3,"linear");
							jq("#product3").animate({"left": parent.layoutObj.layoutWidth * 1},3e3,"linear",function(){
								jq("#headline").animate({top : 80},520, "easeInOutCirc");
								jq('#top_line').animate({top: 80 -jq("#top_line").height() -24},520, "easeInOutCirc");
								jq('#bottom_line').animate({top: 80 + jq("#headline").height() +22},520, "easeInOutCirc");
								jq("#bgImg").animate({"top": "0px"},520, "easeInOutCirc",function(){
									jq("#showNowCTA").delay(300).animate({"left": "90px"},7e2,function(){
										jq(this).css({'z-index':'2'});
									});
								});
								jq("#logo").animate({"top": "185px"},520,"easeInOutCirc");
							});
						});
						jq("#logo").delay(4100).animate({"top": "-5px"},520,"easeInOutCirc");
					}


					var anim;
					switch(weatherCondition)
					{
						case "Cloudy":
						{
							//console.log("cloudy condition");
							//clouds : "//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Cloudy/clouds.jpg",
							//jq("#clouds").animate({"top": "-400px"},9e3, "linear");
							
							if(cloudsSpriteImage != ""){
								var currentFrame = 0,
								width = 300,
								spriteWidth = (9000*3)-width;
		
								jq("#unitBorder").css({"line-height":0}).delay(500).animate(
								{
									"line-height": (spriteWidth/width)
								},
								{
								 	duration: ((spriteWidth/width)*67),
								 	easing : "linear",
								 	step: function(now, fx)
								 	{
								 		currentFrame = (parseInt(now) * width)*-1;
								 		//console.log(currentFrame,parseInt(now));
								 		if(currentFrame > -9000){
								 			jq("#cloudsSpriteContainer img").css({'left': currentFrame+'px'})
								 		}else if(currentFrame > -18000 && currentFrame <= -9000){
								 			jq("#cloudsSpriteContainer img").css({'left': (currentFrame+9000)+'px'})
								 		}else{
								 			jq("#cloudsSpriteContainer img").css({'left': (currentFrame+18000)+'px'})
								 		}
								 		//console.log("fx",fx,"now",parseInt(now));
								 	}
								});
							}
							
							anim = cloudysunnyanim;
							break;
						}
						case "Sunny":
						{
							/*
							sunFlareSpriteContainer:"//cdn.jivox.com/files/33270/REI/images/CommonAssets/300x250/Sunny/300x250_Sunny_Sprite.png",
							var currentFrame = 0,
							width = parseInt(jq("#sunFlareSpriteContainer").width()),
							spriteWidth = 10500;
		
							jq("#sunFlareSpriteContainer").css({'background-position': '0 0',"line-height":0}).delay(1000).animate(
							{
								"line-height": (spriteWidth/width)
							},
							{
								 duration: ((spriteWidth/width)*100),
								 step: function(now, fx)
								 {
								 	//console.log("fx",fx,"now",parseInt(now));
								 	currentFrame = (parseInt(now) * width)*-1;
								 	jq("#sunFlareSpriteContainer").css({'background-position': currentFrame+'px 0'})
								 }
							});
							*/
							
							jq("#blue1 img").delay(1267+500).animate({"opacity": "0.33","top":"90px","left":"74px"},433, "linear",function(){
								jq(this).animate({"opacity": "0.37","top":"103px","left":"117px","width":"108px","height":"116px"},33, "linear",function(){
									jq(this).animate({"opacity": "0.56","top":"104px","left":"158px","width":"114px","height":"122px"},167, "linear",function(){
										jq(this).animate({"opacity": "0.90","top":"105px","left":"183px","width":"117px","height":"126px"},100, "linear",function(){
											jq(this).animate({"opacity": "0.67","top":"105px","left":"191px","width":"117px","height":"126px"},33, "linear",function(){
												jq(this).animate({"opacity": "0.22","top":"121px","left":"225px","width":"99px","height":"106px"},67, "linear",function(){
													jq(this).animate({"opacity": "0.35","top":"144px","left":"275px","width":"70px","height":"76px"},100, "linear",function(){
														jq(this).animate({"opacity": "0"},67, "linear",function(){
												 			 	
														});
													});
												});
											});
										});
									});
								});
							});
							
							jq("#blue2 img").delay(1267+500).animate({"opacity": "0.21","top":"2px","left":"99px"},433, "linear",function(){
								jq(this).animate({"opacity": "0.41","top":"0px","left":"170px","width":"117px","height":"124px"},33, "linear",function(){
									jq(this).animate({"opacity": "0.57","top":"16px","left":"160px","width":"106px","height":"113px"},167, "linear",function(){
										jq(this).animate({"opacity": "0.63","top":"39px","left":"178px","width":"98px","height":"104px"},67, "linear",function(){
											jq(this).animate({"opacity": "0.10","top":"118px","left":"240px","width":"70px","height":"76px"},233, "linear",function(){
												jq(this).animate({"opacity": "0"},67, "linear",function(){
												 				
												});
											});
										});
									});
								});
							});
							
							jq("#white1 img").delay(1233+500).animate({"opacity": "0.20","top":"21px","left":"53px"},233, "linear",function(){
								jq(this).animate({"opacity": "0.20","top":"21px","left":"64px"},33, "linear",function(){
									jq(this).animate({"opacity": "0.86","top":"22px","left":"120px"},167, "linear",function(){
										jq(this).animate({"opacity": "0.29","top":"22px","left":"131px"},33, "linear",function(){
											jq(this).animate({"opacity": "0.32","top":"22px","left":"165px"},100, "linear",function(){
												jq(this).animate({"opacity": "0.35","top":"22px","left":"166px","width":"134px","height":"114px"},100, "linear",function(){
													jq(this).animate({"opacity": "0.62","top":"20px","left":"168px","width":"163px","height":"139px"},133, "linear",function(){
														jq(this).animate({"opacity": "0.28","top":"44px","left":"219px","width":"138px","height":"117px"},67, "linear",function(){
															jq(this).animate({"opacity": "0.45","top":"79px","left":"295px","width":"100px","height":"86px"},100, "linear",function(){
																jq(this).animate({"opacity": "0"},67, "linear",function(){
												 				
																});
															});
														});
													});
												});
											});
										});
									});
								});
							});
							jq("#sun1 img").delay(267+500).animate({"opacity": "0.32"},433, "linear",function(){
								jq(this).animate({"opacity": "0.4"},400, "linear",function(){
									jq(this).animate({"opacity": "0.17"},167, "linear",function(){
										jq(this).animate({"opacity": "0.5"},333, "linear",function(){
											jq(this).animate({"opacity": "0.19","top":"-232px","left":"-60px","width":"362px","height":"370px"},167, "linear",function(){
												jq(this).animate({"opacity": "0.48","top":"-168px","left":"100px","width":"400px","height":"388px"},100, "linear",function(){
													jq(this).animate({"opacity": "0.51","top":"-84px","left":"138px","width":"312px","height":"302px"},200, "linear",function(){
														jq(this).animate({"opacity": "0.34","top":"-28","left":"164px","width":"254px","height":"244px"},133, "linear",function(){
															jq(this).animate({"opacity": "0"},67, "linear",function(){
												 
															});
														});
													});
												});
											});
										});
									});
								});
							});
							
							jq("#sun2 img").delay(267+500).animate({"opacity": "0.4"},433, "linear",function(){
								jq(this).animate({"opacity": "0.08"},467, "linear",function(){
									jq(this).animate({"opacity": "0.08"},367, "linear",function(){
										jq(this).animate({"opacity": "0.17"},233, "linear",function(){
											jq(this).animate({"opacity": "0.48", "top":"-168px","left":"24px","width":"476px","height":"418px"},133, "linear",function(){
												jq(this).animate({"opacity": "0.91", "top":"-210px","left":"0px","width":"446px","height":"438px"},133, "linear",function(){
													jq(this).animate({"opacity": "0.33", "top":"-28px","left":"84px","width":"332px","height":"278px"},166, "linear",function(){
														jq(this).animate({"opacity": "0"},67, "linear",function(){
												
														});
													});
												});
											});
										});
									});
								});
							});
							/*
							//console.log("Sunny condition");
							jq("#sunFlareImg1").fadeIn(2000);
							jq("#sunFlareImg2").fadeIn(2000);							
							jq("#sunImg").animate({
									"left":parent.layoutObj.layoutWidth + "px",
									"top" : "-80px"
								}, {
									duration : 3.1e3,
									easing : "easeInExpo",
									step: function( now, fx ) {
								
									if(parseInt(now) <= -68)
									{
										jq("#sunFlareImg1").animate({
											"left":parent.layoutObj.layoutWidth + "px"
										},1e3,"easeInExpo");
										jq("#sunFlareImg2").animate({
											"left":(parent.layoutObj.layoutWidth+100) + "px",
											"opacity": "0.5"
										},1e3,"easeInExpo");
									}
								  }
							});	
							*/
							anim =  cloudysunnyanim;
							break;
						}
						case 'Snowy':
						{
							//console.log("Snowy condition");
							jq("#snowImg").animate({
								"top": "0px"
							},7e3, "linear");
							anim = snowyRainyAnimation;
							break;
						}
						case 'Rainy':
						{
							//console.log("Rainy condition");
							var range = [7, 10], 
							randomNumber = Math.floor(Math.random() * ((range[1]-range[0])+1) + range[0]),
							opacityRange = [0.1, 1], 
							opacRandomRange = Math.random() * (opacityRange[1]-opacityRange[0]) + opacityRange[0],
							smudges = jq("#rainSmudgeImg > img");
							jq("#rainImg").animate({
								"top": "0px"
							}, 7e3, "linear");
							for(i=1; i<=randomNumber;i++)
							{
								//console.log("for loop", i);
								var showSmudgeTime = 500*i;
								 jq(smudges).clone().insertAfter(smudges).fadeIn(showSmudgeTime).css({
									"position" : "absolute",
									"left" : (Math.random() * (parent.layoutObj.layoutWidth - 20)).toFixed() + "px",
									"top":   (Math.random() * (parent.layoutObj.layoutHeight - 20)).toFixed() + "px",
									"opacity" : opacRandomRange
								 });
							}
							anim = snowyRainyAnimation;
							break;
						}
						default:
      						 anim = defaultCreative;
					}
					return anim;
				}());
				
				var tl = parseInt(jq("#top_line").css("top"));
				var hl = parseInt(jq("#headline").css("top"));
				var bl = parseInt(jq("#bottom_line").css("top"));
				
				var tl_ep = (tl - 190);
				var hl_ep = (hl - 190);
				var bl_ep = (bl - 190);
				//console.log(tl, hl, bl);
				//console.log(tl_ep, hl_ep, bl_ep);
				
				if(weatherCondition != 'Default')
				{
					//jq("#headline").delay(1300).animate({
					//	"left": "0"
					//},4e2, "easeOutExpo",function(){
						jq("#headline").delay(1300).animate({"left" : "0px"},420, "easeOutExpo");
						jq("#top_line").delay(1500).animate({"left" : "113px"},520, "easeOutExpo");
						jq("#bottom_line").delay(1500).animate({"left" : "113px"},520, "easeOutExpo",function()
						{
							backgroundAnimate();
							
							jq("#top_line").delay(4100).animate({top: tl_ep},7e2,"easeInOutCirc");
							jq("#headline").delay(4100).animate({top: hl_ep},7e2,"easeInOutCirc");
							jq("#bottom_line").delay(4100).animate({top: bl_ep},7e2,"easeInOutCirc");
	
							jq("#logo").delay(4100).animate({"top": "-5px"},7e2,"easeInOutCirc");
							jq('#degree').delay(4100).animate({"top":"66px"},7e2,"easeInOutCirc");
							jq('#weatherIcon').delay(4100).animate({"top":"71px"},7e2,"easeInOutCirc");
							jq('#city').delay(4100).animate({top:68},7e2,"easeInOutCirc");
						});
						//jq(this).delay(4100).fadeOut();
						//jq("#top_line, #bottom_line").delay(4100).fadeOut();
					//});
				}
				else
				{
					jq("#headline").css({"top" : "80px"});
					jq('#top_line').css({top: parseInt(jq("#headline").css("top"))-jq("#top_line").height() -22});
					jq('#bottom_line').css({top: parseInt(jq("#headline").css("top")) + jq("#headline").height() +22});
					//jq("#headline").delay(1300).animate({
					//	"left": "0"
					//},4e2, "easeOutExpo",function(){
					
						jq("#headline").delay(1300).animate({"left" : "0px"},420, "easeOutExpo");
						jq("#top_line").delay(1500).animate({"left" : "113px"},520, "easeOutExpo");
						jq("#bottom_line").delay(1500).animate({"left" : "113px"},520, "easeOutExpo",function()
						{
							backgroundAnimate();
							jq("#top_line").delay(4100).animate({top: tl_ep},520,"easeInOutCirc");
							jq("#headline").delay(4100).animate({top: hl_ep},520,"easeInOutCirc");
							jq("#bottom_line").delay(4100).animate({top: bl_ep},520,"easeInOutCirc");
						});
					//});
				}
			}
			self.fireEvent = function(productId,eventType)  // Fire Event. Impression and Click
			{
			   _jvxAd.recordEventByName(productId + " - " + eventType, (eventType.indexOf("Imp") > -1) ? 0 : 1);
			};
			self.hideElemUsingOp = function (id,speed)
			{
				jq(id).animate({opacity:'0'},speed);
			}
			self.createElem = function(tag,attrs,txtContent,parentcontainer) 
			{
				if(typeof parentcontainer =="undefined")
					parentcontainer = self.defaults.container;
				var newEl = jq("<"+tag+"/>").appendTo(parentcontainer).attr(attrs).html(txtContent);
				if(tag == "img")
				{
					$(newEl).on("load",function()
					{
						self.defaults.totalImagesLoaded	= (self.defaults.totalImagesLoaded	 == null) ? 1 : self.defaults.totalImagesLoaded + 1;
						//console.log(this,self.defaults.totalImagesLoaded);
					})
				}
				return newEl;
			}
	        self.generateLayout = function()
			{
				jq.each((function(){
					if(weatherCondition == "Cloudy")
						return self.defaults.cloudyData
					else if(weatherCondition == "Snowy")
						return self.defaults.snowyData
					else if(weatherCondition == "Sunny")
						return self.defaults.sunnyData
					else if(weatherCondition == "Rainy")
						return self.defaults.rainyData
					else 
      					return self.defaults.defaultData
					
				}()), function(key, value) 
				{
					value = decodeURIComponent(value);
					value = value.replace(/{{/g, "<p/>");
					self.createElem("div",{'id':key},(function(){
					if(value.indexOf("//") !=-1)
					{
						self.defaults.totalImageCount++;
						return self.createElem("img",{'src':value});
					}
					
					return value;
				   }()));
				   
				});
				self.alignLayout();
			}
			self.init = function()
			{
				self.generateLayout();
			}
		}).apply(sparkREI);
		return sparkREI.init; // Start
	}(window, jvxAd, reiCreativeData,dynamicData,jQuery));
	//}(window, jvxAd, dynamicData,jQuery));

 initiate();
}