
AMPTManager.registry.push([
{
  "rktr_deployed_date": "2016-06-22 12:35:36",
  "rktr_slot_id": "page",
  "rktr_id": "cnnmoney_tech",
  "gpt_id": "8663477",
  "site": "cnn_money",
  "root": "CNNMONEY",
  "targeting": []
},
{
  "rktr_slot_id": "ad_oop_skin_01",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[1,1]],
    
  "targeting": [["pos",["oop_skin_01"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_oop_inter_01",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[1,1]],
    
  "targeting": [["pos",["oop_inter_01"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_bnr_atf_01",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[728,90],[970,66],[970,90],[970,250]],
    
  "targeting": [["pos",["bnr_atf_01"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_bnr_btf_01",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[1,1]],
    
  "targeting": [["pos",["bnr_btf_01"]]],
  "responsive":[[["1024", "0"], [["1", "1"]]], [["782", "0"], [["1", "1"]]], [["0", "0"], [["1", "1"]]]]
},
{
  "rktr_slot_id": "ad_rect_atf_01",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[300,250],[300,600],[300,1050]],
    
  "targeting": [["pos",["rect_atf_01"]]],
  "responsive":[[["1024", "0"], [["300", "1050"], ["300", "600"], ["300", "250"]]], [["782", "0"], [["300", "600"], ["300", "250"]]], [["0", "0"], [["300", "250"]]]]
},
{
  "rktr_slot_id": "ad_rect_atf_02",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[300,250]],
    
  "targeting": [["pos",["rect_atf_02"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_rect_btf_01",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[300,250],[300,251],[300,600],[300,601],[300,1050],[300,1051]],
    
  "targeting": [["pos",["rect_btf_01"]]],
  "responsive":[[["1024", "0"], [["300", "1051"], ["300", "1050"], ["300", "601"], ["300", "600"], ["300", "251"], ["300", "250"]]], [["782", "0"], [["300", "601"], ["300", "600"], ["300", "251"], ["300", "250"]]], [["0", "0"], [["300", "251"], ["300", "250"]]]]
},
{
  "rktr_slot_id": "ad_ns_atf_01",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[200,60]],
    
  "targeting": [["pos",["ns_atf_01"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_ns_atf_02",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[175,31]],
    
  "targeting": [["pos",["ns_atf_02"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_ns_btf_01",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[300,250]],
    
  "targeting": [["mod",["quigo"]],["pos",["ns_btf_01"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_ns_btf_02",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[620,215]],
    
  "targeting": [["mod",["quigo"]],["pos",["ns_btf_02"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_ns_btf_03",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[220,200]],
    
  "targeting": [["mod",["quigo"]],["pos",["ns_btf_03"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_ns_btf_04",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[353,435]],
    
  "targeting": [["mod",["quigo"]],["pos",["ns_btf_04"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_ns_btf_05",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[300,340]],
    
  "targeting": [["mod",["quigo"]],["pos",["ns_btf_05"]]],
  "responsive":[]
},
{
  "rktr_slot_id": "ad_ns_btf_06",
  "rktr_ad_id": "CNNMoney/tech/main",
  "sizes": [[780,285],[780,385]],
    
  "targeting": [["mod",["quigo"]],["pos",["ns_btf_06"]]],
  "responsive":[]
}
]);