  (function(){
        var localhash = (window._mNDetails && _mNDetails['locHash'] && _mNDetails['locHash']['111121628']) || '';
		var imgUrl = 'http://qsearch.media.net/flping.php?reason=32&action=4&cme=xlXvLQpYwnNahfbarE7GX1zJQ8shMJWu8WYJfDWpOELHuP%2B1eV2OeW53DeUcEaqnyMt5TsZhbUYKXtvINxfgTtm7F2schVLn5krYNJGe9sh%2Bsi4Pag5NtTJHXSqET4eH2McEvXuHq0UfysoSI%2BkyzQ4CDTR1SAJVnTSHueOhn2tWf5VcjubzSYHsHiwqjdZylHWvQFUAJI2VMeDUGFg5%2BKlMH0K33%2FVA%2Fv6Ktkn8MeVpaTCzXVnYTQKlqqSK4dZvat01Qb1m50iKS%2FKHBQkXkaVsRv8wDdRPdakfCbRIchn0sCUDelKsNphBDuZej8Kw5VMKmPZsHP8eJdO0mo0YAzUquIUTtJUWgvE2s0cQCIicdvlKNHxmlA5QrQou%2FzOWD5xv8GaHbz8frpgVLTdE8LVwKJdoLxGqhZrAm15WHVp2VWE2rQWuZvXDrKvQIQciHyRFCnNKQPmHCgI2Vu9OuZgAdq0Vsm6F4TDJVEzQ2n%2FVFgU04FhSHRYOY5s4WeGQTyjeFj3WOE40bIUAEMIoSHYo%2BXyp7TCp2D9BRVmB5Co2vp8eX%2FyjH6YZ1Ob9wyio9XOKDXTTVjmDNpsQ9GPE8wwFanMHCflf3wClAEHWjcpPo5LLUAHIihDdvCxAHKVWOaIRuwA3p78%3D%7C%7C&r='+new Date().getTime()+'&'+localhash.replace(/#/g, '&');
		if(window._mN && _mN._util && _mN._util.logNBBeacons){
			_mN._util.logNBBeacons(imgUrl);
		}else if(window._mN && _mN.util && _mN.util.logBeacons){
			_mN.util.logBeacons(imgUrl);
		}else{
			(new Image()).src = imgUrl;
		}
	})();/*Ad has been hidden*/try{window.parent.window.document.getElementById(window.frameID).style.display = "none";}catch(e){};try{var _adId = window.parent.window.document.getElementById("111121628");if(_adId){_adId.style.display = "none";}}catch(e){};try{if(parent && typeof(parent._rtClose) === "function"){  parent._rtClose("111121628"); }}catch(e){};			if(window.parent.window._mNDetails.console !== undefined && window.parent.window._mNDetails.console.mNForceConsoleCallback !== undefined){
				window.parent.window._mNDetails.console.mNForceConsoleCallback("layer2Url", 'http://cdn3ncal.media.net/fcmdynet.js?esi=1&ry=0&fvips=0&vpf=000&chost=contextual.media.net&&cid=8CU6CD37D&cpcd=VCXvISq8O5d0dB1ktjcGkA%3D%3D&crid=111121628&size=571x200&cc=HK&vif=1&requrl=http%3A%2F%2Fblogs.wsj.com%2Fchinarealtime%2F2016%2F06%2F03%2Funtangling-chinas-cybersecurity-laws%2F&nse=3&vi=1467667533499869106&lw=1&ugd=4&bct=China%20Real%20Time%20Report%40%23%40&re=1&nb=1&isOffice=0', '111121628');
			}
			if(window.parent.window._mN && window.parent.window._mN.util && window.parent.window._mN.util.triggerAdTagEvent) {
			    window.parent.window._mN.util.triggerAdTagEvent('111121628', 'layerTwoFailover', false, 'FAILOVER_REASON_ENTITY_FORCED_HIDE_BLOCK');
			}
