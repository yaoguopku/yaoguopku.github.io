define('flyover', [
  'vendor.asset.jquery/jquery',
  'vendor.asset.underscore/underscore',
  'wsj.assets.grid/context'
], function ($, _, Intent) {

	var $content = $("#wsj-article-wrap"),
	target = 0,
	scrollDepth = 0;

	function isIE () {
    var myNav = navigator.userAgent.toLowerCase();
    return (myNav.indexOf('msie') === -1) ? false : parseInt(myNav.split('msie')[1]);
  }

  function getTriggerTarget() {
  	target = $content.offset().top + $content.height()/3;
  }

  function setupFlyout(elm){

    var item;
    var closeElem = $(elm).find(".wsj-flyover__close");

    item = {
      elem: elm,
      target: target,
      status: "invisible"
    };

    var onCloseElemClick = function() {
      closeFlyover(item);
    }

    if (closeElem.length > 0) {
      closeElem.on("click.flyover", onCloseElemClick);
      item.closeElem = closeElem;
    }

    return item;

  }


  function doOnScroll() {
    
    var doc = document.documentElement;
  	scrollDepth = (window.pageYOffset || doc.scrollTop)  - (doc.clientTop || 0);

    checkAllStates();

  }


  function closeFlyover(item) {
    $(item.elem).removeClass("wsj-flyover--active").addClass("wsj-flyover--closed");
    item.closeElem.off("click.flyover");
  }


  function checkAllStates() {
  	for (i in items) {
      items[i].status = checkState(items[i]) ? "visible" : "invisible";
  	}

    if (!anyFlyoutsLeft()) {
      stopWatching();
    }
  }

  function checkState(item){

    if (item.status == "visible") return true;

      if (scrollDepth >= item.target) {
        $(item.elem).addClass('wsj-flyover--active');
        return true;
      } else {
        return false;
      }
  }


  function anyFlyoutsLeft() {

  	var activeCount = 0;

  	for (i in items) {
  		if (items[i].status != "visible") {
  			activeCount++;
  		}
  	}

  	if (activeCount <= 0) {
  		return false;
  	} else {
  		return true;
  	}
  }


  function stopWatching() {

  	$(document).off("scroll.flyover");
  	$(window).off("resize.flyover");
  }

  function startWatching() {


    if (!anyFlyoutsLeft()) return;

  	//prevent dupe events
  	stopWatching();

  	var throttleScroll = _.throttle(doOnScroll, 100);
  	var debouncedResize =  _.debounce(getTriggerTarget, 100);

		$(document).on('scroll.flyover', throttleScroll);
		$(window).on('resize.flyover', debouncedResize);

  }



  var items = [];

  var flyover = {

    init: function () {

      // This breaks ie8
      if (isIE() && isIE() < 9) {
        return;
      }
      //checkAllStates();

      getTriggerTarget();

      $(".wsj-flyover").each(function(i) {
        items[i] = setupFlyout(this);
      });

      if (anyFlyoutsLeft()) {

        startWatching();

        // after all images and assets loaded
        $(window).on('load', getTriggerTarget);

        // intention events
        Intent.on('width:at16units', startWatching);
        Intent.on('width:at12units', startWatching);

        // when to cancel the stickiness
        Intent.on('width:at8units', stopWatching);
        Intent.on('width:at4units', stopWatching);

      }
      
    } //end of module init

  };

  return flyover;

});


//TODO: move init below to the concat file
//copied from article page sticky ad
//used in article flyover/recommended post
require(['flyover'], function (flyover) {
  flyover.init();
});