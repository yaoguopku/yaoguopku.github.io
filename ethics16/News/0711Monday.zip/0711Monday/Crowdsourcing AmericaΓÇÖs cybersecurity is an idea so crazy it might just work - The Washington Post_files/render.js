
(function() {
  try {
    var socialTools = {
        myRoot: '.top-sharebar-wrapper',
        init: function() {
        	$('.pb-f-sharebars-top-share-bar').each(function(index, root) {
        		//vertical-sticky-top-sharebar has no mobile view
            	if (!TWPHead.desktop && !$(root).find('.top-sharebar-wrapper').data('pb-prevent-ajax') && $(root).find('.vertical-sticky-top-sharebar').size() == 0) {
            		var contentUriPath = $(root).find('.top-sharebar-wrapper').data('pb-canonical-url');
            		if (contentUriPath.indexOf('.washingtonpost.com') >= 0) {
            			$.ajax({
	        	            url:'/pb/api/v2/render/feature',
	        	            dataType:'json',
	        	            data: {
	        	            	id: $(root)[0].id,
	        	                uri: window.location.pathname,
	        	                contentUri: contentUriPath,
	        	                desktop: TWPHead.desktop,
	        	                mobile: TWPHead.mobile
	        	            },
	        	            cache:true,
	        	            jsonCallback:'wpTopShareBarAjax',
	        	            success:function(data) {
	        	            	$(root).empty();
	        	            	$(root).append($(data.rendering).children());
	        	            	socialTools.originalInit();
	        	            },
	        	            error:function(data){
	        	            	socialTools.originalInit();
	        	            }
	        	        });
            		} else {
            			socialTools.originalInit();
            		}
            		$(root).find('.top-sharebar-wrapper').data('pb-prevent-ajax','true');
            	} else {
            		socialTools.originalInit();
            	}
            });
        },
        originalInit: function(myRoot) {
            var self = this;
            myRoot = myRoot || this.myRoot;
            $myRoot = $(myRoot);

            //handle sticky behavior
            if ($myRoot.hasClass('sticky-top-sharebar')) {
            	stickyHorizontalShareBar.init();
            }

            $myRoot.each(function(index, myRootElement) {
            	//handle vertical-sticky behavior for each element that is vertical-sticky
            	if ($(myRootElement).hasClass('vertical-sticky-top-sharebar')) {
            		stickyVerticalShareBar.init($(myRootElement));
            	}
                if (wp_pb.StaticMethods.staticPostShare) {
                    wp_pb.StaticMethods.staticPostShare.init($(myRootElement), $(myRootElement).data('postshare'));
                }
                var $root = $(myRootElement),
                    $individualTool = $('.tool:not(.more, .read-later-bookmark, .read-later-list)', $root),
                    $socialToolsWrapper = $('.social-tools-wrapper', $root),
                    $socialToolsMoreBtn = $('.tool.more', $socialToolsWrapper),
                    $socialToolsAdditional = $('.social-tools-additional', $root),
                    width = (window.innerWidth > 0) ? window.innerWidth : screen.width,
                    isMobile = (mobile_browser === 1 && width < 480) ? true : false;

                $socialToolsMoreBtn.off('click').on('click', this, function(ev) {
                    $socialToolsMoreBtn.hide();
                    $socialToolsAdditional.show('fast', function(ev) {
                        $root.addClass("expanded");
                        $('.social-tools', $socialToolsAdditional).animate({
                            "margin-left": 0
                        }, 4250);
                    }).addClass('more-open'); //end addtl show
                }); //end more click
                $individualTool.bind({
                    click: function(event) {
                        //event.stopPropagation();
                        var shareType = $(this).attr('class');
                        shareType = (typeof shareType != 'undefined') ? shareType.split(" ")[0].trim() : '';
                        self.trackTraffic('share.' + shareType, shareType + '_bar');
                    }
                });
                if (wp_pb && wp_pb.BrowserInfo && wp_pb.BrowserInfo.tablet) {
                    $root.addClass("tablet");
                }
                //vertical-sticky-top-sharebar has no mobile-view
                if (TWPHead.mobile && $root.find('.vertical-sticky-top-sharebar').size() > 0) {
                	var calcMobileIcons = function() {
                		var width = $root.find('.social-tools-wrapper').width()-5;
                		var shareIconWidth =  Math.ceil($root.find('.social-tools-primary .social-tools .tool').first().outerWidth(true));
                		$root.find('.social-tools-primary .social-tools .tool.more').hide();
                		var allShare  = $root.find('.social-tools-primary .social-tools .tool:not(.more), .social-tools-additional .social-tools .tool').hide();
                		if ($root.find('.social-tools-readlater').length > 0) {
                			width = width-Math.ceil($root.find('.social-tools-readlater').width());
                		}
                		var numShare = Math.floor(width/shareIconWidth);
                		for (var int = 0; int < allShare.length; int++) {
                			try {
                				if (int < numShare) {
                					$(allShare.get(int)).fadeIn();
                				} else {
                					$(allShare.get(int)).hide();
                				}
                			} catch (e) {
                			}
                		}
                	}
                	$( window ).resize(function() {
                		calcMobileIcons();
                	});
                	calcMobileIcons();
                } else {
                	$root.find('.social-tools-primary .social-tools .tool').fadeIn();
                }
                $root.removeClass("unprocessed");
            });
            if (typeof wp_pb.StaticMethods.initReadLater == 'function'){
            	wp_pb.StaticMethods.initReadLater($myRoot, 'top-share-bar');
            }
        },
        trackTraffic: function(name, eVar27) {
            if (typeof window.sendDataToOmniture === 'function') {
                var omnitureVars = {
                    "eVar1": (typeof window.s == 'object') && s && s.eVar1,
                    "eVar2": (typeof window.s == 'object') && s && s.eVar2,
                    "eVar8": (typeof window.s == 'object') && s && s.eVar8,
                    "eVar17": (typeof window.s == 'object') && s && s.eVar17,
                    "eVar27": eVar27
                };
                try {
                    sendDataToOmniture(name, 'event6', omnitureVars);
                } catch (e) {}
            }
        }
    };

    var stickyVerticalShareBar = {
    		init : function($myRoot) {
    			$myRoot.closest('.pb-f-sharebars-top-share-bar').insertBefore('#pb-root');
    			if (window.innerWidth > 992) {
    				//center vertically [+25px for half the header-v2]
	    			$myRoot.css({top: (($(window).height()-$myRoot.outerHeight()+25)/2)+'px'});
	    			$myRoot.animate({left: '-1px'});
	    			$(window).resize(function() {
	    				$myRoot.animate({top: (($(window).height()-$myRoot.outerHeight()+25)/2)+'px'},50);
	    			});
    			}
    			
                //handle content collision
                stickyVerticalShareBar.enableCollisionDetection($myRoot);
                wp_pb.register('sticky-vertical-sharebar', 'collides_with_main_content', function(collides) {
                    $myRoot.closest('.pb-f-sharebars-top-share-bar').css('opacity', collides ? '0' : '');
                });

    			//handle magnet strip
    			wp_pb.register('magnet', 'start_open', function(){
    				$myRoot.animate({top: (($(window).height()-$myRoot.outerHeight()+$('.pb-f-page-magnet .pb-module-area').height()+25)/2)+'px'},50);
    			});
    			wp_pb.register('magnet', 'start_close', function(){
    				$myRoot.animate({top: (($(window).height()-$myRoot.outerHeight()+25)/2)+'px'},50);
    			});
    			
    			//handle left-side hamburger menu
    			wp_pb.register('nav', 'menu_start_open', function(){
    				$myRoot.hide();
    				$myRoot.css('left', '-' + $myRoot.outerWidth() + 'px');
    			});
    			wp_pb.register('nav', 'menu_finish_close', function(){
    				if (window.innerWidth > 992) {
	    				setTimeout(function(){
	    					$myRoot.show();
	        				$myRoot.animate({left: '-1px'});
	    				}, 100);
    				}
    			});
    		},
            enableCollisionDetection: function(supported) {
                var INTERVAL_MS = 600;
                var MAX_INTERVALS = 3;
                var intervalCount = 0;

                return function($myRoot) {
                    var job;

                    if (!supported || intervalCount > MAX_INTERVALS) return;

                    job = setInterval(function() {
                        var $sb = $myRoot.closest('.pb-f-sharebars-top-share-bar');
                        var $sbw = $sb.find('.top-sharebar-wrapper');
                        var $mc = $('html').hasClass('gallery_story') ? $('.pb-f-gallery-gallery') : $('#main-content');
                        var oldcollides = $sb.data('__mccollides');
                        var newcollides = { 'value': undefined };

                        if ( !$sb.length || !$sbw.length || !$mc.length ) {
                            // kill interval since document no longer supports this feature
                            clearInterval(job);
                        } else {
                            newcollides.value = collision($mc[0], $sbw[0]);

                            if ( !oldcollides || newcollides.value !== oldcollides.value ) {
                                wp_pb.report('sticky-vertical-sharebar', 'collides_with_main_content', newcollides.value);
                                $sb.data('__mccollides', { 'value': newcollides.value });
                            }
                        }
                    }, INTERVAL_MS);

                    intervalCount++;

                    function collision(element1, element2) {
                        var rect1 = element1.getBoundingClientRect(),
                            rect2 = element2.getBoundingClientRect();

                        return !(
                            rect1.top > rect2.bottom ||
                            rect1.right < rect2.left ||
                            rect1.bottom < rect2.top ||
                            rect1.left > rect2.right
                        );
                    }
                }
            }( 'getBoundingClientRect' in document.documentElement )
    };

    var stickyHorizontalShareBar = {
        setElmTop: function($sharebarElm, y) {
            var style = y? 'translate3d(0px, ' + y + 'px, 0px)':'initial';
            $sharebarElm.css({
                'transform': style
            });
        },
        navMenuToggle: function($sharebarElm) {
            wp_pb.register('nav', 'finish_open', function() {
                this.setElmTop($sharebarElm, 0);
            }, this);
            wp_pb.register('nav', 'finish_close', function() {
                this.setElmTop($sharebarElm, -50);
            }, this);
            wp_pb.register('magnet', 'start_open', function() {
                //this.setElmTop($sharebarElm, 115);
            }, this);
        },
        fixedPosition: function($sharebarElm, sharebarTop) {
            var currentTop = $(window).scrollTop();
            if (currentTop > sharebarTop) {
                if (!$sharebarElm.hasClass('top-sharebar-fixed')) {
                    $sharebarElm.addClass('top-sharebar-fixed');
                    wp_pb.report('sticky-top-sharebar', 'sharebar_fixed', true);
                }
            } else {
                $sharebarElm.removeClass('top-sharebar-fixed');
                wp_pb.report('sticky-top-sharebar', 'sharebar_unfixed', true);
            }

            if ($(".shareBar-follow-modal").css('display') == 'block') {
                if ($('#wp-header').height() > 0) {
                    $(".shareBar-follow-modal").addClass('fixedModalNav').removeClass('fixedModal');
                } else {
                    $(".shareBar-follow-modal").addClass('fixedModal').removeClass('fixedModalNav');
                }
            }
        },
        moveOutOfRoot: function($sharebarElm) {
            //This is hacky!! Have to move leaderboard and sharebar outside of pb-root if it has max-width.
            var $pbRoot = $('#pb-root');
            if ($pbRoot.css('max-width') !== 'none') {
                var $sharebarRoot = $sharebarElm.parent();
                var $leaderboard = $('.pb-f-ad-leaderboard');
                $sharebarRoot.find('.sticky-top-sharebar').css('padding-top', '55px');
                $pbRoot.before($sharebarRoot);
                $pbRoot.before($leaderboard);
            }
        },
        detectMobileForSMS: function() {
            if (mobile_browser) {
                var shareString = '';
                if (windows_browser) {
                    shareString = 'sms://?body=';
                } else if (android_browser || android233_browser) {
                    shareString = 'sms:?body=';
                }

                if (shareString.length > 0) {
                    $('.pb-f-sharebars-top-share-bar .sms-share-device.unprocessed').each(function() {
                        $(this).attr('onclick', $(this).attr('onclick').replace(/sms:\?&body=/g, shareString));
                        $(this).removeClass('unprocessed');
                    });
                } else {
                    //iOS is used as default and does not require change
                    $('.pb-f-sharebars-top-share-bar .sms-share-device.unprocessed').removeClass('unprocessed');
                }
            }
        },
        init: function() {
            var $sharebarElm = $('.sticky-top-sharebar'),
                self = this;
            if (!$sharebarElm.length) return;
            this.moveOutOfRoot($sharebarElm);
            var sharebarTop = $sharebarElm.offset().top;
            var $header = $('#wp-header');
            if ($header.css('position') === 'fixed' && $(window).scrollTop() > sharebarTop) {
                this.fixedPosition($sharebarElm, sharebarTop);
            }
            $(window).off('scroll.sharebar').on('scroll.sharebar', function() {
                self.fixedPosition($sharebarElm, sharebarTop);
            });
            $(document).ready(function() {
                self.navMenuToggle($sharebarElm);
            });

            this.detectMobileForSMS();
        }
    };

    var userId = ((document.cookie.match(/wapo_login_id=([^;]+)/)) ? RegExp.$1 : '');
    var userSecureId = ((document.cookie.match(/wapo_secure_login_id=([^;]+)/)) ? RegExp.$1 : '');
    var userAgent = navigator.userAgent;

    var follow = {

        init: function() {

            var userSignedIn = (userId !== '') ? true : false,
                userApiUrl = "",
                jsonData = {},
                getUserData = true,
                followed = []; // Check which categories are followed

            $("#shareBar-follow").removeClass('hide');

            // Get user data
            if (userSignedIn) {
                userApiUrl = "https://follow.washingtonpost.com/Follow/api/user";
                jsonData = {
                    washPostId: userId,
                    wapoLoginID: userId,
                    wapoSecureID: userSecureId,
                    userAgent: userAgent
                };
            } else if (localStorage.getItem('wp_follow_modal_email')) {
                userApiUrl = "https://follow.washingtonpost.com/Follow/api/anonymous-user"; // TO DO change
                jsonData = {
                    emailId: localStorage.getItem('wp_follow_modal_email')
                };
            } else {
                getUserData = false; // Unanimous user, no data to fetch
            }

            if (getUserData) {

                $.ajax({
                    type: 'POST',
                    url: userApiUrl,
                    contentType: 'application/json',
                    dataType: 'json',
                    data: JSON.stringify(jsonData),
                    success: function(data) {
                        if (data.emailId) {
                            localStorage.setItem('wp_follow_modal_email', data.emailId);
                        }

                        if (data.tags) {
                            for (var i = 0, len = data.tags.length; i < len; i++) {
                                if (data.tags[i].type === 'category') {
                                    followed.push(data.tags[i].slug);
                                }
                            }
                        }

                        if (followed.indexOf($("#subtitle-follow").data('categorySlug')) >= 0) {
                            $("#shareBar-follow").addClass('following');
                            $("#shareBar-follow .followLbl").text('Following');
                        }
                    }
                });
            }

            // Click follow button
            $("#shareBar-follow").on('click', function() {
                var $this = $(this);
                var endpoint = ($this.hasClass('following') ? 'unfollow' : 'follow'),
                    categorySlug = $this.data('categorySlug'),
                    categoryTitle = $this.data('categoryTitle'),
                    position = {};

                position.top = 55;
                position.left = 650;

                function applyCallBack(data) {
                    // change button text
                    if (endpoint === 'follow')
                        $this.addClass('following').find('.followLbl').text('Following');
                    else
                        $this.removeClass('following').find('.followLbl').text('Follow');

                    // send omniture events
                    if (endpoint === 'follow') {
                        s.sendDataToOmniture('Follow', 'event103', {
                            eVar1: s.eVar1,
                            eVar2: s.eVar2,
                            eVar26: 'fl_sharebar_topic_' + categorySlug.replace(/-/g, '')
                        });
                    } else {
                        s.sendDataToOmniture('Unfollow', 'event104', {
                            eVar1: s.eVar1,
                            eVar2: s.eVar2,
                            eVar26: 'fl_sharebar_topic_' + categorySlug.replace(/-/g, '')
                        });
                    }
                }

                var data = {
                    categorySlug: categorySlug,
                    categoryTitle: categoryTitle,
                    signedIn: userSignedIn,
                    endpoint: endpoint,
                    callBack: applyCallBack
                };

                // Follow
                if (endpoint === 'follow') {
                    data.position = position;

                    if (localStorage.getItem('wp_follow_modal_seen') !== 'true' || !localStorage.getItem('wp_follow_modal_email')) {
                        var tagData = {
                            "tag": {
                                "slug": categorySlug,
                                "type": "category"
                            }
                        };

                        // Get pip description: TO DO this will be moved to site service later
                        $.ajax({
                            type: 'POST',
                            url: "https://follow.washingtonpost.com/Follow/api/tag",
                            contentType: 'application/json',
                            dataType: 'json',
                            data: JSON.stringify(tagData),
                            success: function(result) {
                                data.categoryDesc = result.tag.description;
                                follow.displayPip(data);
                            },
                            error: function(reason) {
                                follow.displayPip(data);
                            }
                        });
                    } else {
                        data.email = localStorage.getItem('wp_follow_modal_email');

                        follow.followApi(data);
                    }
                } else { // Unfollow
                    follow.unfollowApi(data);
                }

                return false;
            });

            if (typeof Hammer === 'function' && wp_pb.BrowserInfo.mobile_browser) {
                try {
                    var hammertime = new Hammer($('#shareBar-follow')[0], {
                        prevent_mouseevents: true
                    });
                    hammertime.on("tap", handleTap);
                } catch (err) {}
            }

            /* hammer.js tap */

            function handleTap(ev) {
                ev.gesture.preventDefault();
                ev.gesture.stopPropagation();
                $(ev.gesture.target).click();
                $(ev.gesture.target).blur();
            }

        },

        displayPip: function(data) {

            var modal = $('.shareBar-follow-modal');

            if (data.signedIn === false) {
                modal.find('.not-signed-In.before').removeClass('hide');
                modal.find('.not-signed-In.after').addClass('hide');
                modal.find('.signed-In').addClass('hide');

                if (localStorage.getItem('wp_follow_modal_email')) {
                    modal.find('#follow-modal-input').val(localStorage.getItem('wp_follow_modal_email'));
                }
            } else {
                modal.find('.not-signed-In').addClass('hide');
                modal.find('.signed-In').removeClass('hide');

                data.position.top += 20;
            }

            modal.find('.category-desc').text(data.categoryDesc ? data.categoryDesc : "");

            // set correct position
            modal.css('top', data.position.top);
            modal.css('left', data.position.left);

            if ($('#wp-header').css('position') === 'fixed') {
                if ($('#wp-header').height() > 0) {
                    modal.addClass('fixedModalNav');
                } else {
                    modal.addClass('fixedModal');
                }
            }

            modal.jqm({
                overlayClass: 'sharebar-follow-modal',
                overlay: 0,
                onHide: function(hash) {
                    modal.find('.sign-up').off('click');
                    modal.find('.follow-modal-close').off('click');
                    modal.find('.got-it').off('click');

                    hash.w.hide() && hash.o && hash.o.remove();
                    return true;
                }
            });

            // Close modal
            modal.find('.sign-up').click(function() {
                var email = modal.find('#follow-modal-input').val();
                var re = /[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}/igm;

                if (email === '' || !re.test(email)) {
                    $(".invalid-email").show();
                } else {
                    $(".invalid-email").hide();
                    data.email = email;

                    localStorage.setItem('wp_follow_modal_email', email);

                    follow.followApi(data, function() {
                        modal.find('.not-signed-In.before').addClass('hide');
                        modal.find('.not-signed-In.after').removeClass('hide');
                    });
                }
            });

            modal.find('.follow-modal-close').click(function() {
                modal.jqmHide();
            });

            modal.find('.got-it').click(function() {
                modal.jqmHide();
            });

            if (data.signedIn) {
                follow.followApi(data, function() {
                    if (localStorage.getItem('wp_follow_modal_seen') !== 'true') {
                        modal.jqmShow();
                        localStorage.setItem('wp_follow_modal_seen', 'true');
                    }
                });
            } else {
                if (localStorage.getItem('wp_follow_modal_seen') !== 'true' || !localStorage.getItem('wp_follow_modal_email')) {

                    modal.jqmShow();

                    s.sendDataToOmniture('Follow', 'event101', {
                        eVar1: s.eVar1,
                        eVar2: s.eVar2,
                        eVar26: 'fl_sharebar_topic_' + data.categorySlug.replace(/-/g, '')
                    });

                    localStorage.setItem('wp_follow_modal_seen', 'true');
                } else {
                    data.email = localStorage.getItem('wp_follow_modal_email');

                    follow.followApi(data);
                }
            }
        },

        followApi: function(data, callBack) {
            var serviceBase = "https://follow.washingtonpost.com",
                jsonData = {
                    washPostId: userId,
                    tags: []
                };

            // user is not signed in
            if (data.email && data.signedIn === false) {
                serviceBase += "/Follow/api/anonymous-follow";

                jsonData.emailId = data.email;

                jsonData.tags = [{
                    slug: data.categorySlug,
                    type: 'category'
                }];
            } else {
                serviceBase += "/Follow/api/follow";

                jsonData.tags = [{
                    slug: data.categorySlug,
                    title: data.categoryTitle,
                    level: 1,
                    type: 'category'
                }];
            }

            $.ajax({
                type: 'POST',
                url: serviceBase,
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify(jsonData),
                success: function(result) {
                    if (result.status === true) {
                        data.callBack(data);
                        if (callBack) {
                            callBack();
                        }
                    }
                }
            });
        },

        unfollowApi: function(data) {
            var serviceBase = "https://follow.washingtonpost.com";

            var tags = [{
                slug: data.categorySlug,
                title: data.categoryTitle,
                level: 1,
                type: 'category'
            }];

            var jsonData = {
                washPostId: userId,
                wapoLoginID: userId,
                wapoSecureID: userSecureId,
                userAgent: userAgent,
                tags: tags
            };

            if (data.signedIn) {
                serviceBase += "/Follow/api/unfollow";
            } else {
                serviceBase += "/Follow/api/anonymous-unfollow";
                jsonData.emailId = localStorage.getItem('wp_follow_modal_email');
            }

            $.ajax({
                type: 'POST',
                url: serviceBase,
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify(jsonData),
                success: function(responce) {
                    if (responce.status === true && data.callBack)
                        data.callBack(responce);
                }
            });
        },

        localStorageAvailable: function() {
            var test = 'test';
            try {
                localStorage.setItem(test, test);
                localStorage.removeItem(test);
                return true;
            } catch (e) {
                return false;
            }
        }
    };

    /**
     * Utilities START
     * Note: Same code in sharebars\utlity-bar
     */
    var textResizer = {
	    currIncrementMax: 9,
	    currIncrementUnit: 2,
	    currIncrementIndex: 0,
	    init: function(myRoot, resizeableElementList, clickElement) {
	        myRoot = myRoot || '#article-body article, .related-story, .liveblog-intro, #liveblog-story-list .description, #full-recipe .article-content';
	        resizeableElementList = resizeableElementList || 'p, li';
	        clickElement = clickElement || '.tool.textresizer';
	        this.root = $(myRoot);
	        this.resizeableElements = $(resizeableElementList, this.root);

	        // add "Next up" lable to the resizable element's list
	        if ($(".related-story").prev('h3').length > 0) {
	            this.resizeableElements.push($('.related-story').prev('h3'));
	            this.resizeableElements.push($('.related-story h4 a'));
	        }
	        $(clickElement).on('click', this, this.resize);
	    },
	    resize: function(event) {
	        var currObj = event.data;
	        if (currObj.currIncrementIndex == currObj.currIncrementMax) {
	            currObj.currIncrementIndex = 0;
	            currObj.currIncrementUnit = (currObj.currIncrementUnit == 2) ? -2 : 2;
	        }
	        currObj.currIncrementIndex = currObj.currIncrementIndex + 1;
	        currObj.resizeableElements.each(function() {
	            elm = $(this);
	            currSize = parseFloat(elm.css('font-size'), 5);
	            var result = currSize + currObj.currIncrementUnit;
	            elm.css('font-size', result);
	            wp_pb.report('textresizer', 'resized', result);
	        });
	    }
	};

	var trackTraffic = function(name) {
	    if (typeof window.sendDataToOmniture === 'function') {
	        var omnitureVars = {
	            "eVar1": (typeof window.s == 'object') && s && s.eVar1,
	            "eVar2": (typeof window.s == 'object') && s && s.eVar2,
	            "eVar8": (typeof window.s == 'object') && s && s.eVar8,
	            "eVar17": (typeof window.s == 'object') && s && s.eVar17,
	            "eVar27": name
	        };
	        try {
	            sendDataToOmniture(name + '.click', 'event6', omnitureVars);
	        } catch (e) {}
	    }
	};
	$('.social-tools-wrapper .tool.textresizer, .social-tools-wrapper .tool.print').bind('click', function() {
	    var name = $(this).attr('class').split(" ")[0].trim();
	    trackTraffic(name);
	});

    /**
     * Utilities END
     */

    // Turn off the experience

    // $(window.document).on('abtest-ready', function(e, ABT) {

    //     var test = ABT.get('follow-powerPostTop');

    //     if (test.is('sharebar')) {
    //         follow.init();
    //     }
    // });

    window.TWP = TWP || {};
    TWP.SocialTools = TWP.SocialTools || socialTools;
    TWP.SocialTools.init();

    TWP.TextResizer = TWP.TextResizer || textResizer;
    TWP.TextResizer.init();

    var tablet = isMobile.tablet();

    window.VisitorSegment && VisitorSegment('tablet', function() {
        return (tablet && $(window).width() > 768);
    });

    /*
     * POPOUT code for later var $article = $('#article-topper'); // START:
     * Social share pop-out var $socialToolsMoreBtn = $('.social-tools
     * .more',$article), $socialToolsPopOut =
     * $('.social-tools.pop-out',$article) ;
     * $socialToolsMoreBtn.on('click',function(ev){ var targetTop =
     * $socialToolsMoreBtn.position().top +
     * $socialToolsMoreBtn.outerHeight()-1-14; var targetLeft =
     * $socialToolsMoreBtn.position().left-1-3;
     * $socialToolsPopOut.css({"top":targetTop,"left":targetLeft});
     * $socialToolsPopOut.toggle(); });
     * $socialToolsPopOut.on('mouseout',function(ev){
     * $socialToolsPopOut.toggle(); }); // END: Social share pop-out
     */

  } catch (err) {
  }
})();

(function($,TWP,undefined){var AD_LOAD_TIMER=2E3;var AD_MIN_VISIBLE=4E3;var AD_HEIGHT_LIMITED=150;var ANIM_SPEED=250;var console=new TWP.Tools.logger("leaderboard");if($(".layout_article #pb-root .pb-f-ad-leaderboard.full").length){var $leaderboard=$(".pb-f-ad-leaderboard");$("#pb-root").before($leaderboard)}var applyStickiness=function(){var isLoginUser=document.cookie.match(/wapo_secure_login_id=([^;]+)/)?RegExp.$1:"";if(wp_pb.BrowserInfo&&wp_pb.BrowserInfo.tablet||isLoginUser)return;$(function(){var $html=
$("html"),$feature=getFeature().find(".leaderboard"),$window=$(window),timer,slotId="slug_leaderboard",$slotAd=$feature.find("#"+slotId),$closeBtn=$feature.find(".leaderboard-close");if(!$feature.length)return;function removeSticky(){setTimeout(function(){console.log("remove sticky leaderboard.");$feature.slideUp(ANIM_SPEED,function(){$html.removeClass("lb-persist-top-true");$feature.slideDown(ANIM_SPEED)})},AD_MIN_VISIBLE)}function applySticky(){if($window.scrollTop()>100)$html.addClass("lb-persist-top-true");
else $html.removeClass("lb-persist-top-true")}function bindEvents(){$window.on("scroll.lb-sticky",function(e){e.stopPropagation();applySticky();var bnbHeight=$(".pb-f-page-breaking-news-bar .breaking-news-bar").outerHeight();if(bnbHeight>0){$feature.addClass("pb-has-breaking-news");$feature.css("margin-top",bnbHeight+"px");wp_pb.register("breakingnews","close",function(){$feature.removeClass("pb-has-breaking-news");$feature.css("margin-top","")})}});wp_pb.register("nav","finish_open",function(){$feature.removeClass("pb-navheader-hidden")});
wp_pb.register("nav","finish_close",function(){$feature.addClass("pb-navheader-hidden")});$closeBtn.on("click.lb-sticky",function(e){AD_MIN_VISIBLE=0;afterLoaded();if(typeof window.sendDataToOmniture==="function"){var data={pageName:window.wp_page_name,eVar1:window.wp_page_name,prop2:window.wp_subsection,eVar2:window.wp_channel,prop3:window.wp_content_type,eVar17:window.wp_content_type,eVar26:"leaderboard-close"};sendDataToOmniture("leaderboard-close","event80",data)}})}function afterLoaded(){var $featureContainer=
getFeature();if($feature.height()>$featureContainer.outerHeight())$featureContainer.height($feature.height()+30);$feature.addClass("leaderboard-ad-loaded");$window.off("scroll.lb-sticky");if($html.hasClass("lb-persist-top-true"))removeSticky()}function afterAdInserted(){timer=setTimeout(function(){console.log("from second timeout: prevent ad load fail.");afterLoaded()},7E3);if(window.googletag&&googletag.pubadsReady)googletag.pubads().addEventListener("slotRenderEnded",function(event){console.log("ad slot: "+
event.slot.getSlotElementId()+" inserted success");if(event.slot.getSlotElementId()===slotId){clearTimeout(timer);setTimeout(function(){console.log("leaderboard ad load success.");afterLoaded()},AD_LOAD_TIMER)}})}applySticky();bindEvents();setTimeout(function(){$closeBtn.addClass("fa-remove")},8E3);if($slotAd.children().length)timer=setTimeout(function(){console.log("from first timeout: if ad is already loaded");afterLoaded()},AD_LOAD_TIMER);$feature.on("DOMNodeInserted",function(e){var $el=$(e.target),
id=$el.attr("id");if($el.is("iframe")&&id&&!/(hidden)/g.test(id)){clearTimeout(timer);$feature.off("DOMNodeInserted");afterAdInserted()}});$feature.on("disableSticky.lb-sticky",function(e){clearTimeout(timer);$window.off("scroll.lb-sticky");$feature.off("DOMNodeInserted");$html.removeClass("lb-persist-top-true");TWP.Features.Ad.Leaderboard.sticky=false})})};if(!!TWP.Features.Ad.Leaderboard.sticky)applyStickiness();if(!!TWP.Features.Ad.Leaderboard.belowSharebar)applySharebarPosition();$(window.document).on("abtest-ready",
function(e,ABT){var test=ABT.get("ads-leaderboard");getFeature().attr("moat-test-id",[getFeature().attr("moat-id")||"unknown/unknown",test.name||"control"].join("-"));if(test.is("below_sharebar"))applySharebarPosition();if(test.is("sticky"))applyStickiness()});function applySharebarPosition(){var $leaderboard=getFeature();var $shareBar=getSharebar();$leaderboard.addClass("after-sharebar-leaderboard");return $leaderboard.insertAfter($shareBar)}function getFeature(){return $(".pb-f-ad-leaderboard")}
function getSharebar(){return $(".pb-f-sharebars-top-share-bar")}})(jQuery,TWP);
(function($){try{var $w=$(window);var feature={remarryHeadlines:function(){var remarryHeadlinesSelector=".pb-f-article-article-topper h1";try{wp_pb.StaticMethods.remarryHeadline(remarryHeadlinesSelector)}catch(e){}},init:function(){this.remarryHeadlines()}};var userId=document.cookie.match(/wapo_login_id=([^;]+)/)?RegExp.$1:"";var userSecureId=document.cookie.match(/wapo_secure_login_id=([^;]+)/)?RegExp.$1:"";var userAgent=navigator.userAgent;if($("#article-topper #slug_tiffany_tile:visible").length){$("#topper-headline-wrapper").addClass("col-sm-8").removeClass("col-sm-12");
$("#topper-headline-wrapper").addClass("col-lg-9").removeClass("col-lg-12")}function initAlignToggle(){if($(".header-tool")!==undefined&&$(".header-tool").length>0)if($(".header-tool").position().left==0)$(".header-tool").css("margin-left","0");else $(".header-tool").css("margin-left","30px")}initAlignToggle();$(window).resize(initAlignToggle);var langdivs=$('span[id^\x3d"translate-text-"]').hide(),divi=0;(function cycle(){langdivs.eq(divi).fadeIn("slow").delay(3E3).fadeOut("slow",cycle);divi=++divi%
langdivs.length})();function initToggle(){var $toggleOption=$(".header-wp-language-button");$toggleOption.click(function(e){var $this=$(".header-lang-dropdown");if($this.hasClass("wp-language-button-clicked")){$this.removeClass("wp-language-button-clicked");$toggleOption.removeClass("wp-language-button-clicked-wrapper");$(".header-tool").removeClass("header-tool-selected")}else{$this.addClass("wp-language-button-clicked");$toggleOption.addClass("wp-language-button-clicked-wrapper");$(".header-tool").addClass("header-tool-selected")}});
$(document).click(function(e){var target=e.target;if(!$(target).is(".header-wp-language-button")&&!$(target).parents().is(".header-wp-language-button")){$(".header-lang-dropdown").removeClass("wp-language-button-clicked");$(".header-wp-language-button").removeClass("wp-language-button-clicked-wrapper");$(".header-tool").removeClass("header-tool-selected")}})}initToggle();var follow={init:function(){var userSignedIn=userId!==""?true:false,userApiUrl="",jsonData={},getUserData=true,followed=[];$("#subtitle-follow").removeClass("hide");
if(userSignedIn){userApiUrl="https://follow.washingtonpost.com/Follow/api/user";jsonData={washPostId:userId,wapoLoginID:userId,wapoSecureID:userSecureId,userAgent:userAgent}}else if(follow.localStorageAvailable()&&localStorage.getItem("wp_follow_modal_email")){userApiUrl="https://follow.washingtonpost.com/Follow/api/anonymous-user";jsonData={emailId:localStorage.getItem("wp_follow_modal_email")}}else getUserData=false;if(getUserData)$.ajax({type:"POST",url:userApiUrl,contentType:"application/json",
dataType:"json",data:JSON.stringify(jsonData),success:function(data){if(follow.localStorageAvailable()&&data.emailId)localStorage.setItem("wp_follow_modal_email",data.emailId);if(data.tags)for(var i=0,len=data.tags.length;i<len;i++)if(data.tags[i].type==="category")followed.push(data.tags[i].slug);if(followed.indexOf($("#subtitle-follow").data("categorySlug"))>=0){$("#subtitle-follow").addClass("following");$("#subtitle-follow .followLbl").text("Following")}}});$("#subtitle-follow").on("click",function(){var $this=
$(this);var endpoint=$this.hasClass("following")?"unfollow":"follow",categorySlug=$this.data("categorySlug"),categoryTitle=$this.data("categoryTitle"),position={};position.top=35;position.left=485;function applyCallBack(data){if(endpoint==="follow")$this.addClass("following").find(".followLbl").text("Following");else $this.removeClass("following").find(".followLbl").text("Follow");if(endpoint==="follow")s.sendDataToOmniture("Follow","event103",{eVar1:s.eVar1,eVar2:s.eVar2,eVar26:"fl_top_topic_"+categorySlug.replace(/-/g,
"")});else s.sendDataToOmniture("Unfollow","event104",{eVar1:s.eVar1,eVar2:s.eVar2,eVar26:"fl_top_topic_"+categorySlug.replace(/-/g,"")})}var data={categorySlug:categorySlug,categoryTitle:categoryTitle,signedIn:userSignedIn,endpoint:endpoint,callBack:applyCallBack};if(endpoint==="follow"){data.position=position;if(follow.localStorageAvailable()&&(localStorage.getItem("wp_follow_modal_seen")!=="true"||!localStorage.getItem("wp_follow_modal_email"))){var tagData={"tag":{"slug":categorySlug,"type":"category"}};
$.ajax({type:"POST",url:"https://follow.washingtonpost.com/Follow/api/tag",contentType:"application/json",dataType:"json",data:JSON.stringify(tagData),success:function(result){data.categoryDesc=result.tag.description;follow.displayPip(data)},error:function(reason){follow.displayPip(data)}})}else{data.email=follow.localStorageAvailable()?localStorage.getItem("wp_follow_modal_email"):"";follow.followApi(data)}}else follow.unfollowApi(data);return false});if(typeof Hammer==="function"&&wp_pb.BrowserInfo.mobile_browser)try{var hammertime=
new Hammer($("#subtitle-follow")[0],{prevent_mouseevents:true});hammertime.on("tap",handleTap)}catch(err){}function handleTap(ev){ev.gesture.preventDefault();ev.gesture.stopPropagation();$(ev.gesture.target).click();$(ev.gesture.target).blur()}},displayPip:function(data){var modal=$(".subTitle-follow-modal");if(data.signedIn===false){modal.find(".not-signed-In.before").removeClass("hide");modal.find(".not-signed-In.after").addClass("hide");modal.find(".signed-In").addClass("hide");if(follow.localStorageAvailable()&&
localStorage.getItem("wp_follow_modal_email"))modal.find("#follow-modal-input").val(localStorage.getItem("wp_follow_modal_email"))}else{modal.find(".not-signed-In").addClass("hide");modal.find(".signed-In").removeClass("hide");data.position.top+=20}modal.find(".category-desc").text(data.categoryDesc?data.categoryDesc:"");modal.css("top",data.position.top);modal.css("left",data.position.left);modal.jqm({overlayClass:"article-topper-follow-modal",overlay:0,onHide:function(hash){modal.find(".sign-up").off("click");
modal.find(".follow-modal-close").off("click");modal.find(".got-it").off("click");hash.w.hide()&&hash.o&&hash.o.remove();return true}});modal.find(".sign-up").click(function(){var email=modal.find("#follow-modal-input").val();var re=/[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}/igm;if(email==""||!re.test(email))$(".invalid-email").show();else{$(".invalid-email").hide();data.email=email;if(follow.localStorageAvailable())localStorage.setItem("wp_follow_modal_email",email);follow.followApi(data,function(){modal.find(".not-signed-In.before").addClass("hide");
modal.find(".not-signed-In.after").removeClass("hide")})}});modal.find(".follow-modal-close").click(function(){modal.jqmHide()});modal.find(".got-it").click(function(){modal.jqmHide()});if(data.signedIn)follow.followApi(data,function(){if(follow.localStorageAvailable()&&localStorage.getItem("wp_follow_modal_seen")!=="true"){modal.jqmShow();localStorage.setItem("wp_follow_modal_seen","true")}else modal.jqmShow()});else if(follow.localStorageAvailable()&&(localStorage.getItem("wp_follow_modal_seen")!==
"true"||!localStorage.getItem("wp_follow_modal_email"))){modal.jqmShow();s.sendDataToOmniture("Follow","event101",{eVar1:s.eVar1,eVar2:s.eVar2,eVar26:"fl_top_topic_"+data.categorySlug.replace(/-/g,"")});localStorage.setItem("wp_follow_modal_seen","true")}else{if(follow.localStorageAvailable())data.email=localStorage.getItem("wp_follow_modal_email");follow.followApi(data)}},followApi:function(data,callBack){var serviceBase="https://follow.washingtonpost.com",jsonData={washPostId:userId,tags:[]};if(data.email&&
data.signedIn==false){serviceBase+="/Follow/api/anonymous-follow";jsonData.emailId=data.email;jsonData.tags=[{slug:data.categorySlug,type:"category"}]}else{serviceBase+="/Follow/api/follow";jsonData.tags=[{slug:data.categorySlug,title:data.categoryTitle,level:1,type:"category"}]}$.ajax({type:"POST",url:serviceBase,contentType:"application/json",dataType:"json",data:JSON.stringify(jsonData),success:function(result){if(result.status==true){data.callBack(data);if(callBack)callBack()}}})},unfollowApi:function(data){var serviceBase=
"https://follow.washingtonpost.com";var tags=[{slug:data.categorySlug,title:data.categoryTitle,level:1,type:"category"}];var jsonData={washPostId:userId,wapoLoginID:userId,wapoSecureID:userSecureId,userAgent:userAgent,tags:tags};if(data.signedIn)serviceBase+="/Follow/api/unfollow";else{serviceBase+="/Follow/api/anonymous-unfollow";jsonData.emailId=localStorage.getItem("wp_follow_modal_email")}$.ajax({type:"POST",url:serviceBase,contentType:"application/json",dataType:"json",data:JSON.stringify(jsonData),
success:function(responce){if(responce.status==true&&data.callBack)data.callBack(responce)}})},localStorageAvailable:function(){var test="test";try{localStorage.setItem(test,test);localStorage.removeItem(test);return true}catch(e){return false}}};var tablet=isMobile.tablet();window.VisitorSegment&&VisitorSegment("tablet",function(){return tablet&&$(window).width()>768});window._essentials_onrender=function(Essentials){var $target=$("#essentials-topper");var name=Essentials.name;var data=Essentials.data;
var pdata=Essentials.getPersistentData();var status=pdata[Essentials.contentPath];var count=!!name&&!!data?data.results.length:undefined;var tcount;if(!!Essentials.name&&$(".cf-essentials-module").length!=0){$target.show();$(function(){if(count){switch(count){case 1:tcount="One";break;case 2:tcount="Two";break;case 3:tcount="Three";break;case 4:tcount="Four";break;case 5:tcount="Five";break;default:tcount="";break}$(('\x3ch2\x3e\x3cspan class\x3d"status vg-check status-icon status-%s"\x3e\x3c/span\x3e '+
'\x3cspan class\x3d"status-count"\x3e'+tcount+" Essentials\x3c/span\x3e "+'\x3cspan class\x3d"status-kicker"\x3e%k\x3c/span\x3e'+"\x3c/h2\x3e").replace("%s","undefined"==typeof status?"scroll":"read").replace("%k",data.kicker.text)).appendTo($target);$target.on("click.essentials-topper",function(e){wp_pb.report("essentials-topper","click",{$target:$target});wp_pb.report("essentials","scrollto",{$from:$target})})}})}}}catch(err){}})(jQuery);
(function($){})(jQuery);
(function($){var $article=$("#article-body"),$d=$(document),$w=$(window),$b=$("body");if($(".layout_article #pb-root .pb-f-article-article-topper .headline-kicker").length){var $kicker=$(".pb-f-article-article-topper .headline-kicker").clone();$(".layout_article #pb-root .pb-f-article-article-body .pb-timestamp").before($kicker)}window.cr_on=false;$("iframe[data-src]",$article).each(function(i){var $this=$(this);$this.attr("src",$this.attr("data-src"))});$("#about-the-authors").click(function(e){var $this=
$(this);var $container=$this.closest(".multi-author-bio");if(!!$container){if($container.hasClass("open"))$container.removeClass("open").addClass("closed");else $container.removeClass("closed").addClass("open");wp_pb.report("global","domChanged")}});var $tables=$("div.extra table",$article);$tables.each(function(){var $table=$(this),$bars=$(".barchart",$table),longestBar=0;$bars.each(function(i){var $bar=$(this),w=$bar.attr("width");if(!isNaN(w)){w=w*1;longestBar=w>longestBar?w:longestBar}});$bars.each(function(i){var $bar=
$(this),w=$bar.attr("width");if(!isNaN(w)){w=w*1;var scale=$article.width()>480?.85:.75;relativeWidth=scale*(Math.ceil(100*(w/longestBar)*100)/100);$bar.css("width",relativeWidth+"%")}})});$(".pb-f-gallery-gallery",$article).each(function(i){var $gallery=$(this).children("div:first");var $gtitle=$gallery.attr("data-title");var $gurl=$gallery.attr("data-permalink");var $guuid=$gallery.attr("data-uuid");if($gurl.indexOf("js.")>-1)var $gurl=$gurl.replace("js.","www.");var $genctitle=encodeURI($gtitle);
var $gencurl=encodeURI($gurl);var $gmain=$gallery.find(".wp-volt-gal-main");var $gheadline=$gallery.find(".wp-volt-gal-embed-promo-top");var $gpromotop=$gallery.find(".wp-volt-gal-embed-promo-top span.cell");if($gtitle&&$gurl){$gheadline.html('\x3ch3 class\x3d"promo-top-title"\x3e'+$gpromotop.html()+"\x3c/h3\x3e");var gshare='\x3cspan class\x3d"wp-article-sharing"\x3e\x3cspan class\x3d"wp-tooltip-button wp-article-embed"\x3e\x3cspan class\x3d"title"\x3eEmbed\x3c/span\x3e\x3ci class\x3d"fa fa-code icon-code"\x3e\x3c/i\x3e\x3cspan class\x3d"wp-tooltip"\x3e\x3cspan class\x3d"wp-sharing-copy"\x3e\x3cspan class\x3d"wp-sharing-copy-input-wrap"\x3e\x3cinput type\x3d"text" class\x3d"wp-sharing-copy-input" value\x3d"\x3ciframe width\x3d\'480\' height\x3d\'700\' scrolling\x3d\'no\' src\x3d\''+
$gurl+'?_template\x3dgallery-embed\' frameborder\x3d\'0\' webkitallowfullscreen mozallowfullscreen allowfullscreen\x3e\x3c/iframe\x3e"\x3e\x3c/span\x3e\x3cspan class\x3d"wp-sharing-copy-button"\x3eCopy\x3c/span\x3e\x3c/span\x3e\x3c/span\x3e\x3c/span\x3e\x3cspan class\x3d"wp-tooltip-button wp-article-social"\x3e\x3cspan class\x3d"title"\x3eShare\x3c/span\x3e\x3ci class\x3d"fa fa-share icon-share-alt"\x3e\x3c/i\x3e\x3cspan class\x3d"wp-tooltip"\x3e\x3ci class\x3d"wp-sharing-button fa fa-facebook icon-facebook"\x3e\x3c/i\x3e\x3ci class\x3d"wp-sharing-button fa fa-twitter icon-twitter"\x3e\x3c/i\x3e\x3ci class\x3d"wp-sharing-button fa fa-google-plus icon-google-plus"\x3e\x3c/i\x3e\x3ca class\x3d"wp-sharing-button-email" href\x3d"mailto:?subject\x3d'+
$genctitle+" from The Washington Post\x26body\x3d"+$gencurl+'%3Ftid\x3dss_mail"\x3e\x3ci class\x3d"fa fa-envelope"\x3e\x3c/i\x3e\x3c/a\x3e\x3c/span\x3e\x3c/span\x3e\x3c/span\x3e';$(gshare).insertAfter($gmain);var $facebook=$gallery.find(".fa-facebook");$facebook.click(function(){var shareWindow=window.open("https://www.facebook.com/sharer/sharer.php?u\x3d"+$gencurl+"%3Ftid\x3dss_fb","share_facebook","width\x3d658,height\x3d354,scrollbars\x3dno");return false});var $twitter=$gallery.find(".fa-twitter");
$twitter.click(function(){var shareWindow=window.open("https://twitter.com/share?url\x3d"+$gencurl+"%3Ftid\x3dss_tw\x26text\x3d"+$genctitle,"share_twitter","width\x3d550,height\x3d350,scrollbars\x3dno");return false});var $google=$gallery.find(".fa-google-plus");$google.click(function(){var shareWindow=window.open("https://plus.google.com/share?url\x3d"+$gencurl+"%3Ftid\x3dss_gp","share_google-plus","width\x3d832,height\x3d472,scrollbars\x3dno");return false});var $copybtn=$gallery.find(".wp-sharing-copy-button");
$copybtn.click(function(event){event.stopPropagation();$(event.currentTarget).parent().find(".wp-sharing-copy-input").select();try{document.execCommand("copy")}catch(err){}})}});function initToggle(){var $toggleOption=$(".wp-tooltip-button");$toggleOption.click(function(e){var $this=$(this);if($(e.target).is("span")||$(e.target).is("i.wp-sharing-button")||$(e.target).is("i.icon-envelope")||$(e.target).is("input")){e.preventDefault();return}else if($(this).hasClass("wp-tooltip-button-clicked"))$this.removeClass("wp-tooltip-button-clicked");
else{$toggleOption.filter(".wp-tooltip-button-clicked").removeClass("wp-tooltip-button-clicked");$this.addClass("wp-tooltip-button-clicked")}})}initToggle();var hasResizableIframe=false;$("iframe[width][height]",$article).each(function(i){var $iframe=$(this),w=$iframe.attr("width"),h=$iframe.attr("height");if(!isNaN(w)&&!isNaN(h)){$iframe.attr("data-aspect-ratio",w/h);if($iframe.attr("width")!=$article.width()){var hFudgeFactor=!!$iframe.attr("src")&&$iframe.attr("src").match(/instagram.com/)?40:
0;$iframe.attr("width",Math.round($article.width()));$iframe.attr("height",Math.round($article.width()/$iframe.attr("data-aspect-ratio"))+hFudgeFactor)}if(!hasResizableIframe){hasResizableIframe=true;$w.resize(function(ev){$("iframe[data-aspect-ratio]",$article).each(function(i){var $ifr=$(this);hFF=!!$iframe.attr("src")&&$iframe.attr("src").match(/instagram.com/)?40:0;$ifr.attr("width",Math.round($article.width()));$ifr.attr("height",Math.round($article.width()/$ifr.attr("data-aspect-ratio"))+hFF)})})}}});
$("audio").each(function(){if(!!$(this).find("source")[0]){var audioSrc=$(this).find("source")[0].src;var audioId=$(this)[0].id;$(this).replaceWith('\x3cdiv class\x3d"audio-wrapper" id\x3d"'+audioId+'"\x3e\x3caudio preload\x3d"none"\x3e\x3csource src\x3d"'+audioSrc+'" type\x3d"audio/mp3" /\x3e\x3ca href\x3d"'+audioSrc+'"\x3e'+audioSrc+'\x3c/a\x3e\x3c/audio\x3e\x3cdiv class\x3d"audio-player"\x3e\x3cdiv class\x3d"play-button play"\x3e\x3c/div\x3e\x3cdiv class\x3d"progress-bar"\x3e\x3cdiv class\x3d"elapsed-bar"\x3e\x3c/div\x3e\x3cdiv class\x3d"playhead"\x3e\x3c/div\x3e\x3cdiv class\x3d"time"\x3e \x3cspan class\x3d"elapsed-time"\x3e00:00\x3c/span\x3e / \x3cspan class\x3d"total-time"\x3e00:00\x3c/span\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e')}});
$(".audio-wrapper").each(function(){var $this=$(this);var $audio=$this.find("audio");var audio=$audio[0];var $audioPlayer=$this.find(".audio-player");var $playButton=$audioPlayer.find(".play-button");var $progressBar=$audioPlayer.find(".progress-bar");var $elapsedBar=$audioPlayer.find(".elapsed-bar");var $playhead=$audioPlayer.find(".playhead");var $time=$progressBar.find(".time");var $elapsedTime=$time.find(".elapsed-time");var $totalTime=$time.find(".total-time");var duration;$audio.on("loadedmetadata",
function(){duration=audio.duration;$totalTime.text(formatDuration(duration))});$audio.trigger("load");var playheadWidth=$playhead.outerWidth();var progressBarWidth=$progressBar.outerWidth();var progressBarLeft=$progressBar.offset().left;var firstPlayed=false;var dragging=false;var draggingWhilePaused=false;$playButton.click(function(){if(audio.paused){audio.play();$(this).removeClass("play").addClass("pause");if(firstPlayed==false){firstPlayed=true;$playhead.show()}}else{audio.pause();$(this).removeClass("pause").addClass("play")}});
$audio.on("timeupdate",audioUpdate);$w.on("resize",function(){progressBarWidth=$progressBar.outerWidth();progressBarLeft=$progressBar.offset().left;audioUpdate()});$progressBar.on("mousedown",function(e){if(e.which==1&&firstPlayed==true){e.preventDefault();dragging=true;if(audio.paused)draggingWhilePaused=true;else audio.pause();$w.on("mousemove",drag);$audio.off("timeupdate",audioUpdate)}});$w.on("mouseup",function(e){if(dragging==true){drag(e);$w.off("mousemove",drag);audio.currentTime=duration*
((e.pageX-progressBarLeft)/progressBarWidth);if(audio.currentTime>=duration){audio.pause();$playButton.removeClass("pause").addClass("play")}else if(!draggingWhilePaused)audio.play();$audio.on("timeupdate",audioUpdate)}dragging=false;draggingWhilePaused=false});function drag(e){var newLeft=e.pageX-progressBarLeft;if(newLeft>=0&&newLeft<=progressBarWidth){$playhead.css("left",newLeft-playheadWidth/2+"px");$elapsedBar.css("width",newLeft+"px")}if(newLeft<0){$playhead.css("left",-(playheadWidth/2)+"px");
$elapsedBar.css("width","0px")}if(newLeft>progressBarWidth){$playhead.css("left",progressBarWidth-playheadWidth/2+"px");$elapsedBar.css("width",progressBarWidth+"px")}}function audioUpdate(){var elapsedBarWidth=progressBarWidth*(audio.currentTime/duration);$playhead.css("left",elapsedBarWidth-playheadWidth/2+"px");$elapsedBar.css("width",elapsedBarWidth+"px");if(audio.currentTime>=duration)$playButton.removeClass("pause").addClass("play");$elapsedTime.text(formatDuration(audio.currentTime))}});function formatDuration(duration){sec=
Math.floor(duration);min=Math.floor(sec/60);min=min>=10?min:"0"+min;sec=Math.floor(sec%60);sec=sec>=10?sec:"0"+sec;return min+":"+sec}$article.find(".inline-video").each(function(){var $this=$(this);var $wpvPlayer=$this.find(".wpv-player");if($wpvPlayer.attr("data-show-caption")!=="1")$this.find(".inline-video-caption").show();else;});$(document).on("abtest-ready",function(e,ABT){if("article-politics"===wp_pb.pageName)politicsCrbtnTest();function politicsCrbtnTest(){var articleUuid=$('meta[name\x3d"eomportal-uuid"]').attr("content");
var version=ABT.get("politics-cr_button").name;var strVar="";if("b"==version){switch(articleUuid){case "e9cb3eaa-e544-11e5-bc08-3e03a5b41910":strVar+='\x3ca href\x3d"https://wapo.st/lookingforamerica2?tid\x3dlfa-b-1" class\x3d"normal cr_button-b"\x3e\x3cdiv class\x3d"navbox"\x3e';strVar+='\x3cimg src\x3d"https://www.washingtonpost.com/rf/image_358w/2010-2019/WashingtonPost/2016/03/15/National-Politics/Graphics/L4A_part2.jpg"\x3e';strVar+='\x3cp\x3eCome with us to New Hampshire to hear more voters\' answers.\x26nbsp;\x3ci class\x3d"fa  fa-arrow-right"\x3e\x3c/i\x3e\x3c/p\x3e';
strVar+="\x3c/div\x3e\x3c/a\x3e";break;case "c10b4b8a-e545-11e5-bc08-3e03a5b41910":strVar+='\x3ca href\x3d"https://wapo.st/lookingforamerica3?tid\x3dlfa-b-2" class\x3d"normal cr_button-b"\x3e\x3cdiv class\x3d"navbox"\x3e';strVar+='\x3cimg src\x3d"https://www.washingtonpost.com/rf/image_358w/2010-2019/WashingtonPost/2016/03/15/National-Politics/Graphics/L4A_part3.jpg"\x3e';strVar+='\x3cp\x3eCome with us South Carolina and Nevada to hear more voters\' answers.\x26nbsp;\x3ci class\x3d"fa  fa-arrow-right"\x3e\x3c/i\x3e\x3c/p\x3e';
strVar+="\x3c/div\x3e\x3c/a\x3e";break;case "be970d52-e546-11e5-bc08-3e03a5b41910":strVar+='\x3ca href\x3d"https://wapo.st/lookingforamerica4?tid\x3dlfa-b-3" class\x3d"normal cr_button-b"\x3e\x3cdiv class\x3d"navbox"\x3e';strVar+='\x3cimg src\x3d"https://www.washingtonpost.com/rf/image_358w/2010-2019/WashingtonPost/2016/03/15/National-Politics/Graphics/L4A_part4.jpg"\x3e';strVar+='\x3cp\x3eCome with us to Michigan, Texas, Kentucky and Arkansas to hear more voters\' answers.\x26nbsp;\x3ci class\x3d"fa  fa-arrow-right"\x3e\x3c/i\x3e\x3c/p\x3e';
strVar+="\x3c/div\x3e\x3c/a\x3e";break;default:}if(strVar)$article.find(".inline-html a.normal .navbox").parent().replaceWith(strVar)}else{switch(articleUuid){case "e9cb3eaa-e544-11e5-bc08-3e03a5b41910":strVar+="https://wapo.st/lookingforamerica2?tid\x3dlfa-default-1";break;case "c10b4b8a-e545-11e5-bc08-3e03a5b41910":strVar+="https://wapo.st/lookingforamerica3?tid\x3dlfa-default-2";break;case "be970d52-e546-11e5-bc08-3e03a5b41910":strVar+="https://wapo.st/lookingforamerica4?tid\x3dlfa-default-3";
break;default:}if(strVar)$article.find(".inline-html a.normal .navbox").parent().attr("href",strVar)}}});var inlineLinkConfig={ctx:"#article-body article",selector:'p a[href*\x3d"www\\.washingtonpost\\.com"]',param:"tid",getParamValue:function($link,ev){return this.param+"\x3da_inl"}};var inlineBioConfig={ctx:"#article-body article",selector:'.inline-content.author-bio a[href*\x3d"www\\.washingtonpost\\.com"]',param:"tid",getParamValue:function($link,ev){return this.param+"\x3da_bio"}};try{wp_pb.StaticMethods.parametrizeLinks.init([inlineLinkConfig,
inlineBioConfig])}catch(e){}var authorBioBoxHandler={init:function(){try{if(mobile_browser||$(window).width()<975)$(".pb-f-article-article-body .pb-author-wrapper").each(function(){var $this=$(this);if($this.find(".pb-author-modal-wrapper").length>0){$this.addClass("handle-as-mobile");var $modal=$this.find(".pb-author-modal-wrapper .slide-layer"),$otherModal=$this.siblings().find(".pb-author-modal-wrapper .slide-layer"),$modalWrapper=$this.find(".pb-author-modal-wrapper"),$closeBtn=$this.find(".pb-author-modal-wrapper .close-btn");
var modalFadeIn=function(ev){if($modal.is(":hidden")){modalFadeOut();ev.preventDefault();ev.stopPropagation();$modal.find(".pb-author-modal").css("width",window.innerWidth*.75+"px");$modalWrapper.css("margin-left","-"+$modal.outerWidth()/2+"px");$modal.show(200);$("body").on("click",modalFadeOut)}else if(ev.target.nodeName!="A"&&ev.target.nodeName!="IMG"){ev.preventDefault();ev.stopPropagation()}};var modalFadeOut=function(){$otherModal.hide(200);$modal.hide(200);$("body").off("click",modalFadeOut)};
$this.on("click",modalFadeIn);$closeBtn.on("click",modalFadeOut)}});else{$(".pb-f-article-article-body").prepend('\x3cdiv id\x3d"pb-article-body-author-modals"\x3e\x3c/div\x3e');$(".pb-f-article-article-body .pb-author-wrapper").each(function(){var $this=$(this);if($this.find(".pb-author-modal-wrapper").length>0){var $modal=$this.find(".pb-author-modal-wrapper .slide-layer"),transitionTimer,thisTop;$modal.appendTo($this.closest(".article-body").siblings("#pb-article-body-author-modals"));$this.add($modal).hover(function(ev){if(thisTop!=
$this.closest(".pb-sig-line").position().top){var top=0,left=0;if($(".pb-f-article-article-body .headshot-to-the-left").length>0){top=parseFloat($(".article-body").css("margin-top"))+$this.height()+$this.position().top+5;left=$this.position().left+20}else{top=parseFloat($(".article-body").css("margin-top"))+$this.position().top+$this.height()+5;left=$this.position().left+20}$modal.css({top:top+"px",left:left+"px"});thisTop=$this.closest(".pb-sig-line").position().top}if(transitionTimer){clearTimeout(transitionTimer);
transitionTimer=null}transitionTimer=setTimeout(function(){$modal.show(200)},100)},function(ev){if(transitionTimer){clearTimeout(transitionTimer);transitionTimer=null}var targetElement=ev.toElement;if(targetElement==undefined)targetElement=ev.relatedTarget;if($modal.has(targetElement).length==0&&$this.has(targetElement).length==0)$modal.hide(200)})}})}}catch(err){}}};authorBioBoxHandler.init()})(jQuery);
(function($){var userId=document.cookie.match(/wapo_login_id=([^;]+)/)?RegExp.$1:"",userSecureId=document.cookie.match(/wapo_secure_login_id=([^;]+)/)?RegExp.$1:"",userAgent=navigator.userAgent,wp_pb=window.wp_pb||{},env=wp_pb.environment||"production";function Newsletter(objValue){var obj=objValue||{};this.id=obj.id||"";this.name=obj.name||"";this.headline=obj.headline||"";this.blurb=obj.blurb||""}function InLineNewsletter($rootSelector){var isHomepage=$rootSelector.find(".newsletter-inline-unit").hasClass("homepage"),
codedNewsletter=$rootSelector.find(".newsletter-inline-unit").hasClass("codedNewsletter"),keywordExists=$rootSelector.find(".newsletter-inline-unit").hasClass("keywordExists"),showdefault=$rootSelector.find(".hidden-data .show-default").text()=="true"?true:false,newsletter={value:new Newsletter};if($rootSelector.find(".newsletter-inline-unit").hasClass("rightRail"))$rootSelector.addClass("rightRail");if(isHomepage)$rootSelector.addClass("homepage");var newsletterInLine={showConfirmation:function(){$rootSelector.find(".signup-module").addClass("hide");
$rootSelector.find(".success-confirmation, .title-container").removeClass("hide")},showError:function(message){$rootSelector.find(".error").text(message).removeClass("hide")},hideError:function(){$rootSelector.find(".error").addClass("hide")},getPageData:function(){var section=$rootSelector.find(".section-instream").text(),subSection=$rootSelector.find(".subsection-instream").text(),blog=$rootSelector.find(".blogname-instream").text(),data={};if(userId!=="")data.washPostId=userId;if(blog)data.blog=
blog;if(subSection)data.subSection=subSection;if(section)data.section=section;return data},getInLineNewsletter:function(){var data=newsletterInLine.getPageData(),url="https://recommendation-newsletter.wpdigital.net/Newsletter/api/newsletter";return $.ajax({type:"POST",dataType:"json",contentType:"application/json",url:url,data:JSON.stringify(data)})},subscribe:function(email){var data,url;if(userId!==""){if(env=="production")url="https://subscribe.washingtonpost.com/person/newsletter/subscribe";else url=
"https://subscribe.digitalink.com/person/newsletter/subscribe";data={"wapoLoginID":userId,"wapoSecureID":userSecureId,"userAgent":navigator.userAgent,"newsletterName":newsletter.value.id,"metadata":[{"name":"nl_start_method","value":"S"},{"name":"nl_start_location","value":"IS"}]}}else if(email){if(env=="production")url="https://subscribe.washingtonpost.com/person/newsletter/subscribe-email";else url="https://subscribe.digitalink.com/person/newsletter/subscribe-email";data={"email":email,"newsletterName":newsletter.value.id,
"metadata":[{"name":"nl_start_method","value":"S"},{"name":"nl_start_location","value":"IS"}]}}$.ajax({type:"POST",dataType:"json",contentType:"application/json",url:url,data:JSON.stringify(data),success:function(data){if(data.status=="SUCCESS"){newsletterInLine.showConfirmation();s.sendDataToOmniture("Newsletter In Line Unit","event91",newsletterInLine.trackProps("nl_instream_simple_"+newsletter.value.name.toLowerCase().split(" ").join("-")+"_1"),{wait:true})}else newsletterInLine.showError("Error while subscribing, please try later.")},
error:function(request,status,error){newsletterInLine.showError("Error while subscribing, please try later.")}})},applyNewsletterData:function(){if(codedNewsletter&&keywordExists||isHomepage&&codedNewsletter){$rootSelector.addClass("codedNewsletter");var data={};data.headline=data.name=$rootSelector.find(".coded-nl-headline").text();data.blurb=$rootSelector.find(".coded-nl-tagline").text();data.id=$rootSelector.find(".coded-nl-id").text();newsletter.value=new Newsletter(data);$rootSelector.find(".headline").text(newsletter.value.headline);
$rootSelector.find(".tagline").text(newsletter.value.blurb);return}else if(!codedNewsletter||showdefault)newsletterInLine.getInLineNewsletter().done(function(data){if(!$.isEmptyObject(data.newsletter)){newsletter.value=new Newsletter(data.newsletter);$rootSelector.find(".headline").text(newsletter.value.headline);$rootSelector.find(".tagline").text(newsletter.value.blurb)}else $rootSelector.addClass("hide")})},positionNewsletter:function(){var position=$rootSelector.find(".newsletter-position").text();
if(position=="after3th"){if($("#article-body article").length>0&&$("#article-body article").children("p").length<3){$rootSelector.addClass("hide");return false}var paragraph;if($("#article-body article").children()[2].nodeName=="DIV"||$("#article-body article").children()[3].nodeName=="DIV")paragraph=$("#article-body article").find(" \x3e p")[1];else paragraph=$("#article-body article").find(" \x3e p")[2];$(paragraph).after($rootSelector);$("#article-body article").children().each(function(index){if(index<=
5)if($(this).hasClass("inline-photo-right")){$(this).before($rootSelector);return}});return true}else{if($("#article-body article").length>0&&$("#article-body article").children("p").length<8){$rootSelector.addClass("hide");return false}var paragraphs=$("#article-body article").find(" \x3e p");var last=$(paragraphs).last();$(paragraphs).find(" \x3e strong, \x3e b").each(function(data,index){var text=$(this).text();var linkT=$(this).find("a").text();if(linkT.indexOf("Read More")>=0||linkT.indexOf("Read more")>=
0||text.indexOf("Read More")>=0||text.indexOf("Read more")>=0||linkT.indexOf("Also Read")>=0||linkT.indexOf("Also read")>=0||text.indexOf("Also Read")>=0||text.indexOf("Also read")>=0)last=$(this).parent()});var paragraph=$(last).prev().prev().prev().prev();if($(last).text().trim()=="")paragraph=paragraph.prev();if($(last).prev().text().trim()=="")paragraph=paragraph.prev();if($(last).prev().prev().text().trim()=="")paragraph=paragraph.prev();if($(last).prev().prev().prev().text().trim()=="")paragraph=
paragraph.prev();$(paragraph).before($rootSelector);var prevContent=$rootSelector.prev(),prevprevContent=$rootSelector.prev().prev(),prevprevprevContent=$rootSelector.prev().prev().prev();if($(prevContent).hasClass("inline-photo-left")||$(prevContent).hasClass("inline-photo-right"))$(prevContent).before($rootSelector);if($(prevprevContent).hasClass("inline-photo-left")||$(prevprevContent).hasClass("inline-photo-right"))$(prevprevContent).before($rootSelector);if($(prevprevprevContent).hasClass("inline-photo-left")||
$(prevprevprevContent).hasClass("inline-photo-right"))$(prevprevprevContent).before($rootSelector);return true}},init:function(){var showUnit=true,newsletterpositioned=true;if(codedNewsletter&&keywordExists==false&&showdefault==false&&isHomepage==false)showUnit=false;if(showUnit){if(isHomepage==false)newsletterpositioned=newsletterInLine.positionNewsletter();if(newsletterpositioned!==false){newsletterInLine.applyNewsletterData();$rootSelector.find(".sign-up-btn").click(function(){if(userId!=="")newsletterInLine.subscribe();
else if($rootSelector.find(".title-container").hasClass("hide")){var email=$rootSelector.find(".sign-up-input").val(),re=/[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}/igm;if(email==""||!re.test(email))newsletterInLine.showError("Please enter a valid email address");else{newsletterInLine.hideError();newsletterInLine.subscribe(email)}}else{$rootSelector.find(".title-container").addClass("hide");$rootSelector.find(".input-container").removeClass("hide")}});setTimeout(function(){$(window).off("scroll.newsletterInLine").on("scroll.newsletterInLine",
newsletterInLine.onVisibilityChange($(".pb-f-page-newsletter-inLine"),newsletterInLine.trackOmniture))},3E3)}}else $rootSelector.addClass("hide")},trackOmniture:function(){s.sendDataToOmniture("Newsletter In Line Unit","event59",newsletterInLine.trackProps("nl_instream_simple_"+newsletter.value.name.toLowerCase().split(" ").join("-")+"_1"),{wait:true});$(window).off("scroll.newsletterInLine")},trackProps:function(enhancedKey){var subsection=window.wp_subsection||"";var contentType=window.wp_content_type||
"";var channel=window.wp_channel||"";var props={"eVar2":"wp - "+subsection,"prop2":"wp - "+subsection,"prop3":contentType,"eVar17":contentType,"channel":channel};props.eVar26=enhancedKey;return props},isElementInViewport:function(el){if(typeof jQuery==="function"&&el instanceof jQuery)el=el[0];var rect=el.getBoundingClientRect();return rect.top>=0&&rect.left>=0&&rect.bottom<=(window.innerHeight||document.documentElement.clientHeight)&&rect.right<=(window.innerWidth||document.documentElement.clientWidth)},
onVisibilityChange:function(el,callBack){return function(){if(newsletterInLine.isElementInViewport(el))callBack()}}};newsletterInLine.init()}$(".pb-f-page-newsletter-inLine").each(function(index,value){var Newsletter=new InLineNewsletter($(this))})})(jQuery);
$(function() {
    wp_pb = window.wp_pb || {};
    wp_pb.CommentLoader = wp_pb.CommentLoader || function(){
        var width = (window.innerWidth > 0) ? window.innerWidth : screen.width,
            isMobile = ((wp_pb && wp_pb.BrowserInfo && wp_pb.BrowserInfo.mobile_browser === 1) && width < 480 ) ? true : false,
            isArticle = $('html').hasClass("layout_article") ? true : false,
            commentsClosed = ($('.echo_container .closed').length > 0) ? true : false,
            loadDeferred = ($('.echo_container.defer').length > 0) ? true : false,
            triggerLoad = ($('.echo_container.triggerLoad').length > 0) ? true : false,
            loadDeferredMobile = ($('.echo_container.deferMobile').length > 0) ? true : false,
            noMobile = ($('.echo_container.no-mobile').length > 0 && isMobile) ? true : false,
            noDesktop = ($('.echo_container.no-desktop').length > 0) ? true : false,
            $window = $(window),
            $echoPlaceholder = $('.echo_container_placeholder'),
            loadThreshhold = .70,
            env = wp_pb.environment || "production",
            apiBaseURL = (env == 'production')?'https://comments-api.ext.nile.works':'https://comments-api-staging.ext.nile.works',
            forceShowComments = $(document).getUrlParam("sc"), //get any relevant QS parameters
            commentOverlay = {
                    overlayElements: {
                        overlay: '#comment_overlay',
                        articleWrapper: '.article-wrapper',
                        articleTopper: '.article-topper',
                        articleParent: '.story-stream',
                    },
                    onClose: function(data) {
                        data.overlay = data.overlay || $(commentOverlay.overlayElements.overlay);
                        data.overlay.addClass('overlay-closed');

                        /*** STORYLINE COMMENTS CODE; DEPRECATED ***/
                        /*  $(window.document).off('scroll.TWP.Comments');
                            if (!data.action || data.action != 'story_closed') {
                                $('#story-stream-tools').css('display','block');
                            }
                        */
                    },
                    onOpen: function(data) {
                        //hack to make the comments overlay work with the site menu open. LP will revisit.
                        if($('body').is('.left-menu')) {
                            $('#site-menu-btn').click();
                            setTimeout(function() {
                                data.overlay.addClass('overlay-fixed').removeClass('overlay-absolute');
                                data.overlayWrapper.removeClass('overlay-closed');
                            }, 600);
                        } else {
                            data.overlay.addClass('overlay-fixed').removeClass('overlay-absolute');
                            data.overlayWrapper.removeClass('overlay-closed');
                        }

                    },
                    onScroll: function(event){

                    },
                    closeSelector: "a.close"};


        var loadComments = function() {
            if (!noMobile && !noDesktop) {
                if (typeof wp_e2 == 'undefined' || typeof wp_e2.initStatus == 'undefined') {
                    var domain = (env == "production") ? "//js.washingtonpost.com/pb" : "/pb";
                    var outputtype = (env == "production") ? "&outputType=javascript" : "&outputType=javascript";
                    var resourceToken = wp_pb.resourceToken || '201504300950';
                    var commentsFile = [domain + "/1d/hjs/twp-comments.js" + "?token=" + resourceToken + outputtype];
                    //window.wp_import && window.wp_import.withStyleId("pb-r-comments-loader",commentsFile);
                    window.TWPHead && TWPHead.load(commentsFile);
                }
            }
        };


        var showComments = function(data) {
            loadComments();
            $window.off('scroll.showComments');
            var $overlay = $(commentOverlay.overlayElements.overlay);  //check for overlay element

            if ($overlay.length === 0) {  //standard functionality
                $('.comment-summary.summary-expanded, .comment-summary.summary-expanded-mobile, .comment-summary.summary-expanded-desktop')
                    .slideUp('fast', function() {
                        $('.echo_container.comments-collapsed').removeClass('comments-collapsed')
                            .addClass('comments-expanded')
                            .slideDown('fast', function() {
                                wp_pb.report('global', 'domChanged');
                            });
                        $(this).addClass('summary-collapsed').removeClass('summary-expanded summary-expanded-mobile summary-expanded-desktop');
                        if (typeof window.sendDataToOmniture === 'function') {
                            try {
                                sendDataToOmniture('echo.gotoComments', 'event5', {
                                    "eVar26": "go to comments"
                                });
                            } catch (err) {}
                        }
                    });
                    var bottomOffset = $(document).height() - $($echoPlaceholder.parent()[0]).offset().top;
                    var windowHeight = $(window).height()
                    if ( bottomOffset < windowHeight){
                      $($echoPlaceholder.parent()[0]).height(windowHeight - bottomOffset);
                    }
                    $echoPlaceholder.parent()[0].scrollIntoView();
            } else {
                //comments displayed in side/overlay
                //comments moved to appropriate place in DOM, positioned, and refreshed.

                if (typeof data == 'undefined') {
                    //do nothing
                    return;
                }

                $overlayWrapper = data.elm.parents(commentOverlay.overlayElements.articleWrapper);

                if(!$overlay.is('.overlay-closed')) {
                    //if the comments are open, close them
                    wp_pb.report('comments', 'commentsMultiClosed', {'overlay': $overlay, 'overlayWrapper': $overlayWrapper})
                } else {
                    //otherwise, open the comments
                    $overlay.find(commentOverlay.closeSelector).on('click',function(event){
                        event.stopPropagation();
                        wp_pb.report('comments','commentsMultiClosed', {'overlay':$overlay,'overlayWrapper':$overlayWrapper})
                    });

                    //move to appropriate place in DOM
                    $overlayWrapper.after($overlay);
                    var top = (data && data.location && data.location.offset().top) || $(document).scrollTop();

                    //refresh
                    if (typeof data.guid !== 'undefined') {
                        var allow_comments = ($overlayWrapper.find('.pb-comment-wrapper').attr('data-allow-comments')==='true')?true:false;
                        wp_e2.refreshComments({"id":"#" + $overlay.find('.echo_container.comments').attr('id'), "url":data.guid, "allow_comments":allow_comments});
                    }

                    wp_pb.report('comments', 'commentsMultiOpened',{'parent':$overlayWrapper.parent($(commentOverlay.overlayElements.articleParent)),'overlay':$overlay,'overlayWrapper':$overlayWrapper});
                }
            }

        };

        var loadCommentCount = function (elms){
            //echo code.  comment out for in-house
            //var apiBaseURL = '//api.echoenabled.com';//production (Echo)
            //end echo

            var echoCountApi =  apiBaseURL + '/v2/mux' +
                                '?appkey='  + ((TWP.Data.echo_appkey != 'undefined')?TWP.Data.echo_appkey:'prod.washpost.com') +
                                '&requests=';
            var query = "(childrenof:'{guid}'" +
             encodeURI("source:washpost.com (((state:Untouched AND user.state:ModeratorApproved) OR (state:CommunityFlagged,ModeratorApproved,ModeratorDeleted AND -user.state:ModeratorBanned,ModeratorDeleted) )))"
                + ' children: 2 (((state:Untouched AND user.state:ModeratorApproved) OR (state:CommunityFlagged,ModeratorApproved AND -user.state:ModeratorBanned,ModeratorDeleted) ) )');

            /*
    [{  "id":"count1",
        "method":"count",
        "q":"((childrenof: //www.washingtonpost.com/world/middle_east/palestinians-form-new-unity-government-including-hamas/2014/06/02/c681d5c6-ea46-11e3-9f5c-9075d5508f0a_story.html source:washpost.com (((state:Untouched user.state:ModeratorApproved) OR (state:CommunityFlagged,ModeratorApproved,ModeratorDeleted -user.state:ModeratorBanned,ModeratorDeleted) OR (-state:SystemFlagged,ModeratorFlagged user.id:'http://washingtonpost.com/vr5H9gYg8K7QKi4eY3QuCsBEPSO0NNloQjBe0ZqhSs1oGeVxxhJF5A==/')) AND ( -markers:ignore ) ) )) itemsPerPage: 15 sortOrder:reverseChronological safeHTML:aggressive children: 2 childrenSortOrder:chronological childrenItemsPerPage:3 (((state:Untouched user.state:ModeratorApproved) OR (state:CommunityFlagged,ModeratorApproved -user.state:ModeratorBanned,ModeratorDeleted) OR (-state:SystemFlagged,ModeratorFlagged user.id:'http://washingtonpost.com/vr5H9gYg8K7QKi4eY3QuCsBEPSO0NNloQjBe0ZqhSs1oGeVxxhJF5A==/')) AND ( -markers:ignore ) )"}]
            */
            var muxArray = new Array();

            var dataUrl;

            $(elms).each(function(index,el) {
                var thisData =  $(el).attr('guid') || $(el).attr('data');
                if (typeof thisData != 'undefined') {
                    query = query.replace("{guid}",thisData);
                    muxArray.push( {"id":thisData,"method":"count","q":query});
                 }
            });
            jQuery.ajax({
                url: echoCountApi + JSON.stringify(muxArray),
                dataType: 'jsonp',
                cache: true})
                .done(function(data,status ){
                    if (status != "error") {
                        $.each(data,function(index,el){
                            var count = (el.result != 'error')?parseInt(el.count):'';
                            var counterTarget = $(".echo-counter[guid='"+index +"']");
                            formatCount(count, counterTarget);
                        })
                    }
                });

        };

        var formatCount = function(rawCount, uiTargets){
          for (i = 0; i < uiTargets.length; i++){
            if (rawCount >= 1000 && uiTargets[i].classList.contains('format_short')){
              var shortCount = (Math.floor(10 * (rawCount/1000))/10).toFixed(1);
              uiTargets[i].innerHTML = shortCount + "k";
            } else {
              uiTargets[i].innerHTML = rawCount;
            }
          }
        };

        var resetFixed = function(data) {
            var $shareBarHeight = $('.sticky-top-sharebar'), $streamHeader = $('.echo-apps-conversations-streamHeader');
            if (data == 'opened' && $('.bar-hidden').length === 0 ) {
                $streamHeader.addClass('nav-open');
            } else {
                $streamHeader.removeClass('nav-open');
            }
        };

        var init = function() {
            
            //register that a closed comments message has replaced link display in article
            if (commentsClosed && isArticle){
              $(".pb-f-page-comments").addClass("closed-message");
              $(".social-tools-wrapper-bottom").addClass("align-left").removeClass("align-right");
            }
            
            if (window.location.hash == "#comments") {
                showComments();
            }

            //register callbacks
            wp_pb.register('comments', 'showComments', showComments, this);

            //Initalize showComments immediately if URL includes #comments
            wp_pb.register('comments', 'commentsReady', function() {
                if (forceShowComments === '1') {
                    showComments();
                }
                if (window.location.hash == "#comments") {
                    $echoPlaceholder.parent()[0].scrollIntoView();
                }
                
                $($echoPlaceholder.parent()[0]).height('auto');
            });

            wp_pb.register('nav', 'finish_open', function() {
                resetFixed('opened');
            });

            wp_pb.register('nav', 'finish_close', function(){
                resetFixed('closed');
            });

            wp_pb.register('sticky-top-sharebar', 'sharebar_fixed', function(){
                $('.echo-apps-conversations-streamHeader').addClass('top-sharebar-fixed');
            });

            wp_pb.register('sticky-top-sharebar', 'sharebar_unfixed', function(){
                $('.echo-apps-conversations-streamHeader').removeClass('top-sharebar-fixed');
            });

            wp_pb.register('nav', 'menu_start_open', function(){
                var $overlay = $(commentOverlay.overlayElements.overlay);  //check for overlay element
                if ($overlay.length > 0) {  //standard functionality
                    $overlay.parent().hide();
                }
            });

            wp_pb.register('nav', 'menu_finish_close', function(){
                var $overlay = $(commentOverlay.overlayElements.overlay);  //check for overlay element
                if ($overlay.length > 0) {  //standard functionality
                    $overlay.parent().show();
                }
            });


            wp_pb.register('comments', 'commentsMultiOpened',commentOverlay.onOpen);
            wp_pb.register('comments', 'commentsMultiClosed',commentOverlay.onClose);

            //add events
            $('.comment-summary').click(function() {
                //showComments();
                //populating the data object so that the overlay comments panel has enough info to open
                var data = {
                    elm: $(this),
                    guid: $(this).find('.echo_container').attr('guid')
                };
                history.pushState(null, null, '#comments')
                wp_pb.report('comments', 'showComments', data);
            });
            
            $('.comment-jump').click(function() {
                history.pushState(null, null, '#comments')
            });
            
            if (isMobile) {
                $('.comment-summary.jump').hide();
            }


            //load comments as appropriate
            if (isMobile && loadDeferredMobile || !isMobile && triggerLoad ) {
                //only load count on standard count element.  Comments loaded on click of comment-summary
                loadCommentCount('.echo-counter');
            } else if (!isMobile && loadDeferred) {
                //load comment count on standard count element first
                loadCommentCount('.echo-counter');
                //set up scroll events.  Comments will load on scroll or click of comment count, comment-summary
                $window.on('scroll.showComments', function() {
                    if ($window.scrollTop() / $echoPlaceholder.offset().top >= loadThreshhold) {
                        //showComments();
                        loadComments();
                    }
                    if ($window.scrollTop() >= $echoPlaceholder.offset().top ) {
                        showComments();
                    }
                });
            } else {
                loadComments();
            }

            if (triggerLoad) {
                var triggerLoadLogger = new TWP.Tools.logger("LOAD-BLOCKER-COMMENTS");

                // ensure fields are set
                TWP.loadImmediatelyBlockers = TWP.loadImmediatelyBlockers || {};
                TWP.loadImmediatelyBlockers.comments = TWP.loadImmediatelyBlockers.comments || [];

                // check if fields are empty
                var checkCommentsBlockers = function() {
                    triggerLoadLogger.log("checkCommentsBlockers: " + TWP && TWP.loadImmediatelyBlockers && TWP.loadImmediatelyBlockers.comments && TWP.loadImmediatelyBlockers.comments.length != 0);
                    return TWP && TWP.loadImmediatelyBlockers && TWP.loadImmediatelyBlockers.comments && TWP.loadImmediatelyBlockers.comments.length != 0;
                }

                // load display ads required code
                var loadCommentsLoader = function(forceAdd) {
                    if ( (!checkCommentsBlockers() || !!forceAdd) && !!!TWP.loadImmediatelyBlockers.loadedComments) {
                        triggerLoadLogger.log("loadCommentsLoader");
                        try {
                            loadComments();
//                          TODO: only works for Gallery pages !
                            TWP.loadImmediatelyBlockers.loadedComments = true;
                        } catch (err) {}
                    }
                }

                // add event handling from TWP.loadImmediatelyBlockers
                if (checkCommentsBlockers()) {
                    $.each(TWP.loadImmediatelyBlockers.comments, function(i, val){
                        $(window.document).on(val, function(){
                            triggerLoadLogger.log("comments inEvent: "+val);
                            loadCommentsLoader();
                        });
                        setTimeout(function(){
                            triggerLoadLogger.log("comments inTimeout");
                            $(window.document).off(val);
                            loadCommentsLoader(true);
                        }, 5000);
                    });
                } else {
                    triggerLoadLogger.log("comments inElse");
                    loadCommentsLoader(true);
                }
            }
        }
        return{init:init,showComments:showComments,loadCommentCount:loadCommentCount};
    } ();
    wp_pb.CommentLoader.init();
});

(function($){var $socialToolsBottom=$(".social-tools-bottom"),$individualTools=$socialToolsBottom.children(),config={"omnitureEvent":"event6"};$(".social-tools-wrapper-bottom").each(function(index,myRootElement){if(wp_pb.StaticMethods.staticPostShare)wp_pb.StaticMethods.staticPostShare.init($(myRootElement),$(myRootElement).data("postshare"))});$individualTools.on("click",function(e){if(typeof window.sendDataToOmniture==="function"){var shareType=$(this).data("sharetype"),eventName=config.omnitureEvent,
omnitureVars={"eVar1":typeof window.s=="object"&&s&&s.eVar1,"eVar2":typeof window.s=="object"&&s&&s.eVar2,"eVar8":typeof window.s=="object"&&s&&s.eVar8,"eVar17":typeof window.s=="object"&&s&&s.eVar17,"eVar27":""};omnitureVars.eVar27=shareType+"_bottom";try{sendDataToOmniture("share."+shareType,eventName,omnitureVars)}catch(e){console.log(e)}}})})(jQuery);
(function($){$(".pb-f-article-article-author-bio").each(function(){var numAuthors=$(this).find(".pb-bottom-author").length;if(numAuthors==0)$(this).hide();else if(numAuthors>1)$(this).find(".pb-bottom-author").addClass("hide-images")})})(jQuery);
(function(){var $=jQuery;var TWP=window.TWP||{};TWP.Perso=TWP.Perso||{};TWP.Perso.Tools=TWP.Perso.Tools||{};var T=TWP.Perso.Tools;var $sponsored=null;var $container=null;var $pbcontainer=null;var log=new TWP.Tools.logger("HYBRID");var output="";var validOnes=[];var client=null;var clientName="recommend-strip-v1";var status="";var visible=false;var trackRenderedAllCalled=false;function _failure(error){log.debug("Failure",function(){$pbcontainer.hide();trackError(error);status="failed"})}function isValid(recommendation){return recommendation&&
recommendation.url&&recommendation.responsetype&&recommendation.headline&&recommendation.summary&&recommendation.photo&&recommendation.photo.path}function render(recommendations){if(!recommendations||recommendations.length==0)return _failure("no-recommendations");for(var i=0;i<recommendations.length;i++)if(isValid(recommendations[i]))validOnes.push(recommendations[i]);if(validOnes.length==0)return _failure("no-valid-recommendations");log.debug("Render",function(){_renderArticle(validOnes)});status=
"rendered";trackVisible()}function _renderArticle(recommendations){var idx=0;var html="";var classes="";for(var i=0;i<recommendations.length;i++){log.debug("Render item ("+i+")");html=html+renderItem(recommendations[i],idx,recommendations.length);idx=idx+1}html='\x3cdiv class\x3d"postrecommends contentfeed'+classes+'"\x3e'+'\x3cdiv class\x3d"content-strip"\x3e'+'\x3cdiv class\x3d"label-wrapper"\x3e'+'\x3cspan class\x3d"label label-kicker"\x3eThe Post Recommends\x3c/span\x3e'+"\x3c/div\x3e"+'\x3cdiv class\x3d"clear"\x3e\x3c/div\x3e'+
html+'\x3cdiv class\x3d"clear"\x3e\x3c/div\x3e'+"\x3c/div\x3e"+"\x3c/div\x3e";if(html!=output){output=html;$sponsored=$("#slug_postrecommends");$sponsored.remove();$container.html(output);$container.find(".content-strip \x3e .label-wrapper").before($sponsored);$pbcontainer.show();$pbcontainer.after('\x3cdiv class\x3d"clear"\x3e\x3c/div\x3e')}}function renderURL(recommendation){return recommendation.url+"?tid\x3d"+recommendation.responsetype}function renderImgURL(recommendation,w,h){var url=recommendation.photo.path;
return"https://img.washingtonpost.com/wp-apps/imrs.php?src\x3d"+encodeURIComponent(url)+"\x26w\x3d"+w+"\x26h\x3d"+h}function renderClasses(recommendation,index,total){var classes="";if(recommendation.responsetype.match(/video/))classes=classes+"video ";if(index==0)classes=classes+"first ";if(index==total-1)classes=classes+"last";return classes}function renderItem(recommendation,index,total){var node=$($("#postrecommends-article-template").html());node.addClass(renderClasses(recommendation,index,total));
var headline=node.find(".headline a");headline.html(recommendation.headline);headline.attr("href",renderURL(recommendation));var linkImg=node.find(".photo-wrapper a");linkImg.attr("href",renderURL(recommendation));var blurb=node.find(".blurb");blurb.html(recommendation.summary);var img='\x3cimg alt\x3d"" src\x3d"'+renderImgURL(recommendation,480,320)+'"'+' data-hi-res-src\x3d"'+renderImgURL(recommendation,480,320)+'"'+' data-low-res-src\x3d"'+renderImgURL(recommendation,112,75)+'"'+' data-threshold\x3d"112" class\x3d"courtesy-of-the-resizer"\x3e';
node.find(".photo-wrapper img").replaceWith(img);if(recommendation.responsetype.match(/video/)){var time="";if(recommendation.videoDuration&&recommendation.videoDuration>1E3){var seconds=Math.floor(recommendation.videoDuration/1E3);var minutes=Math.floor(seconds/60);seconds=seconds%60;if(seconds<10)seconds="0"+seconds.toString();time=minutes+":"+seconds}var caption='\x3cdiv class\x3d"standalone-overlay posttv-playlist-text-play-btn"\x3e'+'\x3ca class\x3d"video-play" href\x3d"'+renderURL(recommendation)+
'"\x3e'+'\x3cspan class\x3d"fa fa-play icon-left"\x3e\x3c/span\x3e\x3cspan\x3ePlay Video\x3c/span\x3e'+'\x3cspan class\x3d"duration"\x3e'+time+"\x3c/span\x3e"+"\x3c/a\x3e"+"\x3c/div\x3e";blurb.after(caption)}return node[0].outerHTML}function trackClicks(){$container.on("click","a",null,function(){var link=this;log.debug("Click",function(){var href=link.href;var tid=href.replace(/.*\?tid=/,"");log.debug("URL : "+href);trackClicked(client,href,tid);setTimeout(function(){log.debug("Redirecting");document.location=
href},200)});return false})}function trackClicked(client,url,tid){T.Omniture.send("post_recommends","",{prop69:tid},log);client.clicked(url)}function trackVisible(){if(status=="rendered"&&visible&&!trackRenderedAllCalled){trackRenderedAllCalled=true;var param=[];for(var i=0;i<validOnes.length;i++)param.push(validOnes[i].responsetype);T.Omniture.send("post_recommends","",{prop72:param.join(",")},log);client.rendered()}}function trackError(error){T.noticeError(clientName,error)}function _preload(){log.debug("Setting up click handlers");
trackClicks();log.debug("Requesting recommendations");client=new TWP.Perso.Recommend(clientName,3);client.recommend().done(function(data){render(data["results"])})}function _visible(){log.debug("Visible",function(){visible=true;trackVisible()})}$(function(){log.debug("DOM Ready",function(){try{log.debug("Finding containers");$container=$("#post-recommends");$pbcontainer=$container.parent();if($container.length==1){log.debug("Setting up scroll listener");T.Events.smartPreload($pbcontainer,{preload:_preload,
visible:_visible,screens:2})}}catch(e){trackError("init-error")}})})})();
(function(){$(window.document).on("abtest-ready",function(e,ABT){var test=ABT.get("ads-outbrain");if(test.is("enabled")){var $feature=$(".pb-f-page-outbrain");$feature.show();var $container=$("#outbrain-container");$container.addClass("OUTBRAIN");var obSc=document.createElement("script");obSc.src="//widgets.outbrain.com/outbrain.js";obSc.async="async";obSc.type="text/javascript";$container.append(obSc)}})})(jQuery);
!function(a,b,c){var d=a[b],e=c(a,a.document);a[b]=e,a[b].noConflict=function(){return a[b]=d,e}}(this,"VisSense",function(a,b,c){function d(a,b){return function(){var d=arguments;return g(function(){a.apply(c,d)},b||0)}}function e(a,b){var c=q;return function(){var d=this,e=arguments;c(),c=g(function(){a.apply(d,e)},b)}}function f(a,b){var d=p(b),e=p(a);return d||e?d&&e?(j(Object.keys(b),function(d){a[d]===c&&(a[d]=b[d])}),a):d?b:a:b}function g(a,b){var c=setTimeout(function(){a()},b||0);return function(){clearTimeout(c)}}
function h(a,b){return function(){return(o(a)?a():a)?b():c}}function i(a,b,c){for(var d=-1,e=Object.keys(b),f=e.length,g=o(c);++d<f;){var h=e[d];a[h]=g?c(a[h],b[h],h,a,b):b[h]}return a}function j(a,b,d){for(var e=0,f=a.length;f>e;e++){var g=b.call(d,a[e],e,a);if(g!==c)return g}}function k(a){return a}function l(a){return a!==c}function m(a){return a&&"object"==typeof a&&"number"==typeof a.length&&"[object Array]"===Object.prototype.toString.call(a)||!1}function n(a){return a&&1===a.nodeType||!1}function o(a){return"function"==
typeof a||!1}function p(a){var b=typeof a;return"function"===b||a&&"object"===b||!1}function q(){}function r(){return(new Date).getTime()}function s(a){var b,d=!1;return function(){return d||(b=a.apply(c,arguments),d=!0),b}}function t(a,b,c){var d=q,e=!1;return function(){var f=r(),h=arguments,i=function(){e=f,a.apply(c,h)};e&&e+b>f?(d(),d=g(i,b)):(e=f,g(i,0))}}function u(b){var c=b||a;return{height:c.innerHeight,width:c.innerWidth}}function v(b,c){return(c||a).getComputedStyle(b,null)}function w(a,
b){return a.getPropertyValue(b)}function x(a,b){b||(b=v(a));var c=w(b,"display");if("none"===c)return!1;var d=a.parentNode;return n(d)?x(d):!0}function y(b,c){if(b===(c||a).document)return!0;if(!b||!b.parentNode)return!1;var d=v(b,c),e=w(d,"visibility");return"hidden"===e||"collapse"===e?!1:x(b,d)}function z(a,b){return!a||a.width<=0||a.height<=0?!1:a.bottom>0&&a.right>0&&a.top<b.height&&a.left<b.width}function A(a,b){var c=a.getBoundingClientRect(),d=u(b);if(!z(c,d)||!y(a))return 0;var e=0,f=0;return c.top>=
0?e=Math.min(c.height,d.height-c.top):c.bottom>0&&(e=Math.min(d.height,c.bottom)),c.left>=0?f=Math.min(c.width,d.width-c.left):c.right>0&&(f=Math.min(d.width,c.right)),Math.round(e*f/(c.height*c.width)*1E3)/1E3}function B(b){return!F(b||a).isHidden()}function C(b,c){if(!(this instanceof C))return new C(b,c);if(!n(b))throw new Error("not an element node");this._element=b,this._config=f(c,{fullyvisible:1,hidden:0,referenceWindow:a,percentageHook:A,visibilityHooks:[]});var d=F(this._config.referenceWindow);
this._config.visibilityHooks.push(function(){return!d.isHidden()})}function D(a,b){var c=a.state(),d=c.percentage;return b&&d===b.percentage&&b.percentage===b.previous.percentage?b:c.hidden?C.VisState.hidden(d,b):c.fullyvisible?C.VisState.fullyvisible(d,b):C.VisState.visible(d,b)}function E(a,b){var c=f(b,{strategy:[new E.Strategy.PollingStrategy,new E.Strategy.EventStrategy],async:!1});this._visobj=a,this._state={},this._started=!1;var d="*#"+r();this._pubsub=new G({async:c.async,anyTopicName:d}),
this._events=[d,"start","stop","update","hidden","visible","fullyvisible","percentagechange","visibilitychange"],this._strategy=new E.Strategy.CompositeStrategy(c.strategy),this._strategy.init(this),this._pubsub.on("update",function(a){var b=a._state.percentage,c=a._state.previous.percentage;b!==c&&a._pubsub.publish("percentagechange",[a,b,c])}),this._pubsub.on("update",function(a){a._state.code!==a._state.previous.code&&a._pubsub.publish("visibilitychange",[a])}),this._pubsub.on("visibilitychange",
function(a){a._state.visible&&!a._state.previous.visible&&a._pubsub.publish("visible",[a])}),this._pubsub.on("visibilitychange",function(a){a._state.fullyvisible&&a._pubsub.publish("fullyvisible",[a])}),this._pubsub.on("visibilitychange",function(a){a._state.hidden&&a._pubsub.publish("hidden",[a])}),j(this._events,function(a){o(c[a])&&this.on(a,c[a])},this)}var F=function(b){return function(a,b){var c=function(a,b){return{property:a,event:b}},d="visibilitychange",e=[c("webkitHidden","webkit"+d),c("msHidden",
"ms"+d),c("mozHidden","moz"+d),c("hidden",d)],f=j(e,function(c){return a[c.property]!==b?{isHidden:function(){return!!a[c.property]||!1},onVisibilityChange:function(b){return a.addEventListener(c.event,b,!1),function(){a.removeEventListener(c.event,b,!1)}}}:void 0});return f||{isHidden:function(){return!1},onVisibilityChange:function(){return q}}}((b||a).document)},G=function(a){function b(a){this._cache={},this._onAnyCache=[],this._config=f(a,{async:!1,anyTopicName:"*"})}var c=function(a,b){j(a,
function(a){a(b)})};return b.prototype.on=function(b,c){if(!o(c))return q;var e=function(b){return c.apply(a,b||[])},f=this._config.async?d(e):e,g=function(a,b,c){return function(){var c=b.indexOf(a);return c>-1?(b.splice(c,1),!0):!1}};return b===this._config.anyTopicName?(this._onAnyCache.push(f),g(f,this._onAnyCache,"*")):(this._cache[b]||(this._cache[b]=[]),this._cache[b].push(f),g(f,this._cache[b],b))},b.prototype.publish=function(a,b){var e=(this._cache[a]||[]).concat(a===this._config.anyTopicName?
[]:this._onAnyCache),f=!!this._config.async,g=f?d(c):function(a,b){return c(a,b),q};return g(e,b||[])},b}();C.prototype.state=function(){var a=j(this._config.visibilityHooks,function(a){return a(this._element)?void 0:C.VisState.hidden(0)},this);return a||function(a,b){var c=b.percentageHook(a,b.referenceWindow);return c<=b.hidden?C.VisState.hidden(c):c>=b.fullyvisible?C.VisState.fullyvisible(c):C.VisState.visible(c)}(this._element,this._config)},C.prototype.percentage=function(){return this.state().percentage},
C.prototype.element=function(){return this._element},C.prototype.referenceWindow=function(){return this._config.referenceWindow},C.prototype.isFullyVisible=function(){return this.state().fullyvisible},C.prototype.isVisible=function(){return this.state().visible},C.prototype.isHidden=function(){return this.state().hidden},C.fn=C.prototype,C.of=function(a,b){return new C(a,b)};var H={HIDDEN:[0,"hidden"],VISIBLE:[1,"visible"],FULLY_VISIBLE:[2,"fullyvisible"]};return C.VisState=function(){function a(a,
b,c){return c&&delete c.previous,{code:a[0],state:a[1],percentage:b,previous:c||{},fullyvisible:a[0]===H.FULLY_VISIBLE[0],visible:a[0]===H.VISIBLE[0]||a[0]===H.FULLY_VISIBLE[0],hidden:a[0]===H.HIDDEN[0]}}return{hidden:function(b,c){return a(H.HIDDEN,b,c)},visible:function(b,c){return a(H.VISIBLE,b,c)},fullyvisible:function(b,c){return a(H.FULLY_VISIBLE,b,c)}}}(),E.prototype.visobj=function(){return this._visobj},E.prototype.publish=function(a,b){var c=this._events.indexOf(a)>=0;if(c)throw new Error('Cannot publish internal event "'+
a+'" from external scope.');return this._pubsub.publish(a,b)},E.prototype.state=function(){return this._state},E.prototype.start=function(a){if(this._started)return this;var b=f(a,{async:!1});return this._cancelAsyncStart&&this._cancelAsyncStart(),b.async?this.startAsync():(this.update(),this._pubsub.publish("start",[this]),this._strategy.start(this),this._started=!0,this)},E.prototype.startAsync=function(a){this._cancelAsyncStart&&this._cancelAsyncStart();var b=this,c=g(function(){b.start(i(f(a,
{}),{async:!1}))});return this._cancelAsyncStart=function(){c(),b._cancelAsyncStart=null},this},E.prototype.stop=function(){this._cancelAsyncStart&&this._cancelAsyncStart(),this._started&&(this._strategy.stop(this),this._pubsub.publish("stop",[this])),this._started=!1},E.prototype.update=function(){this._state=D(this._visobj,this._state),this._pubsub.publish("update",[this])},E.prototype.on=function(a,b){return this._pubsub.on(a,b)},E.Builder=function(){var a=function(a,b){var c=null,d=a.strategy===
!1,e=!d&&(a.strategy||b.length>0);if(e){var f=!!a.strategy,g=m(a.strategy),h=f?g?a.strategy:[a.strategy]:[];c=h.concat(b)}else c=d?[]:a.strategy;return c};return function(b){var c={},d=[],e=[],f=!1,g=null;return{set:function(a,b){return c[a]=b,this},strategy:function(a){return d.push(a),this},on:function(a,b){return e.push([a,b]),this},build:function(h){var i=function(){var h=a(c,d);c.strategy=h;var i=b.monitor(c);return j(e,function(a){i.on(a[0],a[1])}),f=!0,g=i},k=f?g:i();return o(h)?h(k):k}}}}(),
E.Strategy=function(){},E.Strategy.prototype.init=q,E.Strategy.prototype.start=q,E.Strategy.prototype.stop=q,E.Strategy.CompositeStrategy=function(a){this._strategies=m(a)?a:[a]},E.Strategy.CompositeStrategy.prototype=Object.create(E.Strategy.prototype),E.Strategy.CompositeStrategy.prototype.init=function(a){j(this._strategies,function(b){o(b.init)&&b.init(a)})},E.Strategy.CompositeStrategy.prototype.start=function(a){j(this._strategies,function(b){o(b.start)&&b.start(a)})},E.Strategy.CompositeStrategy.prototype.stop=
function(a){j(this._strategies,function(b){o(b.stop)&&b.stop(a)})},E.Strategy.PollingStrategy=function(a){this._config=f(a,{interval:1E3}),this._started=!1},E.Strategy.PollingStrategy.prototype=Object.create(E.Strategy.prototype),E.Strategy.PollingStrategy.prototype.start=function(a){return this._started||(this._clearInterval=function(b){var c=setInterval(function(){a.update()},b);return function(){clearInterval(c)}}(this._config.interval),this._started=!0),this._started},E.Strategy.PollingStrategy.prototype.stop=
function(){return this._started?(this._clearInterval(),this._started=!1,!0):!1},E.Strategy.EventStrategy=function(a){this._config=f(a,{throttle:50}),this._config.debounce>0&&(this._config.throttle=+this._config.debounce),this._started=!1},E.Strategy.EventStrategy.prototype=Object.create(E.Strategy.prototype),E.Strategy.EventStrategy.prototype.start=function(a){return this._started||(this._removeEventListeners=function(b){var c=F(a.visobj().referenceWindow()),d=c.onVisibilityChange(b);return addEventListener("scroll",
b,!1),addEventListener("resize",b,!1),addEventListener("touchmove",b,!1),function(){removeEventListener("touchmove",b,!1),removeEventListener("resize",b,!1),removeEventListener("scroll",b,!1),d()}}(t(function(){a.update()},this._config.throttle)),this._started=!0),this._started},E.Strategy.EventStrategy.prototype.stop=function(){return this._started?(this._removeEventListeners(),this._started=!1,!0):!1},C.VisMon=E,C.PubSub=G,C.fn.monitor=function(a){return new E(this,a)},C.Utils={async:d,debounce:e,
defaults:f,defer:g,extend:i,forEach:j,fireIf:h,identity:k,isArray:m,isDefined:l,isElement:n,isFunction:o,isObject:p,isPageVisible:B,isVisibleByStyling:y,noop:q,now:r,once:s,throttle:t,percentage:A,VisibilityApi:F(),createVisibilityApi:F,_viewport:u,_isInViewport:z,_isDisplayed:x,_computedStyle:v,_styleProperty:w},C});
!function(e,t){typeof module!="undefined"?module.exports=t():typeof define=="function"&&typeof define.amd=="object"?define(t):this[e]=t()}("domready",function(e){function p(e){h=1;while(e=t.shift())e()}var t=[],n,r=!1,i=document,s=i.documentElement,o=s.doScroll,u="DOMContentLoaded",a="addEventListener",f="onreadystatechange",l="readyState",c=o?/^loaded|^c/:/^loaded|c/,h=c.test(i[l]);return i[a]&&i[a](u,n=function(){i.removeEventListener(u,n,r),p()},r),o&&i.attachEvent(f,n=function(){/^c/.test(i[l])&&
(i.detachEvent(f,n),p())}),e=o?function(n){self!=top?h?n():t.push(n):function(){try{s.doScroll("left")}catch(t){return setTimeout(function(){e(n)},50)}n()}()}:function(e){h?e():t.push(e)}});
(function($,wp_pb){if(!(document.location.toString().match(/from-prime-time-hearthrob-to-hollywood-freak/)||document.location.toString().match(/islamic-states-embrace-of-social-media-puts-tech-companies-in-a-bind/)))return;domready(function(){debug("DOM Ready");domReady=true;article=$("#article-body")});var $b=$("body");var $w=$(window);var $d=$(document);var init=function(){};var initNoKmap=function(){};var start=Date.now();var $html=$("html");var $body=$("body");var $window=$(window);var $header=
$("#wp-header");var ad=null;var closer=null;var signup=null;var footer=null;var article=null;var sidebar=null;var children=null;var container=null;var selector=".kmap-info, .kmap-keyword, .kmap-inline-trigger, .kmap-person-trigger, .kmap-series-trigger, .kmap-theme-buttons";var sidebarActivated=false;var initialScroll=0;var pr=false;var darwin=false;var abdarwin=false;var abvariant=null;var devmode=false;var domReady=false;var mockupData="";var mockupReady=false;var featureStarted=false;var sviFull=
document.cookie.match(/s_vi=([^;]+)/)?RegExp.$1:"";var visibility={};var screenSize=0;var toRemove=[];if(document.location.toString().match(/[?&#]kmap=1/)||window.localStorage&&window.localStorage.getItem("kmap"))$(window.document).on("abtest-before",function(e,ABT){debug("Forcing experience in Darwin");trackEvent("ready","darwin-before");abvariant="experiment";ABT.forceTest("knowledgemap-experiment1","experiment")});if(document.location.toString().match(/[?&#]pr=1/))pr=true;var initFeature=function(){if(!domReady||
!mockupReady||!darwin){if(domready&&mockupReady&&!darwin&&Date.now()-start<5E3)setTimeout(initFeature,100);if(Date.now()-start<6E4)setTimeout(initFeature,100);else debug("Giving up");return}if(featureStarted)return;else{featureStarted=true;if(darwin){abdarwin=true;var variation=darwin.get("knowledgemap-experiment1");if(variation.is("experiment"))abvariant="experiment"}else debug("Darwin not ready");if(abvariant=="experiment"){if(devmode)article.html(mockupData);else article.append(mockupData);debug("Initializing");
init();debug("Tracking pageview");trackEvent("experiment","pageview");debug("Initializing (done)")}else{article.append(mockupData);debug("Initializing");initNoKmap();debug("Tracking pageview");trackEvent("default","pageview");debug("Initializing (done)")}}};setTimeout(initFeature,200);$(window.document).on("abtest-ready",function(e,ABT){darwin=ABT;debug("Darwin is ready");trackEvent("ready","darwin");initFeature()});var logs=[];var groupLevel=0;function debug(msg){msgline="[DBGKMAP] "+msg+" ("+(Date.now()-
start)+"ms)";logs.push(msgline);if(window.localStorage&&localStorage.getItem("debug-knowledge-map"))console.log(msgline)}function debugGroupStart(name){groupLevel=groupLevel+1;msgline="[DBGKMAP] "+name;logs.push("\x3e\x3e "+msgline);if(window.localStorage&&localStorage.getItem("debug-knowledge-map"))if(window.console&&console.group)console.group(msgline)}function debugGroupEnd(){groupLevel=groupLevel-1;msgline="[DBGKMAP] "+name;logs.push("\x3c\x3c "+msgline);if(window.localStorage&&localStorage.getItem("debug-knowledge-map"))if(window.console&&
console.groupEnd)console.groupEnd()}function debounce(func,wait,immediate){var timeout;return function(){var context=this,args=arguments;var later=function(){timeout=null;if(!immediate)func.apply(context,args)};var callNow=immediate&&!timeout;clearTimeout(timeout);timeout=setTimeout(later,wait);if(callNow)func.apply(context,args)}}function updateUrlParam(url,key,value){value=encodeURIComponent(value);var n=new RegExp("([?\x26])"+key+"\x3d.*?(\x26|$)","i");var i=-1!==url.indexOf("?")?"\x26":"?";return url.match(n)?
url.replace(n,"$1"+key+"\x3d"+value+"$2"):url+i+key+"\x3d"+value}debug("Adding fonts CSS");$("head").append('\x3clink rel\x3d"stylesheet" href\x3d"/pb/resources/css/fonts.css?_\x3d'+wp_pb.resourceToken+'" type\x3d"text/css"/\x3e');if(window.localStorage&&localStorage.getItem("kmap-development-mockup-url")&&localStorage.getItem("kmap-development-mockup-css")){devmode=true;var mockupURL=localStorage.getItem("kmap-development-mockup-url");var mockupCSS=localStorage.getItem("kmap-development-mockup-css");
$("head").append('\x3clink rel\x3d"stylesheet" href\x3d"'+mockupCSS+'" type\x3d"text/css"/\x3e');$.get(mockupURL,{},function(data){debug("Downloading mockup HTML (done)");mockupData=data;mockupReady=true;abvariant="experiment"},"html")}else $.get("https://www.washingtonpost.com/wp-stat/html/post/isis.html",{},function(data){debug("Downloading mockup HTML (done)");mockupData=data;mockupReady=true});var handleBodyscroll=function(){if(window.innerWidth<=768&&container.hasClass("visible"))$html.addClass("kmapnoscroll");
else $html.removeClass("kmapnoscroll")};var handleScrollAndResize=function(){if(devmode)return;handleBodyscroll();var sidebarPosition=sidebar.offset();var scrollPosition=$window.scrollTop();var topPosition=0;if($header.hasClass("bar-hidden"))topPosition=0;else topPosition=$("#nav-bar").outerHeight();if($(".top-sharebar-fixed").length>0)topPosition=topPosition+$(".top-sharebar-fixed").outerHeight();if(scrollPosition+topPosition>sidebarPosition.top){container.addClass("sticky");container.css("top",
topPosition);container.css("left",sidebarPosition.left);container.css("width",sidebar.width())}else{container.removeClass("sticky");container.css("top",0);container.css("left",0);container.css("width","100%")}};var resizeImages=function(initial){$(container).find("img").each(function(i,img){$img=$(img);var zoom=false;var src=$img.data("origsrc");var width=window.innerWidth;var resize="https://img.washingtonpost.com/wp-apps/imrs.php?src\x3d"+encodeURIComponent(src);var oldScreenSize=screenSize;if(width<=
450){screenSize=450;resize=resize+"\x26w\x3d450"}else if(width<=560){screenSize=560;resize=resize+"\x26w\x3d560"}else if(width<=768){screenSize=768;resize=resize+"\x26w\x3d768"}else{zoom=true;screenSize=1024;resize=resize+"\x26w\x3d285"}if(oldScreenSize==screenSize&&!initial)return;debug("Resize image URLs");$img.attr("src",resize);$img.off("click.modal");$img.removeClass("zoom-in");$(".modal-image-in-focus").remove();$(".overlay-image-in-focus").remove();if($img.parent().is("a"))zoom=false;if(zoom){var modalClass=
"modal-kmap-"+i;$img.addClass("zoom-in");$img.addClass(modalClass);$("\x3cimg/\x3e").attr("src",src).load(function(){var placeholder,defaultTopMargin=$w.height()<480?0:40,defaultLeftMargin=$w.width()<760?0:40,rawWidth=this.width,rawHeight=this.height,displayWidth=$img.width(),displayHeight=$img.height(),bodyWidth=$b.width(),windowWidth=$w.width(),screenWidth=(bodyWidth<windowWidth?bodyWidth:windowWidth)-2*defaultLeftMargin,screenHeight=$w.height()-2*defaultTopMargin,isRawImageMoreHorizontalThanScreen=
rawWidth/screenWidth>=rawHeight/screenHeight,isRawImageMoreVerticalThanScreen=!isRawImageMoreHorizontalThanScreen,isRawImageBig=rawWidth*rawHeight>displayWidth*displayHeight,isRawImageTooWide=rawWidth>screenWidth,isRawImageTooTall=rawHeight>screenHeight,dimensions={w:screenWidth,h:screenHeight,t:defaultTopMargin,l:defaultLeftMargin};if(isRawImageTooWide&&isRawImageTooTall)if(isRawImageMoreHorizontalThanScreen)dimensions.t+=Math.floor((screenHeight-rawHeight*(screenWidth/rawWidth))/2);else dimensions.l+=
Math.floor((screenWidth-rawWidth*(screenHeight/rawHeight))/2);else if(isRawImageTooWide)dimensions.t+=Math.floor((screenHeight-rawHeight*(screenWidth/rawWidth))/2);else if(isRawImageTooTall)dimensions.l+=Math.floor((screenWidth-rawWidth*(screenHeight/rawHeight))/2);else{dimensions.w=rawWidth;dimensions.h=rawHeight;dimensions.t+=Math.floor((screenHeight-rawHeight)/2);dimensions.l+=Math.floor((screenWidth-rawWidth)/2)}var $modal=$('\x3cdiv class\x3d"modal-content modal-image-in-focus"\x3e\x3ci class\x3d"inline-content-img-full-close close"\x3e\x26#215;\x3c/i\x3e\x3cimg alt\x3d"" src\x3d"'+
src+'" class\x3d"modal-closer zoom-out" style\x3d"max-width:'+dimensions.w+"px;max-height:"+dimensions.h+'px;"/\x3e\x3c/div\x3e');$("body").append($modal);$modal.jqm({overlayClass:"overlay-image-in-focus",overlay:100,closeClass:"modal-closer",trigger:false,onShow:function(obj){obj.o.prependTo("body");obj.w.css({"margin-top":dimensions.t+"px","margin-left":dimensions.l+"px"}).fadeIn("1000");$w.on("scroll."+modalClass,function(ev){$modal.jqmHide()});$d.on("keyup."+modalClass,function(ev){if(ev.which==
27)$modal.jqmHide()});$(obj.w).find(".inline-content-img-full-close").on("click."+modalClass,function(ev){$modal.jqmHide()});$(".modal-image-in-focus").addClass("zoom-out")},onHide:function(obj){obj.w.fadeOut("500");obj.o.fadeOut("1500",function(){obj.o.remove()});$w.off("scroll."+modalClass);$d.off("keyup."+modalClass);$(obj.w).find(".inline-content-img-full-close").off("click."+modalClass);$(".modal-image-in-focus").removeClass("zoom-out")}});$img.on("click.modal",function(){$modal.jqmShow()})})}})};
var activateSidebar=function(){if(!sidebarActivated){sidebarActivated=true;handleScrollAndResize();var scroller=function(){handleScrollAndResize();resizeImages()};$window.scroll(scroller);$window.resize(scroller);for(var i=0;i<toRemove.length;i++)toRemove[i].remove();toRemove=[];debug("Activate sidebar (done)")}};var addSnippetToSidebar=function(selector){debug("Save initial scroll position");initialScroll=$body.scrollTop();debug("Finding new snippet");var div=article.find(selector);if(div.length==
0)return;debug("Removing signup form");signup.detach();debug("Emptying container");if(!devmode)container.empty();debug("Cloning content");var newdiv=div[0].cloneNode(true);newdiv.id=div[0].id+"-clone";debug("Adding content to container");container.prepend(newdiv);container.prepend(closer);debug("Instrumenting external links");$(newdiv).find("a").each(function(idx,a){$a=$(a);$a.attr("target","_blank");var href=$a.attr("href");href=updateUrlParam(href,"tid",selector.replace(/^#/,"").replace(/[^\w]/g,
"-"));$a.attr("href",href);$a.click(function(){trackEvent(href,"external")})});debug("Update image URLs");$(newdiv).find("img").each(function(idx,img){$img=$(img);$img.data("origsrc",$img.attr("src"))});resizeImages(true);if(div[0].className.match(/\kmap-series/)){debug("Re-adding signup");container.append(signup)}};var trackEvent=function(target,name){$.post("https://recommendation-hybrid.wpdigital.net/hybrid/hybrid-filter/kmapevent",{start:start,elapsed:Date.now()-start,event:name,target:target,
svi:sviFull,pr:pr,darwin:!!darwin,omniture:!!(window.s&&window.s.sendDataToOmniture),abdarwin:abdarwin,abvariant:abvariant||"default",location:document.location.toString(),logs:logs.join("\n")});if(name=="click"&&window.s&&window.s.sendDataToOmniture)try{s.sendDataToOmniture("Knowledge Map Click","event80",{eVar26:target})}catch(e){}};var trackVisibility=function(elem){VisSense(elem).monitor({visible:function(){var target=$(elem).attr("data-id");if(!visibility[target]){visibility[target]=true;trackEvent(target,
"visible")}}}).start()};var linkClicked=function(ev){debugGroupStart("Link clicked");debug("Activate sidebar");activateSidebar();debug("Setting selected class");article.find(selector+".selected").removeClass("selected");$(this).addClass("selected");debug("Emptying the sidebar");if(!devmode)ad.remove();footer.remove();closer.detach();debug("Finding data target");var target=$(this).attr("data-id");debug("Adding snippet to sidebar");addSnippetToSidebar("#"+target);debug("Showing container");container.addClass("visible");
debug("Handling body scroll");handleBodyscroll();debug("Tracking click");trackEvent(target,"click");debug("Adding new content (done)");debugGroupEnd()};var closerClicked=function(){$html.removeClass("kmapnoscroll");$body.scrollTop(initialScroll);closer.addClass("closing");container.addClass("closing");setTimeout(function(){closer.removeClass("closing");container.removeClass("closing");container.removeClass("visible")},250);article.find(selector+".selected").removeClass("selected")};var updateURL=
function(){var newurl=null;var loc=document.location.toString();var replace=window.history&&window.history.replaceState;if(replace){if(!/[?&#]kmap=1/.test(loc)){if(!/\?/.test(loc))newurl=loc.replace(/#.*/,"")+"?kmap\x3d1";else newurl=loc.replace(/#.*/,"")+"\x26kmap\x3d1";var idx=newurl.indexOf(document.location.pathname);history.replaceState({},"",newurl.substr(idx))}}else if(!/[?&#]kmap=1/.test(loc))document.location=loc.replace(/#.*/,"")+"#kmap\x3d1"};var setupSignup=function(){if(window.localStorage&&
localStorage.getItem("kmap-signup")){localStorage.removeItem("kmap-signup");var modal=$("#knowledge-map-signup-modal").detach();$body.append(modal);modal=modal.jqm({closeClass:"kmap-follow-modal-close"});modal.jqmShow()}signup=$("#knowledge-map-signup").detach();signup.find("input[name\x3dredirect]").attr("value",document.location.toString());signup.find("form").submit(function(){this.action=this.action.replace(/https/,"http");document.cookie="kmap-signup\x3d1"+";max-age\x3d"+3600*24*365+";expires\x3d"+
(new Date(Date.now()+3600*24*365*1E3)).toUTCString();if(window.localStorage)localStorage.setItem("kmap-signup",true)})};var setupSharelinks=function(){var sharer=function(element,elementObject,socialUrl,shareUrlLong,socialUrl2,style){var shareUrl="";var currentURL="";if(abvariant=="experiment"&&pr)currentURL="http://wapo.st/1RBmkx6";else if(abvariant=="experiment")currentURL="http://wapo.st/1HQVI0e";else currentURL="http://wapo.st/1K9YhkM";if(socialUrl.match(/mailto/)){shareUrl="mailto:?subject\x3d"+
encodeURIComponent(document.title);shareUrl=shareUrl+"\x26body\x3d"+encodeURIComponent(currentURL);window.location.href=shareUrl}else if(socialUrl.match(/whatsapp/)){shareUrl="whatsapp://send?text\x3d"+encodeURIComponent(document.title);shareUrl=shareUrl+" - "+encodeURIComponent(currentURL);window.location.href=shareUrl}else if(socialUrl.match(/twitter/)){shareUrl=socialUrl+encodeURIComponent(currentURL)+"\x26text\x3d"+encodeURIComponent(document.title);window.open(shareUrl,"share",style)}else{shareUrl=
socialUrl+encodeURIComponent(currentURL);window.open(shareUrl,"share",style)}return false};$(".top-sharebar-wrapper a, .social-tools-wrapper-bottom a").each(function(idx,item){if(item.postShare&&item.postShare.callPostShare)item.postShare.callPostShare=sharer})};init=function(){updateURL();$(".pb-f-article-article-body").addClass("kmap");article.find(".kmap-themes").addClass("active");var triggers=article.find(selector).addClass("active");triggers.click(linkClicked);triggers.each(function(idx,elem){trackVisibility(elem)});
closer=$("#kmap-modal-closer").detach();closer.click(closerClicked);setupSignup();var marker=$("#knowledge-map-sidebar");sidebar=marker.parent().parent();container=marker.parent();marker.remove();ad=sidebar.find(".pb-f-ad-flex");footer=sidebar.find(".pb-f-page-footer-v2");if(!devmode)addSnippetToSidebar(".kmap-snippet.kmap-series");if(window.innerWidth>768)container.addClass("visible");children=sidebar.children();for(var i=0;i<children.length;i++){var box=$(children[i]);if(!box.hasClass("pb-f-ad-flex")&&
!box.hasClass("pb-f-page-footer-v2")&&!box.hasClass("pb-f-knowledge-map-knowledge-map"))if(!devmode)box.remove();else if(!/pf-f-ad/.test(children[i].className))toRemove.push(box)}setTimeout(setupSharelinks,500)};initNoKmap=function(){setupSignup();$("#signup-box-rr").empty().append(signup).show();article.find(selector).each(function(idx,elem){trackVisibility(elem)})}})(jQuery,wp_pb);
(function($){$(window.document).on("abtest-ready",function(e,ABT){var variation=ABT.get("recommendation-mostread");if(variation.is("chartbeat")){$("ul.def-feed").hide();$("ul.alt-feed").show()}})})(jQuery);

(function($){var deviceWidth=window.innerWidth>0?window.innerWidth:screen.width;var defaultNewsLetter={frequency:"Daily",headline:"Get the Today's Headlines Newsletter",id:"post_newsletter1",name:"Today's Headlines",tagline:"Free daily updates delivered just for you.",template:"signup-confirm-heads",variable:"vars[intent_heads]"},defaultNewsLetters=[{frequency:"Daily",headline:"Get the Today's Headlines Newsletter",id:"post_newsletter1",name:"Today's Headlines",tagline:"Free daily updates delivered just for you.",
template:"signup-confirm-heads",variable:"vars[intent_heads]"},{frequency:"Daily",headline:"Get the Read In Newsletter",id:"post_newsletter112",name:"Read In",tagline:"Free daily updates delivered just for you.",template:"signup-confirm-readin",variable:"vars[intent_readin]"},{frequency:"Weekly",headline:"Get the Lean \x26 Fit Newsletter",id:"post_newsletter8",name:"Lean \x26 Fit",tagline:"Free weekly updates delivered just for you.",template:"signup-confirm-lean",variable:"vars[intent_lean]"},{frequency:"Twice-weekly",
headline:"Get the Checkpoint Newsletter",id:"post_newsletter130",name:"Checkpoint",tagline:"Free twice-weekly updates delivered just for you.",template:"signup-confirm-check",variable:"vars[intent_check]"}],subscribeEmail,washPostId,showNewsletter=function(){$("#signup-box-rr").show()},hideNewsletter=function(){$("#signup-box-rr").hide()},showSignUpForm=function(){$("#newsletter-signUp-form").show();$("#newsletter-signUp-button").hide()},showSignUpButton=function(){$("#newsletter-signUp-form").hide();
$("#newsletter-signUp-button").show()},showErrorMessage=function(message){if(message)$(".newsLetter-error-msg").text(message).show()},hideErrorMessage=function(){$(".newsLetter-error-msg").hide()},setNewsLetterValue=function(data){$("#newsletter-headline").append(data.headline);$("#newsletter-tagline").text(data.blurb)},setRecommendationsValues=function(data){$(".suggestion-list .recommended").each(function(index){$(this).find("p").text(data[index].headline);$(this).find("input[type\x3d'checkbox']").attr("value",
data[index].id);$(this).find("input[type\x3d'checkbox']").attr("name",data[index].name)})},toggleRecommendations=function(show){if(show){$("#newsletter-signUp-form, #newsletter-signUp-button, #newsletter-tagline").hide();$("#newsletter-suggestions-rr, #headline-checked, #subscribed-confirmation, #all-newsletters-lbl").show()}else $("#newsletter-suggestions-rr").hide()},showSignUpConfirmation=function(){$("#newsletter-signUp-form, #newsletter-signUp-button, #newsletter-tagline").hide();$("#headline-checked, #subscribed-confirmation, #all-newsletters-lbl").show()},
getUserId=function(){return document.cookie.match(/wapo_login_id=([^;]+)/)?RegExp.$1:""},getWapoId=function(){return document.cookie.match(/wapo_secure_login_id=([^;]+)/)?RegExp.$1:""},getPageData=function(){var section=$("#newsletter-section").text(),subSection=$("#newsletter-subsection").text(),blog=$("#newsletter-blogname").text(),data={};washPostId=getUserId();if(washPostId!=="")data.washPostId=washPostId;if(blog)data.blog=blog;if(subSection)data.subSection=subSection;if(section)data.section=
section;return data},getMainNewsletter=function(){var data=getPageData();return $.ajax({type:"POST",dataType:"json",contentType:"application/json",url:"https://recommendation-newsletter.wpdigital.net/Newsletter/api/newsletter",data:JSON.stringify(data)})},getRecommendations=function(newsletters){var data=getPageData();data.newsletters=newsletters;return $.ajax({type:"POST",dataType:"json",contentType:"application/json",url:"https://recommendation-newsletter.wpdigital.net/Newsletter/api/newsletters",
data:JSON.stringify(data)})},subscribe=function(email){var data,url;if(washPostId!==""){url="https://subscribe.washingtonpost.com/person/newsletter/subscribe";data={"wapoLoginID":washPostId,"wapoSecureID":getWapoId(),"userAgent":navigator.userAgent,"newsletterName":window.Newsletter.id,"metadata":[{"name":"nl_start_method","value":"EI"},{"name":"nl_start_location","value":"RR"}]}}else if(email){url="https://subscribe.washingtonpost.com/person/newsletter/subscribe-email";data={"email":email,"newsletterName":window.Newsletter.id,
"metadata":[{"name":"nl_start_method","value":"EI"},{"name":"nl_start_location","value":"RR"}]}}$.ajax({type:"POST",dataType:"json",contentType:"application/json",url:url,data:JSON.stringify(data),success:function(data){if(data.status=="SUCCESS"){sendCustomTrackProps("event91",trackProps(window.Newsletter.name,1,"simple"),"Newsletter Right Rail Sign-up");setUpRecommendations(window.Newsletter.id)}},error:function(request,status,error){console.log(error,"Error while subscribing")}})},subscribeBundle=
function(){var data,url,newsletters=[],newsletterNames=[];$("#newsletter-suggestions-rr input:checked").each(function(index){newsletters.push($(this).val());newsletterNames.push({name:$(this).attr("name"),position:$(this).attr("data-pos")})});if(newsletters.length>0&&newsletterNames.length>0){if(washPostId!==""){url="https://subscribe.washingtonpost.com/person/newsletter/subscribe-list";data={"wapoLoginID":washPostId,"wapoSecureID":getWapoId(),"userAgent":navigator.userAgent,"newsletters":newsletters,
"metadata":[{"name":"nl_start_method","value":"EA"},{"name":"nl_start_location","value":"RR"}]}}else if(subscribeEmail){url="https://subscribe.washingtonpost.com/person/newsletter/subscribe-list-email";data={"email":subscribeEmail,"newsletters":newsletters,"metadata":[{"name":"nl_start_method","value":"EA"},{"name":"nl_start_location","value":"RR"}]}}$.ajax({type:"POST",dataType:"json",contentType:"application/json",url:url,data:JSON.stringify(data),success:function(data){if(data.status=="SUCCESS"){for(var i=
0;i<newsletterNames.length;i++)sendCustomTrackProps("event91",trackProps(newsletterNames[i].name,newsletterNames[i].position,"enhanced"),"Newsletter Right Rail Sign-up Bundle");setUpRecommendations(newsletters,true);toggleRecommendations(false)}},error:function(request,status,error){console.log(error,"Error while subscribing bundle")}})}},setUpRecommendations=function(newsletterId,confirmBundleSubscribe){var recommendations=getRecommendations([window.Newsletter.id]);recommendations.done(function(data){if(!$.isEmptyObject(data.newsletters)&&
data.newsletters.length>=3&&!confirmBundleSubscribe){window.Newsletters=data.newsletters;setRecommendationsValues(data.newsletters);toggleRecommendations(true);for(var i=0;i<data.newsletters.length-1;i++)sendCustomTrackProps("event59",trackProps(data.newsletters[i+1].name,i+1,"enhanced"),"Newsletter Right Rail Show Recommendations")}else toggleRecommendations(false);showSignUpConfirmation()});recommendations.fail(function(){if(!confirmBundleSubscribe){window.Newsletters=defaultNewsLetters;setRecommendationsValues(defaultNewsLetters);
toggleRecommendations(true)}})},setUpMainNewsletter=function(newsletter){window.Newsletter=newsletter;setNewsLetterValue(newsletter);showNewsletter();if(getUserId()!=="")showSignUpButton();else showSignUpForm();$(window).off("scroll.newsletterRR").on("scroll.newsletterRR",onVisibilityChange($(".pb-f-page-newsletter"),function(){sendCustomTrackProps("event59",trackProps(window.Newsletter.name,1,"simple"),"Newsletter Right Rail displayed in viewport");$(window).off("scroll.newsletterRR")}))},applyRrNewsletters=
function(variant,version){var mainNewsletter=getMainNewsletter();mainNewsletter.done(function(data){if(!$.isEmptyObject(data.newsletter))setUpMainNewsletter(data.newsletter);else hideNewsletter()});mainNewsletter.fail(function(){setUpMainNewsletter(defaultNewsLetter);sendCustomTrackProps("event50",trackProps(defaultNewsLetter.name,1),"Newsletter Right Rail API failure case")});$(".subscribe-newsLetter").click(function(){var re=/[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}/igm;subscribeEmail=$("#newsLetter-input").val();
if(this.id!=="newsletter-signUp-button"&&(subscribeEmail==""||!re.test(subscribeEmail)))showErrorMessage("Please enter a valid email address");else{hideErrorMessage();subscribe(subscribeEmail)}return false});$("#subscribe-bundle").click(function(){subscribeBundle()});$("#cancel-bundle").click(function(){sendCustomTrackProps("event58",trackProps(),"No Thanks, Newsletter Right Rail Sign-up Bundle");toggleRecommendations(false)})};$(window.document).on("abtest-ready",function(e,ABT){if(deviceWidth>460)if(window.TWP.Data.Tracking.props.content_type==
"front")applyRrNewsletters();else if(window.TWP.Data.Tracking.props.content_type=="blog"||window.TWP.Data.Tracking.props.content_type=="article"){var testArticle=ABT.get("newsletters-articleUnits");if(!testArticle.is("banner")&&!testArticle.is("bottom"))applyRrNewsletters(testArticle)}else applyRrNewsletters()});function trackProps(newsletterName,index,enhancedKey){var subsection=window.wp_subsection||"";var contentType=window.wp_content_type||"";var channel=window.wp_channel||"";var props={"eVar2":"wp - "+
subsection,"prop2":"wp - "+subsection,"prop3":contentType,"eVar17":contentType,"channel":channel};if(newsletterName&&index)props.eVar26="nl_rightrail_"+enhancedKey+"_"+newsletterName.toLowerCase().split(" ").join("-")+"_"+index;return props}function sendCustomTrackProps(eventKey,props,name){if(!!window.s)window.s.sendDataToOmniture(name||"PB Feature - Page-Newsletter",eventKey,props,{wait:true})}function onVisibilityChange(el,callBack){return function(){if(isElementInViewport(el))callBack()}}function isElementInViewport(el){if(typeof jQuery===
"function"&&el instanceof jQuery)el=el[0];var rect=el.getBoundingClientRect();return rect.top>=0&&rect.left>=0&&rect.bottom<=(window.innerHeight||document.documentElement.clientHeight)&&rect.right<=(window.innerWidth||document.documentElement.clientWidth)}})(jQuery);
(function($){try{function cleanUp(){$("li","#editors-picks-rr").each(function(i){var $this=$(this);var $headline=$(".headline",$this);var $number=$(".number",$this);var lineHeight=parseInt($headline.css("lineHeight"));if($headline.height()<=2*lineHeight)$headline.css({"padding-top":"7px","padding-bottom":"8px"});else if($headline.height()>3*lineHeight)while($headline.height()>3*lineHeight){$headline.text($headline.text().replace(/\.\.\.$/,""));$headline.text($headline.text().slice(0,-1));$headline.text($headline.text()+
"...")}})}cleanUp()}catch(e){}})(jQuery);
(function($,TWP){var applyStickiness=function(){var $window=$(window),$ad=$(".pb-f-ad-flex-3"),$nextStory=$(".pb-f-article-next-story"),$leaderboardAd=$(".pb-f-ad-leaderboard-2"),$rightRail=jQuery("#right-rail"),slotId="slug_flex_ss_bb_hp_3";if(!$rightRail.length)$rightRail=$ad.prev();$ad.on("DOMNodeInserted",function(e){var $el=$(e.target),id=$el.attr("id");if($el.is("iframe")&&id&&!/(hidden)/g.test(id)){$ad.off("DOMNodeInserted");afterAdInserted($el)}});var bindScrollDown=function(){var original_top=
$ad.offset().top,scrollTop,ad_left=$rightRail.offset().left,adWidth=$rightRail.width(),min_left=618;var getStopPoint=function(){var leaderboardAdTop=$leaderboardAd.length?$leaderboardAd.offset().top:$(document).height();var featureTop=$nextStory.is(":visible")?$nextStory.offset().top:leaderboardAdTop;return featureTop-$ad.height()-50};var applySticky=function(scrollTop){var stopPoint=getStopPoint();if(scrollTop>stopPoint){if($ad.hasClass("sticky")){$ad.removeClass("sticky");$ad.css({"top":stopPoint,
"position":"absolute"})}}else if(!$ad.hasClass("sticky")&&ad_left>min_left){$ad.css({"top":100,"left":ad_left,"width":adWidth,"position":"initial"});$ad.addClass("sticky")}};var removeSticky=function(){if($ad.hasClass("sticky")){$ad.attr("style","");$ad.removeClass("sticky")}};$window.off("scroll.flexAd3-sticky").on("scroll.flexAd3-sticky",function(){scrollTop=$window.scrollTop();if(scrollTop>original_top)applySticky(scrollTop);else removeSticky()});$window.off("resize.flexAd3-sticky").on("resize.flexAd3-sticky",
function(){ad_left=$rightRail.offset().left;if($ad.is(":visible")&&$ad.hasClass("sticky"))if(ad_left>min_left)$ad.css({"left":ad_left});else removeSticky()});$ad.on("flexAd3.remove_sticky",function(){$window.off("scroll.flexAd3-sticky");$window.off("resize.flexAd3-sticky");removeSticky()})};function startSticky(){if(!TWP.Features.Ad.flexAd3.sticky)return;if($ad.is(":visible"))bindScrollDown();else $window.on("resize.flexAd3-invisible",function(){if($ad.is(":visible"))bindScrollDown();else $ad.trigger("flexAd3.remove_sticky")})}
var afterAdInserted=function(){if(window.googletag&&googletag.pubadsReady)googletag.pubads().addEventListener("slotRenderEnded",function(event){if(event.slot.getSlotElementId()===slotId)startSticky()})}};if(TWP.Features.Ad.flexAd3&&TWP.Features.Ad.flexAd3.sticky)applyStickiness()})(jQuery,TWP);
(function($){TWP=window.TWP||{};TWP.PostTV=TWP.PostTV||{};TWP.PostTV.StickyPlayer=TWP.PostTV.StickyPlayer||{};var $root=$($(".pb-f-posttv-sticky-player")),$subRoot=$root.find(".posttv-sticky-player-video"),$vidWrapper=$root.find(".posttv-sticky-player-wrapper"),$textEl=$root.find(".posttv-sticky-player-text"),$caption=$root.find(".posttv-sticky-player-caption");TWP.PostTV.StickyPlayer.showPlayer=function(){$subRoot.removeClass("wpv-hidden")};TWP.PostTV.StickyPlayer.hidePlayer=function(){$subRoot.addClass("wpv-hidden")};
TWP.PostTV.StickyPlayer.showText=function(){$textEl.removeClass("wpv-hidden")};TWP.PostTV.StickyPlayer.hideText=function(){$textEl.addClass("wpv-hidden")};TWP.PostTV.StickyPlayer.updateBlurb=function(newBlurb){$caption.html(newBlurb)};var adjustSize=function(){var stickyWidth=$(window).width()*.3+12;if(stickyWidth>492)stickyWidth=492;else if(stickyWidth<156)stickyWidth=156;$root.css({"width":stickyWidth});$vidWrapper.css({"width":stickyWidth-12});$vidWrapper.css({"height":$vidWrapper.width()*9/16})};
$(window).off("resize.stickyPlayerResize").on("resize.stickyPlayerResize",function(){adjustSize()});adjustSize();function isElementInViewport(el,fract){if(typeof jQuery==="function"&&el instanceof jQuery)el=el[0];var fraction=fract||.8;var rect=el.getBoundingClientRect();var topOffsetAdjustment=0,$navBarEl=$("#nav-bar"),$breakingNewsEl=$(".pb-f-page-breaking-news-bar"),$shareBarEl=$(".top-sharebar-wrapper",".pb-f-sharebars-top-share-bar");if($navBarEl.length>0)topOffsetAdjustment+=$navBarEl.height();
if($breakingNewsEl.length>0)topOffsetAdjustment+=$breakingNewsEl.height();return rect.top+el.offsetHeight*fraction>=topOffsetAdjustment&&rect.left>=0&&rect.bottom-el.offsetHeight*fraction<=(window.innerHeight||document.documentElement.clientHeight)&&rect.right<=(window.innerWidth||document.documentElement.clientWidth)||rect.top<0&&rect.bottom>(window.innerHeight||document.documentElement.clientHeight)}var $players=$(".posttv-video-embed");var throttleInterval=5;var waitInterval=400;var lastTime=(new Date).getTime();
var isOut=false;var playerOutId;var waitTimeout;var $target=$("#posttv-sticky-player-wrapper");var $stickyClose=$(".posttv-sticky-player-exit");var outTracker=false;var closeTracker=false;var WAIT=false;function getExceptions(){var url="//projects.posttv.com/siteconfig/settings.json";$.getJSON(url,function(data){var excludeUrls=data["sticky-player-exclude-urls"];var isException=false;excludeUrls.forEach(function(url){if(window.location.href.indexOf(url)>-1)isException=true});if(!isException)initEventHandlers()})}
function safetyCheck(cb){clearTimeout(waitTimeout);waitTimeout=setTimeout(function(){WAIT=true;cb&&cb()},waitInterval)}function moveOut(id,$el,playerEmbed){if(!outTracker){playerEmbed.reportEvent("event8888","Sticky Player initialized");outTracker=true}playerOutId=id;isOut=true;$root.removeClass("wpv-hidden");clearTimeout(waitTimeout);if($target.get(0).style.display!="none")playerEmbed.animateTo($el,{fixed:true,zIndex:536870903,cb:function(){if(isOut)TWP.PostTV.StickyPlayer.showPlayer()}})}function moveBack($el,
playerEmbed){TWP.PostTV.StickyPlayer.hidePlayer();safetyCheck(function(){playerEmbed.animateTo($el,{cb:function(){WAIT=false}})});$root.addClass("wpv-hidden");isOut=false}function checkPlayers(){var $el=$($players.get(0));if($el.data("aspect-ratio")<.56||$el.data("aspect-ratio")>.57)return true;var id=$el.attr("id");var hasBeenVisible=$el.data("has-been-visible");var player=window.TWP&&TWP.PostTV&&TWP.PostTV.players?TWP.PostTV.players[id]:null;var playerEmbed=window.TWP&&TWP.PostTV&&TWP.PostTV.embeds?
TWP.PostTV.embeds[id]:null;var $wrap=$el.parent().hasClass("wpv-wrap")?$el.parent():$el.parent().parent().hasClass("wpv-wrap")?$el.parent().parent():null;if($wrap&&player&&player.player&&hasBeenVisible&&!closeTracker)if(isElementInViewport($wrap)&&isOut&&playerOutId===id)moveBack($wrap,playerEmbed);else if(!isElementInViewport($wrap)&&!isOut&&player.player.getState()==="playing")moveOut(id,$target,playerEmbed)}function initEventHandlers(){$(window).scroll(function(){var time=(new Date).getTime();
if(time-lastTime>throttleInterval&&isMobile&&!isMobile.any()&&!WAIT){lastTime=time;checkPlayers()}});$(window).resize(function(){if(isOut&&playerOutId)TWP.PostTV.embeds[playerOutId].animateTo($target,{fixed:true,speed:10,zIndex:536870903})});$stickyClose.click(function(){var playerEmbed=playerOutId?TWP.PostTV.embeds[playerOutId]:null;var player=TWP.PostTV.players[playerOutId];if(!closeTracker){playerEmbed.reportEvent("event8889","Sticky Player closed");closeTracker=true}if(playerEmbed){player.pause();
moveBack($("#"+playerOutId).parent(),playerEmbed)}})}var waitForPubSub=setInterval(function(){if(typeof PubSub!=="undefined"){clearInterval(waitForPubSub);PubSub.subscribe("playerCreated",function(msg,data){if(data.playerType!=="posttv-embed")return;var $el=$("#"+data.playerContainerId);$el.addClass("wpv-sticky");var $wrap=$el.parent().hasClass("wpv-wrap")?$el.parent():null;var playerEmbed=TWP&&TWP.PostTV&&TWP.PostTV.embeds?TWP.PostTV.embeds[$el.attr("id")]:null;if(!$wrap&&playerEmbed)playerEmbed.wrap()})}},
200);getExceptions();$(function(){$root.addClass("wpv-hidden")})})(jQuery);
(function(window,$,TWP){var console=new TWP.Tools.logger("re-engage");$.fn.idle=function(options){var defaults={idle:6E4,events:"mousemove keydown mousedown touchstart",onIdle:function(){},onActive:function(){},onHide:function(){},onShow:function(){},keepTracking:true,startAtIdle:false,recurIdleCall:false},idle=options.startAtIdle||false,visible=!options.startAtIdle||true,settings=$.extend({},defaults,options),lastId=null,resetTimeout,timeout;$(this).on("idle:stop",{},function(event){$(this).off(settings.events);
settings.keepTracking=false;resetTimeout(lastId,settings)});resetTimeout=function(id,settings){if(idle){settings.onActive.call();idle=false}clearTimeout(id);if(settings.keepTracking)return timeout(settings)};timeout=function(settings){var timer=settings.recurIdleCall?setInterval:setTimeout,id;id=timer(function(){idle=true;settings.onIdle.call()},settings.idle);return id};return this.each(function(){lastId=timeout(settings);$(this).on(settings.events,function(e){lastId=resetTimeout(lastId,settings)});
if(settings.onShow||settings.onHide)$(document).on("visibilitychange webkitvisibilitychange mozvisibilitychange msvisibilitychange",function(){if(document.hidden||document.webkitHidden||document.mozHidden||document.msHidden){if(visible){visible=false;settings.onHide.call()}}else if(!visible){visible=true;settings.onShow.call()}})})};var ReEngageMonitor=function(){var callback;var direction="unknown";var lastDate=-1;var lastScrollTop=-1;var thisMinimumTrackingDelayInMs=250;function init(callbackMethod){callback=
callbackMethod;window.addEventListener("scroll.reEngage",function(e){e.preventDefault();var scrollTop=$(this).scrollTop();e.timeStamp=(new Date).getTime();didScroll(e.timeStamp,scrollTop)},true);$(window).on("scroll.reEngage",function(e){var scrollTop=$(this).scrollTop();e.timeStamp=(new Date).getTime();didScroll(e.timeStamp,scrollTop)});$(window).on("touchstart",function(e){var scrollTop=$(this).scrollTop();didScroll(e.timeStamp,scrollTop)})}function didScroll(timeStamp,scrollTop){if(lastDate+thisMinimumTrackingDelayInMs<=
timeStamp){var offset=Math.abs(scrollTop-lastScrollTop);var direction=getDirection(scrollTop);var delayInMs=timeStamp-lastDate;var speedInPxPerMs=offset/delayInMs;if(speedInPxPerMs>0)callback(speedInPxPerMs,timeStamp,direction);lastDate=timeStamp}}function getDirection(scrollTop){var currentScrollTop=lastScrollTop;lastScrollTop=scrollTop;if(currentScrollTop>-1){if(currentScrollTop>=scrollTop)return"up";return"down"}return"unknown"}function reset(){direction="unknown";lastDate=-1;lastScrollTop=-1}
return{init:init}}();var ReEngageScroller=function(){var direction="unknown";var jQueryElement=null;var targetHeight=$(document).height();var requiredSpeedInPxPerMs=3;var $storyContainer=null;function init(starOverlay,clickThru){jQueryElement=starOverlay;$storyContainer=starOverlay.find(".re-engage-secondary");$(document).on("click",".re-engage-close",function(event){if($(this).hasClass("fa-chevron-down")||$(this).hasClass("fa-remove")){shrinkScroller();trackingFeature("collapse","event80")}});$(document).on("click",
".js-re-engage-sm",function(event){growScroller();trackingFeature("expand","event80")});$(document).on("click",".re-engage-ad-close",function(event){hideBigLogo()});$(document).on("click",".re-engage-ad-sm",function(event){hideSmallLogo()});ReEngageMonitor.init(function(speedInPxPerMs,timeStamp,newDirection){if(direction!=newDirection){jQueryElement.removeClass("up down").addClass(newDirection);direction=newDirection}var visible=jQueryElement.is(":visible");if(requiredSpeedInPxPerMs<=speedInPxPerMs)if(jQueryElement.length&&
!visible){$(".js-re-engage-click").on("click",function(event){event.preventDefault();window.open(clickThru)});if($("#floating-bb-content").length)return;disableAd();jQueryElement.css("opacity",1).fadeIn(3E3);if(TWP.Features.Page.ReEngage.isCarousel)repositionSlick($storyContainer);$(document).trigger("idle:stop");trackingFeature("show","event66");ReEngageRendering.trackDisplay();$(window).off("scroll.reEngage")}})}function repositionSlick($storyContainer){if(!$storyContainer.hasClass("slick-initialized"))$storyContainer.on("init",
function(){$storyContainer.slick("setPosition")});else $storyContainer.slick("setPosition")}function shrinkScroller(){var min_height=$(".re-engage-big").data("min-height");$(".re-engage-big").animate({height:min_height+"px"},function(){$(this).addClass("js-re-engage-sm");$(this).find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up")})}function growScroller(){var max_height=$(".re-engage-big").data("max-height");$(".re-engage-big").animate({height:max_height+"px"},function(){$(this).removeClass("js-re-engage-sm");
$(this).find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down")})}function hideBigLogo(){$(".re-engage-ad-big").slideUp("slow",function(){$(".re-engage-ad-sm").slideDown("slow");jQueryElement.css("opacity",1)})}function hideSmallLogo(){$(".re-engage-ad-sm").slideUp("slow",function(){$(".re-engage-ad-big").slideDown("slow");jQueryElement.css("opacity",1)})}return{init:init}}();var ReEngageRendering=function(){var client,displayStoryNum;function _failure(){$(".re-engage-wrapper").remove();
$(window).off("scroll.reEngage")}function render(recommendations){if(!recommendations||recommendations.length===0)return _failure();var content="",$storyContainer=$(".re-engage-secondary"),recommendation;for(var i=0;i<recommendations.length;i++){recommendation=recommendations[i];if(i<displayStoryNum)content+=renderItem(recommendation,i)}if($storyContainer.length&&content){$storyContainer.html(content);trackClick($storyContainer);if(TWP.Features.Page.ReEngage.isCarousel){$storyContainer.slick({arrows:true,
rtl:false});$storyContainer.on("afterChange",function(event,slick,currentSlide,nextSlide){var eVar26="swipe-"+currentSlide;trackingFeature(eVar26,"event80")})}}}function renderItem(recommendation,index){var img='\x3cimg alt\x3d"" src\x3d"'+renderImgURL(recommendation,75,75)+'"'+' data-hi-res-src\x3d"'+renderImgURL(recommendation,75,75)+'"'+' data-low-res-src\x3d"'+renderImgURL(recommendation,75,75)+'"'+' data-threshold\x3d"112" class\x3d"re-engage-photo"\x3e';return'\x3cdiv class\x3d"re-engage-recommend"\x3e\x3ca href\x3d"'+
recommendation.url+"?tid\x3da_reengage-"+index+'" class\x3d"re-engage-text-link"\x3e'+img+'\x3cdiv class\x3d"re-engage-headline"\x3e'+recommendation.headline+"\x3c/div\x3e\x3c/a\x3e\x3c/div\x3e"}function renderImgURL(recommendation,w,h){var url=recommendation.photo.path;return"https://img.washingtonpost.com/wp-apps/imrs.php?src\x3d"+encodeURIComponent(url)+"\x26w\x3d"+w+"\x26h\x3d"+h}function trackClick($storyContainer){$storyContainer.on("click","a",null,function(ev){var link=this,href=link.href;
client.clicked(href);setTimeout(function(){document.location=href},200);return false})}function trackDisplay(){client.rendered()}function preload(){displayStoryNum=1;if(TWP.Features.Page.ReEngage.isCarousel)displayStoryNum=3;client=new TWP.Perso.Recommend("re-engage-v1",displayStoryNum);client.recommend().done(function(data){render(data["results"])}).fail(_failure)}return{preload:preload,trackDisplay:trackDisplay}}();var enableReEngage=function(){var $scrollStars=$(".re-engage-wrapper"),$closeIcon=
$(".re-engage-close");if($scrollStars.length&&wp_pb.BrowserInfo.mobile_browser&&!wp_pb.BrowserInfo.tablet){ReEngageRendering.preload();TWP.Features.Page.ReEngage.isCarousel?$closeIcon.addClass("fa-remove"):$closeIcon.addClass("fa-chevron-down");var idleTimeInMiliseconds=3E4;console.log("Inactive start");$(document).idle({onIdle:function(){console.log("Showing re-engage");var $engageElm=$(".re-engage-wrapper");disableAd();if($engageElm.length&&!$engageElm.is(":visible")&&!$("#floating-bb-content").length){$(document).trigger("idle:stop");
$engageElm.css("opacity",1).fadeIn(1500);if(TWP.Features.Page.ReEngage.isCarousel)$(".re-engage-secondary").slick("setPosition");trackingFeature("show","event66");ReEngageRendering.trackDisplay()}},events:"mousemove keydown mousedown touchstart scroll",idle:idleTimeInMiliseconds});ReEngageScroller.init($scrollStars)}};var disableAd=function(){var $bottomAd=$("#slug_fixedBottom");if($bottomAd.length)$bottomAd.remove();else $("body").on("DOMNodeInserted",function(e){var $el=$(e.target),id=$el.attr("id");
if($el.is("div")&&id&&id==="slug_fixedBottom")$el.remove()})};var trackingFeature=function(ev,eNum){if(typeof window.sendDataToOmniture==="function"){var eventName="reengage-"+ev,varName="a_reengage-"+ev,subsection=window.wp_subsection;if(subsection.indexOf("wp")<0)subsection="wp - "+subsection;var data={pageName:window.wp_page_name,eVar1:window.wp_page_name,prop2:subsection,eVar2:window.wp_channel,prop3:window.wp_content_type,eVar17:window.wp_content_type,eVar26:varName};sendDataToOmniture(eventName,
eNum,data)}};$(window.document).on("abtest-ready",function(e,ABT){var test=ABT.get("reengage-recommend_i3");if(test.is("carousel"))TWP.Features.Page.ReEngage.isCarousel=true})})(window,jQuery,TWP);
(function($){})(jQuery);
(function($,window){function noticeError(app,error,context){$.ajax("https://errors.perso.nile.works/error",{contentType:"application/json",processData:false,dataType:"json",type:"POST",data:JSON.stringify({app:app,error:error,context:context,location:document.location.toString()})})}var svi="";var sviFull=document.cookie.match(/s_vi=([^;]+)/)?RegExp.$1:"";try{if(sviFull&&sviFull!==""){svi=sviFull.replace(/.*\|/,"").replace(/\[.*/,"").split("-");svi=svi[0]+"-"+svi[1]}}catch(e){svi=""}var loxodoId=
null;try{loxodoId=localStorage.getItem("wp_vi")}catch(e){}var ttlForusersegments=1;function getHoursSinceLastTime(lastTime){var datetime=(new Date(lastTime)).getTime();var now=(new Date).getTime();var milisec_diff=null;if(isNaN(datetime))return ttlForusersegments+1;if(datetime<now)milisec_diff=now-datetime;else milisec_diff=datetime-now;var date_diff=Math.floor(milisec_diff/1E3/60/60);return date_diff}function isParamValid(variable){return variable!==null&&variable!=="null"}function isUserSegmentsInvalidOrStale(){usersegments=
localStorage.getItem("usersegments");if(!isParamValid(usersegments))return true;else{var json=JSON.parse(usersegments);var usersegmentsstoragetime=json.updated;if(getHoursSinceLastTime(usersegmentsstoragetime)>=ttlForusersegments)return true}return false}function saveKeyValue(key,value){if(window.localStorage){localStorage.setItem(key,value);if(window.JSON){var obj=localStorage.getItem("usersegmentsAdops");if(!obj)obj={};else obj=JSON.parse(obj);obj[key]=value;localStorage.setItem("usersegmentsAdops",
JSON.stringify(obj))}}}function setCookies(data){if(!data||!data.segmentsFlag||!data.segmentsFlag["7688613820"])return;document.cookie="us.7688613820\x3d"+data.segmentsFlag["7688613820"]+";expires\x3d"+(new Date(Date.now()+365*24*3600*1E3)).toUTCString()+";domain\x3d"+"."+document.location.hostname.split(".").slice(-2).join(".")+";path\x3d/"}function setAdopsData(data){var value=null;if(data&&data.segmentsFlag){value=data.segmentsFlag["7978704408"];if(value=="8936"){saveKeyValue("8936",1);saveKeyValue("9868",
0);saveKeyValue("6136",0)}else if(value=="9868"){saveKeyValue("8936",0);saveKeyValue("9868",1);saveKeyValue("6136",0)}else if(value=="6136"){saveKeyValue("8936",0);saveKeyValue("9868",0);saveKeyValue("6136",1)}else{saveKeyValue("8936",0);saveKeyValue("9868",0);saveKeyValue("6136",0)}value=data.segmentsFlag["5497328667"];if(value=="7204"){saveKeyValue("7204",1);saveKeyValue("0862",0);saveKeyValue("2467",0);saveKeyValue("0668",0)}else if(value=="0862"){saveKeyValue("7204",0);saveKeyValue("0862",1);
saveKeyValue("2467",0);saveKeyValue("0668",0)}else if(value=="2467"){saveKeyValue("7204",0);saveKeyValue("0862",0);saveKeyValue("2467",1);saveKeyValue("0668",0)}else{saveKeyValue("7204",0);saveKeyValue("0862",0);saveKeyValue("2467",0);saveKeyValue("0668",1)}var newsletters=["6362","3552","3433","7543","8636","5723","2748","3522","5263"];var list=[];value=data.segmentsFlag["1599213719"];if(value&&value.length>0)list=value.split(",");for(var i=0;i<newsletters.length;i++){var nl=newsletters[i];if(list.indexOf(nl)>
-1)saveKeyValue(nl,1);else saveKeyValue(nl,0)}}}if(window.localStorage&&window.JSON)if(isUserSegmentsInvalidOrStale())$.ajax("https://usersegment.wpdigital.net/usersegments",{type:"POST",dataType:"json",processData:false,contentType:"application/json",data:'{"userid": "'+svi+'"}'}).done(function(data){if(isParamValid(data)){setCookies(data);setAdopsData(data);data.updated=new Date;localStorage.setItem("usersegments",JSON.stringify(data))}}).fail(function(errorResponse){noticeError("usersegments",
"ajax-error",errorResponse)});var hasStorage=function(){var storageTest=new Date;try{localStorage.setItem(storageTest,storageTest);localStorage.removeItem(storageTest);return true}catch(e){return false}}();function normalizeURL(url,params){var str=(url||"").trim();str=str.replace(/^(https?:)?\/\//,"");str=str.replace(/\?.*/,"");if(params)str=str.replace(/\/$/,"");return str}function extractParam(param){var rgx=new RegExp(".*[?\x26]"+param+"\x3d([^\x26]+).*");if(rgx.test(document.location.toString()))return document.location.toString().replace(rgx,
"$1");else return""}var clavisAuxiliaries=window.wp_meta_data&&wp_meta_data.clavis&&wp_meta_data.clavis.auxiliaries,canonicalUrl=$('link[rel\x3d"canonical"]').attr("href"),userId=!!document.cookie.match(/s_vi=([^;]+)/)?RegExp.$1:"unavailable";if(!canonicalUrl)canonicalUrl=[window.location.host,window.location.pathname].join("");var contentType="";try{contentType=TWP.Data.Tracking.props.content_type}catch(e){}var dataPayload={"articleid":normalizeURL(canonicalUrl,true),"referrer":normalizeURL(document.referrer),
"contentType":contentType,"wpisrc":extractParam("wpisrc"),"tid":extractParam("tid"),"userid":userId,"uuid":!!document.cookie.match(/wapo_login_id=([^;]+)/)?RegExp.$1:"","auxiliaries":!!clavisAuxiliaries?clavisAuxiliaries:[],"wp_meta_data":window.wp_meta_data||null,"isMobile":window.isMobile&&window.isMobile.any()};var targetingServerUrl=TWP&&TWP.Features&&TWP.Features.Page&&TWP.Features.Page.Targeting&&TWP.Features.Page.Targeting.endpointServer;$.ajax({url:!!targetingServerUrl?targetingServerUrl:
"//targeting.wpdigital.net/TargetingWebAPP/targeting",type:"POST",contentType:"application/json",dataType:"JSON",data:JSON.stringify(dataPayload)}).done(function(response){if(hasStorage)if(!!response){var auxMap=response.aux_map&&response.aux_map.join(",");if(auxMap)localStorage.setItem("targeting_aux_map",auxMap);else localStorage.setItem("targeting_aux_map","")}else localStorage.setItem("targeting_aux_map","")}).fail(function(errorResponse){noticeError("targeting","ajax-error",errorResponse)});
if(Math.random()<.01){dataPayload.uuid=loxodoId;$.ajax({url:"https://targeting-userprofile-arc-wpost-prod.arc.nile.works/TargetingWebAPP/targeting",type:"POST",contentType:"application/json",dataType:"JSON",data:JSON.stringify(dataPayload)})}})(jQuery,window);
(function($){var wp_pb=window.wp_pb||{},env=wp_pb.environment||"production",apiBaseURL=env=="production"?"https://subscribe.washingtonpost.com/drawbridgeservice/queue-drawbridge":"https://subscribe.digitalink.com/drawbridgeservice/queue-drawbridge",washPostId,subscribeEmail,db_cookie_name="drawbridge_o",db_cookie_name_ab_test="drawbridge_test",db_cookie_expiration=42,db_cookie_domain=env=="production"?".washingtonpost.com":".digitalink.com",showDrawbridgeOverlay=function(testName,variantName,openCookieValue){$modal=
$("#drawbridge-signup-overlay");window["db-ad-flag"]=true;setTimeout(function(){var props=trackProps();var originalReferrer=window.s&&s.eVar35||"";props.eVar35=originalReferrer;sendCustomTrackProps("event86",props,"Drawbridge Overlay Opened")},5E3);$modal.jqm({overlay:85,modal:true,toTop:true,trigger:false,closeClass:"overlay-closer",onShow:function(h){h.o.prependTo("#pb-root");$("html").addClass("drawbridge-up");h.w.show();$(document).ready(function(){forceOverridePrevPageScrollPosition()});if(getDBCookieVal()!==
openCookieValue)setCookie(db_cookie_name,openCookieValue,db_cookie_expiration,db_cookie_domain);var abtCookieVal=testName+"|"+variantName;if(getDBABTCookieVal()!==abtCookieVal)setCookie(db_cookie_name_ab_test,abtCookieVal,db_cookie_expiration,db_cookie_domain);resetFixed("opened")},onHide:function(h){$("html").removeClass("drawbridge-up");sendCustomTrackProps("event80",{eVar26:"drawbridge_close"},"drawbridge-modal-close");h.w.fadeOut("2000",function(){h.o.remove()})}});$modal.jqmShow()},showErrorMsgInStream=
function(elm,message){if(message)elm.text(message).show()},hideErrorMsgInStream=function(elm){elm.hide()},getUserId=function(){return document.cookie.match(/wapo_login_id=([^;]+)/)?RegExp.$1:""},getWapoId=function(){return document.cookie.match(/wapo_secure_login_id=([^;]+)/)?RegExp.$1:""},getDBCookieVal=function(){var re=new RegExp("/"+db_cookie_name+"\x3d([^;]+)");return document.cookie.match(re)?RegExp.$1:""},getDBABTCookieVal=function(){var re=new RegExp("/"+db_cookie_name_ab_test+"\x3d([^;]+)");
return document.cookie.match(re)?RegExp.$1:""},resetFixed=function(data){if(data=="opened"&&$(".bar-hidden").length==0){$(".jqmOverlay, #drawbridge-signup-overlay").addClass("nav-open").removeClass("nav-closed");var headerHeight=$("#nav-bar").height();$(".jqmOverlay, #drawbridge-signup-overlay").css("margin-top",headerHeight)}else{$(".jqmOverlay, #drawbridge-signup-overlay").removeClass("nav-open").addClass("nav-closed");$(".jqmOverlay, #drawbridge-signup-overlay").css("margin-top","")}},dbTemplate=
function dbTemplate(options){options=options||{};var templ=["You'll also receive:","\x3cul\x3e","\x3cli\x3eour \x3cb\x3ePost Most\x3c/b\x3e newsletter \u2013 a daily roundup of top stories\x3c/li\x3e","\x3c/ul\x3e"];if(!!options.withSub)templ.splice(2,0,"\x3cli\x3ea \x3cstrong\x3efree\x3c/strong\x3e 6-week subscription\x3c/li\x3e");return templ.join("")},applySingleNewsletter=function(template){var module=$(".drawbridge-contet");$(module).find(".subtitleMessage").html(template);$(module).find("#email-field").data("newsletterId",
"post_newsletter347")},subscribeInStream=function(email,newsletterId,testName,variantName,successCookieValue){var data={};data.email=email;data.testName=testName;data.variantName=variantName;data.newsletterName=newsletterId;$.ajax({type:"POST",dataType:"json",contentType:"application/json",url:apiBaseURL,data:JSON.stringify(data),success:function(data){if(data.status=="SUCCESS"){var props=trackProps();props.eVar71=email;sendCustomTrackProps("event87",props,"Drawbridge Signup email sent");setCookie(db_cookie_name,
successCookieValue,db_cookie_expiration,db_cookie_domain);$(".db-signup-email").hide();$(".subscribe-group").removeClass("processing");$("#db-signup-thanks").show();var $submitButton=$("#drawbridge-submit");$submitButton.attr("disabled","disabled")}else if(data.status=="FAILURE"&&data.messages.indexOf("Invalid Email")>-1){$(".subscribe-group").removeClass("processing");showErrorMsgInStream($(".error-msg-email"),"Please enter a valid email address")}else{$(".subscribe-group").removeClass("processing");
showErrorMsgInStream($(".error-msg-email"),"Error while subscribing, please try later")}},error:function(request,status,error){$(".subscribe-group").removeClass("processing");showErrorMsgInStream($(".error-msg-email"),"Error while subscribing, please try later")}}).fail(function(){$(".subscribe-group").removeClass("processing");showErrorMsgInStream($(".error-msg-email"),"Error while subscribing, please try later")})},applyTest=function(testName,variantName,openCookieValue,successCookieValue){openCookieValue=
typeof openCookieValue=="undefined"?"":openCookieValue;successCookieValue=typeof successCookieValue=="undefined"?"":successCookieValue;var templ;if(variantName=="subscription")templ=dbTemplate({withSub:true});else if(variantName=="nosubscription")templ=dbTemplate();applySingleNewsletter(templ);showDrawbridgeOverlay(testName,variantName,openCookieValue);$(".pb-f-page-drawbridge-test-1 #email-field").val("");$(".pb-f-page-drawbridge-test-1").show();typeof wp_pb.register=="function"&&wp_pb.register("nav",
"finish_open",function(){resetFixed("opened")});typeof wp_pb.register=="function"&&wp_pb.register("nav","finish_close",function(){resetFixed("closed")});if(/wapo_secure_login_id/.test(document.cookie))$(".subscribe-link").hide();$(".subscribe-btn").click(function(){hideErrorMsgInStream($(".error-msg-email"));hideErrorMsgInStream($(".error-msg-checkbox"));subscribeEmail=$("#email-field").val(),re=/[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}/im,newsletterId=$("#email-field").data("newsletterId");if(subscribeEmail==
""||!re.test(subscribeEmail)){showErrorMsgInStream($(".error-msg-email"),"Please enter a valid email address");return false}if($(".agree-checkbox input.checkbox").attr("checked")!="checked"){showErrorMsgInStream($(".error-msg-checkbox"),"You are required to read and agree to the terms of service and privacy policy");return false}$(".subscribe-group").addClass("processing");subscribeInStream(subscribeEmail,newsletterId,testName,variantName,successCookieValue)})},trackProps=function(newsletterName,
index,enhancedKey){var subsection=window.wp_subsection||"";var contentType=window.wp_content_type||"";var props={"eVar1":wp_page_name,"eVar2":wp_channel,"eVar8":wp_author,"eVar25":wp_blogname,"prop56":window.s&&s.prop56?s.prop56:""};return props},sendCustomTrackProps=function(eventKey,props,name){if(!!window.s)window.s.sendDataToOmniture(name||"Drawbridge Test 1",eventKey,props,{wait:true})};function elementIsVisible(elem){elem=elem instanceof jQuery?elem:$(elem);return elem.is(":visible")}function setCookie(name,
value,expires,domain){var expireDate=(new Date(Date.now()+60*60*24*expires*1E3)).toUTCString();document.cookie=name+"\x3d"+value+";expires\x3d"+expireDate+";path\x3d/"+";domain\x3d"+domain}function isNewsletterEntry(){return/wpisrc/.test(location.search)}function isDrawbridgeEntry(){return!/drawbridge_o/.test(document.cookie)||!/drawbridge_o=2/.test(document.cookie)}function forceOverridePrevPageScrollPosition(){var $w=$(window);var interval=setInterval(function(){if($w.scrollTop()!==0)$w.scrollTop(0);
else clearInterval(interval)},1500)}var checkReferrer=function(referrer){return function(domainRegEx){return domainRegEx.test(referrer)}}(window.document.referrer);var segmentsDefined=false;function defineDBSegments(){if(window.VisitorSegment&&!segmentsDefined){VisitorSegment("loggedIn",function(){return/wapo_secure_login_id=/.test(document.cookie)});VisitorSegment("notLoggedIn",function(){return!/wapo_secure_login_id=/.test(document.cookie)});VisitorSegment("subscriber",function(){return/rplsb=1/.test(document.cookie)});
VisitorSegment("nonsubscriber",function(){return!/rplsb=1/.test(document.cookie)});VisitorSegment("facebook_referrer",function(){return checkReferrer(/facebook\.com/)});VisitorSegment("twitter_referrer",function(){return checkReferrer(/twitter\.com/)||checkReferrer(/t\.co/)});VisitorSegment("dark_traffic",function(){return document.referrer===""});VisitorSegment("domestic",function(){var rpld1=document.cookie.match(/rpld1=([^;]+)/)?RegExp.$1:"";return/20:usa/.test(rpld1)});VisitorSegment("international",
function(){var rpld1=document.cookie.match(/rpld1=([^;]+)/)?RegExp.$1:"";return!/20:usa/.test(rpld1)});segmentsDefined=true}}function shouldApplyDbV7(){return getWapoId()===""&&isDrawbridgeEntry()&&!isNewsletterEntry()}function drawbridgeABTHandlerV7(e,ABT){defineDBSegments();var TEST_NAME="drawbridge-v7";var successCookieValue=2;var variants={sub:{variantName:"subscription",openCookieValue:14},nosub:{variantName:"nosubscription",openCookieValue:15}};var test,variant;if(shouldApplyDbV7()){test=ABT.get(TEST_NAME);
if(test.is(variants.sub.variantName)){variant=variants.sub;applyTest(TEST_NAME,variant.variantName,variant.openCookieValue,successCookieValue)}else if(test.is(variants.nosub.variantName)){variant=variants.nosub;applyTest(TEST_NAME,variant.variantName,variant.openCookieValue,successCookieValue)}}}$(window.document).on("abtest-before",defineDBSegments);$(window.document).on("abtest-ready",drawbridgeABTHandlerV7)})(jQuery);
(function magnetAnonymous(window,$,wp_pb,undefined){var SCROLL_INTERVAL=200;var DEFAULT_DEBOUNCE=100;var UP_OFFSET=-175;var DOWN_OFFSET=-10;var WINDOW_TOP_OFFSET=0;var SCREEN_BOTTOM_OFFSET=600;logMagnetTag();var $w=$(window);var $d=$(document);var $r=$("html");var $h=$(".pb-f-page-header-v2");var trackNewsreel=function(){$(function(){window.sendDataToOmniture&&sendDataToOmniture("newsreel-display","event66",{eVar1:window.wp_page_name,prop2:window.wp_subsection,eVar2:window.wp_channel,prop3:window.wp_content_type,
eVar17:window.wp_content_type,eVar26:"newsreel-nl_optimist"},{wait:true})})};var $instance=$(".pb-f-page-magnet");$instance.each(function(){var $el=$(this);$el.insertAfter($h)});var $rootfeature=$(".pb-f-page-magnet");var $modulearea=$rootfeature.find(".pb-module-area");var $moduleareanewsreel=$modulearea.hasClass("has-newsreel-content");var $hasABTest=false;if($moduleareanewsreel)$(window.document).on("abtest-ready",function(e,ABT){var test=ABT.get("newsreel-optimist");var $rootfeature=$(".pb-f-page-magnet");
if(test.is("enabled"))init($rootfeature)});else init($rootfeature);function init($container){var $modulearea=$container.find(".pb-module-area");var $moduleareanewsreel=$modulearea.hasClass("pb-module-area-newsreel");if($moduleareanewsreel){$r.addClass("newsreel-root");down();$container.addClass("newsreel-feature");trackNewsreel()}var $isMobile=$("html").hasClass("mobile");if($isMobile&&!$moduleareanewsreel)makeTitle().insertBefore(".pb-f-page-magnet").addClass("mb-title");else{makeTitle().insertAfter(".pb-magnet-controls").addClass("desk-title");
$(".desk-title").addClass("showInlineBlock")}var $ctrl={};$ctrl.$container=$container.find(".pb-magnet-controls");$ctrl.$mvleft=$ctrl.$container.find(".pb-magnet-mvleft");$ctrl.$mvright=$ctrl.$container.find(".pb-magnet-mvright");$container.data("magnetControl",$ctrl);var $title=$modulearea.find(".pb-magnet-title");applyTitleCase($title.find(".pb-magnet-h2.magnet-title-case"));$modulearea.find('[data-pb-magnet-first\x3d"true"]').insertAfter($title);var $items=$container.find(".pb-magnet-item");var $imgs=
$items.find(".pb-magnet-article-image");if($items.length==0)return;var tagname=$modulearea.data("tag");var omniParams=params($modulearea.data("omni"));tagLinks(omniParams);attachNavEvents();$modulearea.css("display","");function attachNavEvents(){applyLazyload();var edown="mousedown.magnet";if(!touchDevice()){containerScroll(function(){applyNavVisibility()});$ctrl.$mvleft.off(edown).on(edown,function(){var value=Math.max(0,$container.scrollLeft()-computeWidth());moveScroll(value)});$ctrl.$mvright.off(edown).on(edown,
function(){var value=$container.scrollLeft()+computeWidth();moveScroll(value)});registerOnce("nav","start_open",debounce(function(){down()},DEFAULT_DEBOUNCE,true))}else windowTop(function(){if(WINDOW_TOP_OFFSET>=$w.scrollTop())down()});registerOnce("nav","start_close",debounce(function(){up()},DEFAULT_DEBOUNCE,true));registerOnce("magnet","start_open",debounce(function(){if(tagname&&!!window.s)if(tagname.indexOf("newsreel-nl_optimist")>=0);else s.sendDataToOmniture("magnet_open","",{prop72:tagname})},
DEFAULT_DEBOUNCE,true));function computeWidth(){var winwidth=$w.width();var itemwidth=$items.first().width();return Math.floor(winwidth/itemwidth)*itemwidth}}function params(value){var params=value?value.split("\x26"):[value];var result=[];if(params.length>0)$.each(params,function(index,value){var param=value.split("\x3d");result.push(param)});return result}function tagLinks(params){$modulearea.find("a").each(function(){var $a=$(this);var url=$a.attr("href");$.each(params,function(index,param){url=
updateUrlParam(url,param[0],param[1])});$a.attr("href",url)})}function registerOnce(arg1,arg2,fn){var regdata=[arg1,arg2];var regname=regdata.join(":");if(!$container.data(regname))wp_pb.register(regdata[0],regdata[1],fn);$container.data(regname,true)}function applyNavVisibility(){$ctrl.scrollleft=$container.scrollLeft();$ctrl.leftoffset=$container.scrollLeft()+$container.width();var rightbound=$modulearea[0].offsetWidth-$ctrl.leftoffset<=0;$ctrl.$mvleft.toggle(!!$ctrl.scrollleft);$ctrl.$mvright.toggle(!rightbound)}
function applyLazyload(){var sename="scroll.magnet-lazy";var reveal=0;$container.off(sename).on(sename,debounce(function(){lazy()},1,true));lazy();function lazy(){var count=Math.max(reveal,computeNumberOfImages());if(!!count&&"NaN"!==count.toString()&&reveal!==count){reveal=count;$imgs.filter(":lt("+reveal+")").each(function(){var $el=$(this);$el.attr("src",$el.data("original"))})}}function computeNumberOfImages(){return Math.ceil(($container.scrollLeft()+($container.width()||$(window).width()))/
$items.first().width())}}function nearBottom(){return $w.scrollTop()>=$d.height()-$w.height()-SCREEN_BOTTOM_OFFSET}function down(){$r.addClass("magnet");$(".mb-title").addClass("showBlock");if(!nearBottom())$r.addClass("magnet-nudge");if(touchDevice())$container.add(".mb-title").addClass("magnet-open");else $container.addClass("magnet-open").css({top:DOWN_OFFSET});wp_pb.report("magnet","start_open")}function up(){$r.removeClass("magnet magnet-nudge");$(".mb-title").removeClass("showBlock");if(touchDevice())$container.add(".mb-title").removeClass("magnet-open");
else $container.removeClass("magnet-open").css({top:UP_OFFSET});wp_pb.report("magnet","start_close")}function containerScroll(fn){var scroll;var rename="resize.magnet";$w.off(rename).on(rename,function(){scroll=true});var sename="scroll.magnet";$container.off(sename).on(sename,function(){scroll=true});var tid;setInterval(function(){if(scroll){if(tid)clearTimeout(tid);tid=setTimeout(function(){fn()},SCROLL_INTERVAL)}scroll=false},SCROLL_INTERVAL)}function getTitleHtml(){return $("#PageMagnetTitle").html()}
function makeTitle(){return $(getTitleHtml())}function windowTop(fn){var atop=false;var tid;var sename="scroll.magnet";$w.off(sename).on(sename,function(){var top=$(window).scrollTop();if(!atop&&top==0){atop=true;if(tid)clearTimeout(tid);tid=setTimeout(function(){fn()},SCROLL_INTERVAL)}else if(top>=0)atop=false})}function moveScroll(value){$container.stop().animate({scrollLeft:value},"slow")}}function touchDevice(){return $r.hasClass("touch")}function titleCase(strValue){var str=strValue.replace(/([^\W_]+[^\s-]*) */g,
function(txt){return txt.charAt(0).toUpperCase()+txt.substr(1).toLowerCase()});var lowers=["A","An","The","And","But","Or","For","Nor","As","At","By","For","From","In","Into","Near","Of","On","Onto","To","With"];var i,j;for(i=0,j=lowers.length;i<j;i++)str=str.replace(new RegExp("\\s"+lowers[i]+"\\s","g"),function(txt){return txt.toLowerCase()});var uppers=["Id","Tv"];for(i=0,j=uppers.length;i<j;i++)str=str.replace(new RegExp("\\b"+uppers[i]+"\\b","g"),uppers[i].toUpperCase());return str}function applyTitleCase($el){var title=
titleCase(($el.text()||"").replace(/_/gi," "));$el.text(title)}function updateUrlParam(url,key,value){var n=new RegExp("([?\x26])"+key+"\x3d.*?(\x26|$)","i");var i=-1!==url.indexOf("?")?"\x26":"?";return url.match(n)?url.replace(n,"$1"+key+"\x3d"+value+"$2"):url+i+key+"\x3d"+value}function logMagnetTag(){var tagname;var modulearea=document.getElementsByClassName("pb-f-page-magnet")[0].getElementsByClassName("pb-module-area")[0];tagname=modulearea&&modulearea.getAttribute("data-tag");if(tagname&&!!window.s)s.prop55=
tagname}function debounce(func,wait,immediate){var timeout;return function(){var context=this,args=arguments;var later=function(){timeout=null;if(!immediate)func.apply(context,args)};var callNow=immediate&&!timeout;clearTimeout(timeout);timeout=setTimeout(later,wait);if(callNow)func.apply(context,args)}}})(window,jQuery,wp_pb);
(function(m,d,b){function f(a){return function(c,g,b){if(g)a[c]={when:g,setup:b},b&&(a[c]._setupResult=!!b.call(a[c]));else if(a[c])return!!a[c].when.call(a[c],a[c]._setupResult)}}function h(){var a=navigator.userAgent;return a.match(/Android/i)||a.match(/webOS/i)||a.match(/iPhone/i)||a.match(/iPad/i)||a.match(/iPod/i)||a.match(/BlackBerry/i)||a.match(/Kindle/i)||a.match(/Windows Phone/i)||a.match(/IEMobile/i)?!0:!1}function k(a){var c=localStorage.getItem("_vsData")||"{}";return JSON.parse(c)[a]}
function l(a,c){var b=localStorage.getItem("_vsData")||"{}",b=JSON.parse(b);b[a]=c;c=JSON.stringify(b);localStorage.removeItem("_vsData");localStorage.setItem("_vsData",c)}var e=d._vsdata=d._vsdata||{};b=function(a,c,b){return f(e).call(this,a,c,b)};b.clone=function(a){a=a?m.extend(!0,{},e):e;return f(a)};b("desktop",function(){return!h()});b("mobile",function(){return h()});b("touch",function(){return!!("ontouchstart"in d)});b("first_visit",function(){var a=k("first_time_start"),b=k("first_time_end");
if(a&&!b&&18E5<=(new Date).getTime()-(new Date(a)).getTime())return l("first_time_end",!0),!1;if(a)return!b;l("first_time_start",(new Date).getTime());return!0});return d.VisitorSegment=b})(jQuery,window);var TWP=window.TWP||{};TWP.ABTestUser=TWP.ABTestUser||{};
(function ABTestAnonymous($,TWP,VisitorSegment,undefined){var VERSION="1.0.2";var OPT_OUT_KEY="ABT__OO";var IGNORE_BL_KEY="ABT__ib";var LOCAL_TRUE="yes";var LOCAL_FALSE="no";var featureData={};var bucketData={};var disabled;var ignoreBlacklist;var state="uninitialized";var $d=$(window.document);var ABT={init:function(data){disabled=!data;$d.trigger("abtest-before",[ABT]);ABT.applyData(data);if(state!="initialized")$d.trigger("abtest-ready",[ABT]);state="initialized";$d.trigger("abtest-init",[ABT])},
state:function(){return state},trackBefore:function(eventHandler){bindTop($d,ABT.trackPageviewEventBefore(),eventHandler)},trackAfter:function(eventHandler){bindTop($d,ABT.trackPageviewEventAfter(),eventHandler)},trackValueDelimeter:function(){return TWP.ABTestUser.trackValueDelimeter},trackPageviewEventBefore:function(){return TWP.ABTestUser.trackPageviewEventBefore},trackPageviewEventAfter:function(){return TWP.ABTestUser.trackPageviewEventAfter},trackSendHandler:function(){var method=str2obj(TWP.ABTestUser.trackSendHandler);
return"function"==typeof method?method:function(){}},trackSetHandler:function(){var method=str2obj(TWP.ABTestUser.trackSetHandler);return"function"==typeof method?method:function(){}},trackUnsetHandler:function(){var method=str2obj(TWP.ABTestUser.trackUnsetHandler);return"function"==typeof method?method:function(){}},applyData:function(dataValue){var data;if(!disabled&&detectLocalStorage()&&!optOut()){data={features:[]};ignoreBlacklist=getLocalItem(IGNORE_BL_KEY);$.each(dataValue||[],function(index,
bucket){if("boolean"==typeof bucket.disabled&&!bucket.disabled)$.merge(data.features,bucket.features)});ABT.bucket(data)}},bucket:function(data){bucketData=data;var features;if(!data.disabled){features=data.features||[];$.each(features,function(index,feature){setFeature(feature)})}},ignoreBlacklist:function(value){if(!value){ignoreBlacklist=undefined;removeLocalItem(IGNORE_BL_KEY)}else{ignoreBlacklist=LOCAL_TRUE;setLocalItem(IGNORE_BL_KEY,LOCAL_TRUE)}},optOut:function(){setLocalItem(OPT_OUT_KEY,LOCAL_TRUE);
$d.trigger("abtest-optout",[ABT])},get:function(name,skipTrack){var feature=!disabled&&featureData[name]||{};var variation=feature.variation||new Variation(feature);if(!skipTrack&&feature.variation&&!variation._trackset){variation._trackset=true;ABT.trackBefore(function(){variation.setTrackVars()});ABT.trackAfter(function(){variation.unsetTrackVars()})}return variation},clear:function(){$.each(bucketData.features,function(i,f){unregisterVariation(f.name)})},forceTest:function(featureName,variantName){var key=
makeKeyNames(featureName);setLocalItem(key.name,variantName);setLocalItem(key.visit,LOCAL_TRUE);setLocalItem(key.computed,LOCAL_TRUE);setLocalItem(key.force,LOCAL_TRUE)}};ABT.$handlers={applyClass:function(isVariant,feature,variant){this.removeClass("abt-not-loaded").addClass("abt-"+feature+"-"+variant+"-"+isVariant)}};$.fn.extend({biAbtest:function(handlerName,name,cb){var config=getConfig(name);var ftr=ABT.get(config.feature);var is=ftr.is(config.variant);function getConfig(name){var n=name.split(".");
return{feature:n[0],variant:n[1]}}if(!config.feature||!config.variant)return;return this.each(function(){var $el=$(this);ABT.$handlers[handlerName].call($el,is,config.feature,config.variant);if(cb)cb.call($el,is,config.feature,config.variant)})}});TWP.ABTest=ABT;TWP.ABTest.version=VERSION;VisitorSegment("abtest-init:v"+VERSION,function(){return true});ABT.init(TWP.ABTestBucket);function initError(msg){$d.trigger("abtest-fail",[["init",msg].join(": ")])}function Feature(data){var name=data.name||"";
var key=makeKeyNames(name);var increment=data.increment||0;var variations=data.variations||[];var persist=data["x-persist"]||false;var blacklist=data.blacklist&&data.blacklist.referrers||[];var blacklisted=getLocalItem(key.blacklisted)==LOCAL_TRUE;var bopt={domains:blacklist,segment:{}};var segmentName;for(segmentName in data.segment)bopt.segment[segmentName]=!!data.segment[segmentName];var included=!notInSegment(bopt.segment);if(!blacklisted&&!getLocalItem(key.blacklisted)){blacklisted=isBlacklisted(bopt.domains)||
!included;setLocalItem(key.blacklisted,blacklisted?LOCAL_TRUE:LOCAL_FALSE)}var enabled=!!variations.length;var variation=variations.length&&new Variation(registerVariation(name,variations,blacklisted,increment,included,persist));if(enabled&&data.active&&!variation.nocollect){this.name=name;this.variation=variation}var defaultTrack=enabled&&data.active?data.defaultTrack:[];if(blacklisted)$.merge(defaultTrack,data.blacklist&&data.blacklist.track||[]);if(defaultTrack.length&&variation.nocollect)this.variation=
new Variation({variation:{track:!included?[]:defaultTrack}});if((!enabled||!variation||!included)&&LOCAL_TRUE!=getLocalItem(key.force))unregisterVariation(name)}function Variation(objValue){var obj=objValue||{};this.nocollect=!obj.collect;var data=obj.variation||{};this.name=data.name||"";this.trackvars=data.track||[];this.customOptions=data.customOptions||{};var _self=this;this.is=function(name){return name?name===_self.name:false};this.getTrackVar=function(name,prepend,delimiterValue){var result=
[];$.each(_self.trackvars,function(index,trackvar){if(makeTrackvarName(name)===makeTrackvarName(trackvar.name))result.push(trackvar.value)});var delimiter=delimiterValue||ABT.trackValueDelimeter();result=result.join(delimiter);return result&&(prepend?prepend+delimiter:"")+result};this.sendTrackVars=function(setOp,eventKey,extraOptions){var payload=trackingPayload();var trackargs=["Darwin - TrackVar",eventKey||"",payload,extraOptions];if(setOp)ABT.trackSetHandler().apply(ABT,[payload]);else ABT.trackSendHandler().apply(ABT,
trackargs);$d.trigger("abtest-tracksend",trackargs)};this.unsetTrackVars=function(){var payload=trackingPayload();ABT.trackUnsetHandler().apply(ABT,[payload])};this.setTrackVars=function(){var payload=trackingPayload();ABT.trackSetHandler().apply(ABT,[payload])};this.sendCustomTrackVar=function(){return undefined};this.unsetCustomTrackVar=function(){return undefined};this.setCustomTrackVar=function(){return undefined};function trackingPayload(){var payload={};$.each(_self.trackvars,function(index,
trackvar){var svar;if(!trackvar.dynamic){svar=makeTrackvarName(trackvar.name);payload[svar]=payload[svar]||[];payload[svar].push(trackvar.value)}});return payload}}function registerVariation(name,variations,blacklisted,increment,included,persist){var key=makeKeyNames(name);var his={cur:persist?"":testHash(name,variations,blacklisted,increment),old:persist?"":getLocalItem(key.hash)};var i=getLocalItem(key.name);var r=LOCAL_TRUE==getLocalItem(key.visit);var t=LOCAL_TRUE==getLocalItem(key.computed);
var f=LOCAL_TRUE==getLocalItem(key.force);var compare=function(a,b){var a=parseFloat(a.customOptions.target);var b=parseFloat(b.customOptions.target);if(a<b)return-1;if(a>b)return 1;return 0};var v=findByProp(variations,"name",i);if(included&&(!t&&!blacklisted&&("string"!==typeof i&&!v)||!f&&!!t&&his.cur!=his.old)){variations.sort(compare);var ranges=[];var g=0;var h=0;$.each(variations,function(index,variant){var v=variant.customOptions&&variant.customOptions.target;if(v){v=parseFloat(v)/100;g+=
v;var result={value:[h,g]};h+=v;ranges.push(result)}});var rc=randChance();$.each(ranges,function(index,range){if(between(rc,range.value[0],range.value[1]))i=index});v=variations[i];if(v)setLocalItem(key.name,v.name);else setLocalItem(key.name,"_default")}setLocalItem(key.visit,LOCAL_TRUE);setLocalItem(key.computed,LOCAL_TRUE);setLocalItem(key.hash,his.cur);var result=v&&(!blacklisted||r)&&{variation:v,collect:true};return result}function testHash(name,variations,blacklisted,increment){var vnames=
[];$.each(variations,function(index,variation){var o=variation.customOptions;var ostr="";if(o)for(n in o)if(o.hasOwnProperty(n))ostr+=[n,o[n]].join("\x3d");vnames.push(variation.name+ostr)});var result=[name,vnames.sort().join(""),!!blacklisted,increment].join("");return result}function unregisterVariation(name){var key=makeKeyNames(name);removeLocalItem(key.name);removeLocalItem(key.visit);removeLocalItem(key.blacklisted);removeLocalItem(key.computed);removeLocalItem(key.hash);removeLocalItem(key.force)}
function findByProp(arr,prop,value){var result;$.each(arr,function(i,item){if(item[prop]==value){result=item;return false}});return result}function makeTrackvarName(value){if(!value)throw new Error("trackvar: invalid name");return value.toLowerCase()}function makeKeyNames(name){return{name:"ABT__"+name,visit:"ABT__"+name+"__visit",blacklisted:"ABT__"+name+"__blstd",computed:"ABT__"+name+"__cmpted",hash:"ABT__"+name+"__hash",force:"ABT__"+name+"__force"}}function randChance(){return Math.random(0,
1)}function between(x,min,max){return x>=min&&x<=max}function getFeature(name){return featureData[name]}function setFeature(data){if(!data.name)throw new Error("Feature: missing name");var feature=new Feature(data);if(!$.isEmptyObject(feature))featureData[data.name]=feature}function isBlacklisted(domainsValue){var domains=domainsValue||[];function regescape(str){return str.replace(/\./g,"\\.").replace(/\-/g,"\\-")}function check(domain){var reg=new RegExp("^(http://)?(www\\.)?"+regescape(domain),
"gi");return!domain&&!document.referrer||(domain&&document.referrer.match(reg)||[]).length>0}var result;if(!ignoreBlacklist)$.each(domains,function(index,domain){result=check(domain);return!result});return result}function notInSegment(segmentValue){var segment=segmentValue||{};var result;var count=0;var segmentName;for(segmentName in segment)if(segment.hasOwnProperty(segmentName)){result=result||(!!segment[segmentName]?!!VisitorSegment(segmentName):false);if(!!segment[segmentName])count++}return 0!==
count?!result:1==Object.keys(segment).length?!VisitorSegment(segment[0]):false}function detectLocalStorage(){var str="_abti_";try{setLocalItem(str,str);removeLocalItem(str);return true}catch(e){return false}}function getLocalItem(name){return localStorage.getItem(name)}function setLocalItem(name,value){if(getLocalItem(name))removeLocalItem(name);localStorage.setItem(name,value)}function removeLocalItem(name){localStorage.removeItem(name)}function optOut(){return getLocalItem(OPT_OUT_KEY)==LOCAL_TRUE}
function str2obj(handlerStr){var parts;var method=window;try{parts=handlerStr.split(".");$.each(parts,function(i,obj){method=method[obj]})}catch(e){}return method}function bindTop($ctx,name,fn){if(!name)return;$ctx.on(name,fn);$ctx.each(function(){var handlers=$._data($ctx[0],"events")[name.split(".")[0]];var handler=handlers.pop();handlers.splice(0,0,handler)})}})(jQuery,TWP,VisitorSegment);