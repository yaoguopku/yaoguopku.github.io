(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	manifest: [
		{src:"images/disclaimer.png?1467316760565", id:"disclaimer"},
		{src:"images/image.jpg?1467316760565", id:"image"},
		{src:"images/stoptrump.png?1467316760565", id:"stoptrump"}
	]
};



// symbols:



(lib.disclaimer = function() {
	this.initialize(img.disclaimer);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.image = function() {
	this.initialize(img.image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,610,1116);


(lib.stoptrump = function() {
	this.initialize(img.stoptrump);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,520,142);


(lib.image_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.image();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,610,1116);


(lib.disclaimer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.disclaimer();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.ctaarea = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.stoptrump();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,260,71);


(lib.clicktag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("A3vT1MAAAgnpMAvfAAAMAAAAnpg");
	this.shape.setTransform(152,127);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{s1:12,s2:29});

	// timeline functions:
	this.frame_0 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}
	this.frame_19 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}
	this.frame_34 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(15).call(this.frame_34).wait(1));

	// Layer 1
	this.instance = new lib.ctaarea();
	this.instance.setTransform(130,35.5,1,1,0,0,0,130,35.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({scaleX:1.1,scaleY:1.1,x:129.7},3,cjs.Ease.get(1)).to({regY:35.4,scaleX:1.05,scaleY:1.05,x:129.9,y:35.4},3).wait(11).to({regY:35.1,y:35.1},0).to({regY:35.5,scaleX:1,scaleY:1,x:130,y:35.6},5,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,260,71);


(lib.animation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"s1":36});

	// timeline functions:
	this.frame_0 = function() {
		window.hasFinished = false;
	}
	this.frame_30 = function() {
		this.stop();
		window.hasFinished = true;
	}
	this.frame_42 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(30).call(this.frame_30).wait(12).call(this.frame_42).wait(1));

	// disclaimer
	this.instance = new lib.disclaimer_1();
	this.instance.setTransform(150,300,1,1,0,0,0,150,300);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(24).to({_off:false},0).to({alpha:1},5).wait(14));

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_24 = new cjs.Graphics().p("AgmLLIAA2UIBOAAIAAWUg");
	var mask_graphics_25 = new cjs.Graphics().p("AlKLLIAA2UIKVAAIAAWUg");
	var mask_graphics_26 = new cjs.Graphics().p("ApuLLIAA2UITdAAIAAWUg");
	var mask_graphics_27 = new cjs.Graphics().p("AuSLLIAA2UIclAAIAAWUg");
	var mask_graphics_28 = new cjs.Graphics().p("Ay2LLIAA2UMAltAAAIAAWUg");
	var mask_graphics_29 = new cjs.Graphics().p("EgXaAn7IAA2WMAu2AAAIAAWWg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(24).to({graphics:mask_graphics_24,x:4.2,y:439.5}).wait(1).to({graphics:mask_graphics_25,x:33.4,y:439.5}).wait(1).to({graphics:mask_graphics_26,x:62.6,y:439.5}).wait(1).to({graphics:mask_graphics_27,x:91.8,y:439.5}).wait(1).to({graphics:mask_graphics_28,x:121,y:439.5}).wait(1).to({graphics:mask_graphics_29,x:150.1,y:255.5}).wait(14));

	// cta
	this.cta = new lib.cta();
	this.cta.setTransform(150,443.5,1,1,0,0,0,130,35.5);
	this.cta._off = true;

	this.cta.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(24).to({_off:false},0).wait(19));

	// image
	this.instance_1 = new lib.image_1();
	this.instance_1.setTransform(164.1,300,0.538,0.538,0,0,0,305.1,557.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({scaleX:1.1,scaleY:1.1,x:149.1,y:-13.8},12,cjs.Ease.get(-1)).to({scaleX:0.95,scaleY:0.95,x:149,y:70},2).wait(1).to({scaleX:1,scaleY:1,x:149.1,y:42},0).wait(16).to({scaleX:1.1,scaleY:1.1,y:12},0).to({scaleX:1,scaleY:1,y:42},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,328,600);


// stage content:



(lib.listbuildingtrumpoppocolorangrytrumpstoptumpsthtml5300x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		// ignore this code - its used to make troubleshooting easier since its HTML5
		// create trace window 
		/*
		var loc = document.location.toString();  
		if (loc.indexOf("http") == -1 || loc.indexOf("127.0.0.1") > 0) {  
		    _traceWin = document.createElement("div");   
		    _traceWin.style.cssText = "position:absolute; background:#EDEDED; overflow-y:scroll; overflow-x:hidden; padding:0 5px 0 5px; font-family:monospace; font-size:13px; left:0; top:" + (canvas.height + 1) + "px; width:" + (canvas.width - 10) + "px; height:80px";  
		    canvas.parentNode.appendChild(_traceWin);  
		    trace = function(msg) {  
		        _traceWin.innerHTML += String(msg) + "<br>";  
		        _traceWin.scrollTop = _traceWin.scrollHeight;  
		    }  
		}  
		else {  
		    trace = function() {};  
		}  
		*/
		
		
		// this ver
		canvas.addEventListener("mouseover", overcta.bind(this));  
		canvas.addEventListener("mouseout", outcta.bind(this));
		
		
		function overcta(e){
			if(window.hasFinished){
			this.animation.cta.gotoAndPlay('s1');
				this.animation.gotoAndPlay('s1');
			}
			
		}
		function outcta(e){
			if(window.hasFinished){
			this.animation.cta.gotoAndPlay('s2');
			}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// frame
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,0,3).p("EgXWguyMAutAAAMAAABdlMgutAAAg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// animation
	this.animation = new lib.animation();
	this.animation.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.animation).wait(1));

	// button symbol
	this.instance = new lib.clicktag();
	this.instance.setTransform(150,300.1,0.987,2.363,0,0,0,152,127);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.clicktag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(149.5,299.5,328.5,601);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;