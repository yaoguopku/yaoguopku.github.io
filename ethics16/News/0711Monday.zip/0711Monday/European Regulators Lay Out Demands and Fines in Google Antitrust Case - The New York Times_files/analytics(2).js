(function() {
var ozoki_tc = 'G594faMSqz7TUUtY7OXLTUtzctVnw8hq';
var ozoki_os = 's.adzmath.com';
var ozoki_url = 'https://s.adzmath.com/2/482387/analytics.js?ac=9070138&amp;si=1701479&amp;pc=130410126&amp;pi=303205973&amp;cr=72556807&amp;dm=300x600&amp;ai=4782501&amp;ui=AMsySZZJ9qMtkJy1bfc-hf8HxTs-&amp;cb=3185520641&amp;pp=N5778.6440THENEWYORKTIMESCOMPANY&amp;dt=4823871464379373245001';

var ozoki_ct = {"ac":"9070138", "si":"1701479", "pc":"130410126", "pi":"303205973", "cr":"72556807", "dm":"300x600", "ai":"4782501", "ui":"AMsySZZJ9qMtkJy1bfc\u002Dhf8HxTs\u002D", "cb":"3185520641", "pp":"N5778.6440THENEWYORKTIMESCOMPANY", "dt":"4823871464379373245001"};

if (typeof ozoki_ct == "undefined" || ozoki_ct == null)  {
var ozoki_ct = {};
}
ozoki_ct.ci = '482387';

var ozoki_opt = {sm:2,fs:true};

ozoki_opt.mouse=true;
ozoki_opt.dup=true;
ozoki_opt.wrip = true;











var PAGESPEED_VERSION = "4.14.6";




(function() {
!function(){!function(){var o="2";if(window.ozoki_data){if(!ozoki_opt.dup)return}else window.ozoki_data=[];var i={};i.ozoki_st=(new Date).getTime(),i.ozoki_os=ozoki_os,"undefined"!=typeof ozoki_fl&&(i.ozoki_fl=ozoki_fl),i.ozoki_url=ozoki_url,i.ozoki_ct=ozoki_ct,i.ozoki_tc=ozoki_tc,i.ozoki_opt=ozoki_opt,window.ozoki_data.push(i);var t,e=ozoki_url.substr(0,ozoki_url.indexOf(":"))+"://"+ozoki_os+"/"+o+"/"+PAGESPEED_VERSION+"/",_=!1,d=function(){_||(document&&!t&&(t=document.createElement("script"),t.src=e+"loaded.js"),document.body?(_=!0,document.body.appendChild(t)):window.setTimeout(d,4))};d()}()}();}());


}());

