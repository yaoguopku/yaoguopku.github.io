/**
 * ArsonalVideoCuepoint
 */
(function () {

    this.ArsonalVideoCuepoint = function(id, time) {
        this.id = id;
        this.time = time;
        this.enabled = true;
    };

    ArsonalVideoCuepoint.prototype.constructor = ArsonalVideoCuepoint;

})();

/**
 * ArsonalSizmekVideo
 */
(function () {

    this.ArsonalSizmekVideo = function(id, elementId, videoContainerId, sourceMP4, sourceWEBM, videoDuration, autoPlay, autoMuted) {
        this.observers = [];
        this.id = id;
        this.elementId = elementId;
        this.videoContainerId = videoContainerId;
        this.sourceMP4 = sourceMP4;
        this.sourceWEBM = sourceWEBM;
        this.videoDuration = videoDuration;
        this.time = 0;
        this.autoplay = autoPlay || false;
        this.isVideoPlaying = false;
        this.isVideoComplete = false;
        this.isVideoBuffering = false;
        this.isVideoLoaded = false;
        this.automuted = autoMuted || true;
        this.isVideoMuted = this.automuted;
        this.videoPlaybackInterval = 0;
        this.cuepoints = [];
        this.videoContainer = null;
        this.videoComponent = null;
        this.millisecondsBeforeBufferIsValidated = 500;
        this.millisecondsBeforeVideoLoadedIsValidated = 1000;
    };

    ArsonalSizmekVideo.prototype = new Notifier();
    ArsonalSizmekVideo.prototype.constructor = ArsonalSizmekVideo;

    ArsonalSizmekVideo.prototype.initialize = function() {
        if(this.videoComponent) return;
        this.removeCuepoints();

        var videoString = "";
        if(this.autoplay) {
            videoString = "<video id='" + this.elementId + "' autoplay>";
        } else {
            videoString = "<video id='" + this.elementId + "'>";
        }
        videoString += "<source src='" + this.sourceMP4 + "' type='video/mp4'>";
        videoString += "<source src='" + this.sourceWEBM + "' type='video/webm'>";
        videoString += "</video>";
        videoString += "<div id='sdk-video-player' class='sdk-video-player'>";
        videoString += "<div id='sdk-video-play-button' class='sdk-video-player-button'></div>";
        videoString += "</div>";

        this.videoContainer = document.getElementById(this.videoContainerId);
        this.videoContainer.innerHTML = videoString;
        this.videoComponent = document.getElementById(this.elementId);

        var sdkPlayerVideoFormat = "mp4";
        var useSDKVideoPlayer = false;
        var videoTrackingModule = null;
        var sdkData = EB.getSDKData();
        if (sdkData !== null) {
            if (sdkData.SDKType === "MRAID" && sdkData.version > 1) {
                document.body.classList.add("sdk");
                var sourceTags = this.videoComponent.getElementsByTagName("source");
                var videoSource = "";
                for(var i = 0; i < sourceTags.length; i++) {
                    if (sourceTags[i].getAttribute("type")) {
                        if (sourceTags[i].getAttribute("type").toLowerCase() === "video/" + sdkPlayerVideoFormat) {
                            videoSource = sourceTags[i].getAttribute("src");
                        }
                    }
                }
                useSDKVideoPlayer = true;
            }
        }
        if (! useSDKVideoPlayer) {
            videoTrackingModule = new EBG.VideoModule(this.videoComponent);
        }
        if(this.autoplay) {
            this.play();
        }
        if(this.automuted) {
            this.mute();
        } else {
            this.unmute();
        }
        this.addVideoEvents();
    };

    ArsonalSizmekVideo.prototype.play = function() {
        if(this.isVideoPlaying) return;
        this.isVideoBuffering = true;
        this.videoComponent.play();
        clearInterval(this.videoPlaybackInterval);
        this.videoPlaybackInterval = setInterval(this._videoProgress.bind(this), 100);
    };

    ArsonalSizmekVideo.prototype.pause = function() {
        this.isVideoPlaying = false;
        this.videoComponent.pause();
        clearInterval(this.videoPlaybackInterval);
    };

    ArsonalSizmekVideo.prototype.mute = function() {
        this.isVideoMuted = true;
        this.videoComponent.volume = 0.0;
    };

    ArsonalSizmekVideo.prototype.unmute = function() {
        this.isVideoMuted = false;
        this.videoComponent.volume = 1.0;
    };

    ArsonalSizmekVideo.prototype.replay = function() {
        this.rewind();
        this.unmute();
        this.play();
    };

    ArsonalSizmekVideo.prototype.rewind = function() {
        if(this.isVideoComplete) return;
        try {
            this.videoComponent.currentTime = 0;
        } catch(e) {}
        this.pause();
    };

    ArsonalSizmekVideo.prototype.addCuepoint = function(id, time) {
        var c = new ArsonalVideoCuepoint(id, time);
        this.cuepoints.push(c);
    };

    ArsonalSizmekVideo.prototype.removeCuepoints = function() {
        this.cuepoints = []
    };

    ArsonalSizmekVideo.prototype.addVideoEvents = function() {
        if(! this.videoComponent) return;
        try {
            this.videoComponent.removeEventListener("playing", this._videoPlaying.bind(this), false);
            this.videoComponent.removeEventListener('ended', this._videoComplete.bind(this), false);
            this.videoComponent.removeEventListener("fullscreenchange", this._videoEndFullscreen.bind(this), false);
            this.videoComponent.removeEventListener("mozfullscreenchange", this._videoEndFullscreen.bind(this), false);
            this.videoComponent.removeEventListener("webkitfullscreenchange", this._videoEndFullscreen.bind(this), false);
        } catch(e) {}
        try {
            this.videoComponent.addEventListener("playing", this._videoPlaying.bind(this), false);
            this.videoComponent.addEventListener('ended', this._videoComplete.bind(this), false);
            this.videoComponent.addEventListener("fullscreenchange", this._videoEndFullscreen.bind(this), false);
            this.videoComponent.addEventListener("mozfullscreenchange", this._videoEndFullscreen.bind(this), false);
            this.videoComponent.addEventListener("webkitfullscreenchange", this._videoEndFullscreen.bind(this), false);
        } catch(e) {}
    };

    ArsonalSizmekVideo.prototype.removeVideoEvents = function() {
        if(! this.videoComponent) return;
        try {
            this.videoComponent.removeEventListener("playing", this._videoPlaying.bind(this), false);
            this.videoComponent.removeEventListener('ended', this._videoComplete.bind(this), false);
            this.videoComponent.removeEventListener("fullscreenchange", this._videoEndFullscreen.bind(this), false);
            this.videoComponent.removeEventListener("mozfullscreenchange", this._videoEndFullscreen.bind(this), false);
            this.videoComponent.removeEventListener("webkitfullscreenchange", this._videoEndFullscreen.bind(this), false);
        } catch(e) {}
    };

    ArsonalSizmekVideo.prototype.destroy = function() {
        if(! this.videoComponent) return;
        this.removeVideoEvents();
        this.pause();
        clearInterval(this.videoPlaybackInterval);
        this.videoComponent = null;
        delete(this.videoComponent);
        this.videoContainer.innerHTML = "";
    };

    ArsonalSizmekVideo.prototype._videoPlaying = function() {
        this.isVideoPlaying = true;
        this.isVideoComplete = false;
        if(this.isVideoLoaded) {
            setTimeout(function() {
                this.isVideoBuffering = false;
            }.bind(this), this.millisecondsBeforeBufferIsValidated);
        } else {
            setTimeout(function() {
                this.isVideoLoaded = true;
                this.isVideoBuffering = false;
            }.bind(this), this.millisecondsBeforeVideoLoadedIsValidated);
        }
        clearInterval(this.videoPlaybackInterval);
        this.videoPlaybackInterval = setInterval(this._videoProgress.bind(this), 100);
        this.sendNotification('playing', {}, this);
    };

    ArsonalSizmekVideo.prototype._videoProgress = function() {
        if(this.isVideoComplete) return;
        try {
            if(! this.videoComponent.currentTime) return;
            var i = 0;
            if(this.time > this.videoComponent.currentTime) {
                for(i = 0; i < this.cuepoints.length; i++) {
                    this.cuepoints[i].enabled = true;
                }
            }
            this.time = parseFloat(this.videoComponent.currentTime).toFixed(2);
            for(i = 0; i < this.cuepoints.length; i++) {
                if(this.cuepoints[i].enabled) {
                    if(((parseFloat(this.time) - 0.1) < this.cuepoints[i].time &&
                        (parseFloat(this.time) + 0.1) > this.cuepoints[i].time) ||
                        this.time === this.cuepoints[i].time) {
                        this.cuepoints[i].enabled = false;
                        this.sendNotification(this.cuepoints[i].id, { time: this.cuepoints[i].time }, this);
                    }
                }
            }
            this.sendNotification("progress", { time: this.videoComponent.currentTime, duration: this.videoDuration }, this);
        } catch(e) {}
    };

    ArsonalSizmekVideo.prototype._videoComplete = function(e) {
        if(this.isVideoComplete) return;
        this.isVideoComplete = true;
        this.isVideoPlaying = false;
        this.rewind();
        setTimeout(function() {
            this.sendNotification("ended", {}, this);
        }.bind(this), 10);
    };

    ArsonalSizmekVideo.prototype._videoEndFullscreen = function() {
        this.rewind();
        this.sendNotification("fullscreenchange", {}, this);
    };

})();


/* ================================================================
    EXAMPLE

// TODO Construct the video object
videoComponent1 = new ArsonalSizmekVideo(
    video_1_vo.id, // identifier for tracking purposes
    video_1_vo.elementId, // video element id
    video_1_vo.sourceMP4, // mp4 url
    video_1_vo.sourceWEBM, // webm url
    video_1_vo.videoDuration, // video length
    true, // auto play
    true, // auto muted
);

// TODO Listen for video events from "this" scope. Which then relays events to the "receiveNotification" method
videoComponent1.addObserver(this);

// TODO Creates the video videoYoutubePlayer. Be sure to have loaded the doubleclick module "studio.module.ModuleId.RAD_VIDEO" first before calling.
videoComponent1.initialize();

// TODO OVERRIDE THIS CALLBACK METHOD TO LISTEN FOR VIDEO EVENTS
function receiveNotification(notification) {
    console.log("OVERRIDE THIS CALLBACK METHOD TO LISTEN FOR VIDEO EVENTS");
    var data = notification.data;
    var type = notification.type;
    switch(type) {
        case "playing" :
            break;
        case "progress" :
            console.log(data.time);
            console.log(data.duration);
            break;
        case "ended" :
            break;
        case "fullscreenchange" :
            break;
        case "cue1" :
            console.log(data.time);
            break;
    }
}

*/
