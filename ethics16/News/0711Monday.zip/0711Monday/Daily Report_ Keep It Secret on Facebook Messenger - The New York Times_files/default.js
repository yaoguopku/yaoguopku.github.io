/*
 $Id: default.js 145881 2014-09-10 18:18:52Z hetal.thakkar $
 (c)2013 The New York Times Company
 This file has been now moved to build/mtr/src folder and now part of mtr.js
 */
