/* Elements */
var banner_container = null;
var cta_button_container = null;
var state_resolve = null;
var state_resolve_background = null;
var tunein_container = null;
var button_clicktag_1 = null;
/* Data */
var whichDate = null;
var videoPlaying = false;
var isMobileDevice = false;
var isTabletDevice = false;
var isIE = false;
var activeVideoComponent = null;
var videoComponent1 = null;
var activeVideoVO = null;
var videoVO1 = {
    id: "video-1-component",
    elementId: "video-1",
    videoContainerId: "video-1-container",
    element: null,
    videoDuration: 15000,
    sourceMP4: "videos/MrRobotS2_300x250_Prog_Rami.mp4",
    sourceWEBM: "videos/MrRobotS2_300x250_Prog_Rami.webm",
    imageSequenceImgId: "image-sequence-1-image-container",
    imageSequenceImg: null,
    imageSequenceSource: "videos/MrRobotS2_300x250_Prog_Rami.txt",
    imageSequenceFrame: 0,
    imageSequenceTotalFrames: 225,
    imageSequenceImages: []
};
var currentDate = new Date();
var currentDay = currentDate.getDate();
var currentMonth = currentDate.getMonth();
var currentYear = currentDate.getFullYear();
/**
 * All scripts and markup is ready
 */
window.onload = function () {
    /**
     * Assign elements that are commonly used
     */
    banner_container = document.getElementById("banner-container");
    state_resolve = document.getElementById("state-resolve");
    state_resolve_background = document.getElementById("state-resolve-background");
    tunein_container = document.getElementById("tunein-container");
    cta_button_container = document.getElementById("cta-button-container");
    button_clicktag_1 = document.getElementById("button-clicktag-1");
    videoVO1.imageSequenceImg = document.getElementById(videoVO1.imageSequenceImgId);

    /**
     * Detect device
     */
    var detectedDevice = deviceDetector.device;
    // TODO TESTING MOBILE
    // detectedDevice = "some phone"; // Or append ?arsonalDevice=mobile // Quick test mobile devices
    // detectedDevice = "tablet"; // Or append ?arsonalDevice=tablet // Quick test tablet devices
    console.log("arsonalDevice: " + getParameterByName("arsonalDevice"));
    if (getParameterByName("arsonalDevice") !== "") {
        detectedDevice = getParameterByName("arsonalDevice");
    }
    console.log("detectedDevice: " + detectedDevice);
    switch (detectedDevice) {
    case "desktop":
        break;
    case "tablet":
        isTabletDevice = true;
        isMobileDevice = true;
        break;
    default:
        isMobileDevice = true;
        break;
    } 

    /**
     * Date Swap
     */
    if (currentMonth <= 5 || (currentMonth == 6 && currentDay <= 11)) {
        whichDate = "ddt";
        tunein_container.style.backgroundPosition = "0px 0px";
    } else if (currentMonth == 6 && currentDay == 12) {
        whichDate = "tmrw";
        tunein_container.style.backgroundPosition = "0px -70px";
    } else if (currentMonth == 6 && (currentDay == 13)) {
        whichDate = "ton";
        cta_button_container.style.background = "url('images/USA_Robot_S2_300x250_CTA_TON.png')";
        tunein_container.style.backgroundPosition = "0px -140px";
    } else if (currentMonth == 6 && (currentDay >= 14 && currentDay <= 19) || currentDay >= 21) {
        whichDate = "post";
        tunein_container.style.backgroundPosition = "0px -210px";
    } else if (currentMonth == 6 && (currentDay == 20)) {
        whichDate = "post-ton";
        tunein_container.style.backgroundPosition = "0px -140px";
    }
    
    console.log(whichDate);
    
    if (isMobileDevice) {
        var tag = document.createElement('script');
        tag.onload = function () {
            if (EB.isInitialized()) {
                pageLoadedHandler();
            } else {
                EB.addEventListener(EBG.EventName.EB_INITIALIZED, pageLoadedHandler);
            }
        };
        tag.onabort = tag.onerror = function () {
            console.log("zepto failed to load");
            return;
        };
        tag.src = "js/zepto.min.js";
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
    } else {
        if (EB.isInitialized()) {
            pageLoadedHandler();
        } else {
            EB.addEventListener(EBG.EventName.EB_INITIALIZED, pageLoadedHandler);
        }
    }
};

/**
 * Onse all elements have loaded on the webpage initialize the banner
 */
function pageLoadedHandler() {
    activeVideoVO = videoVO1;

    banner_container.style.display = "block";
    /**
     * Setup state_initial video
     */
    if (isMobileDevice) {
        document.getElementById("video-1-container").innerHTML = "";
        $.ajax({
            url: activeVideoVO.imageSequenceSource,
            async: false,
            success: function (text) {
                activeVideoVO.imageSequenceImages = text.split('|');
                APP.play();
            }
        });
    } else {
        document.getElementById("image-sequence-1").innerHTML = "";
        document.getElementById("image-sequence-1").style.display = "none";

        videoComponent1 = new ArsonalSizmekVideo(
            activeVideoVO.id,
            activeVideoVO.elementId,
            activeVideoVO.videoContainerId,
            activeVideoVO.sourceMP4,
            activeVideoVO.sourceWEBM,
            activeVideoVO.videoDuration, true, true);
        videoComponent1.addObserver(this);
        if (isIE) {
            videoComponent1.millisecondsBeforeBufferIsValidated = 1000;
            videoComponent1.millisecondsBeforeVideoLoadedIsValidated = 2000;
        }
        videoComponent1.initialize();
        videoComponent1.addCuepoint("cue1", 14.4);
        activeVideoComponent = videoComponent1;
    }

    /**
     * Attach listeners
     */
    setTimeout(function () {
        button_clicktag_1.addEventListener("click", ClicktagHandler, false);
        if (!isMobileDevice) {
            banner_container.addEventListener("mouseenter", rollOverCTAHandler, false);
            banner_container.addEventListener("mouseleave", rollOutCTAHandler, false);
        }
        var hasHiddenProperty = getHiddenProp();
        if (hasHiddenProperty) {
            var evtname = hasHiddenProperty.replace(/[H|h]idden/, '') + 'visibilitychange';
            document.addEventListener(evtname, windowFocusHandler);
        }
    }, 1000);
}
/**
 * Rollvoer
 */
function rollOverCTAHandler(e) {
    if (!videoPlaying) {
        firePulseAnimation();
    }
}

function rollOutCTAHandler(e) {
    if (!videoPlaying) {
        document.getElementById("ripple1-container").classList.remove("pulse_Anim");
        document.getElementById("ripple2-container").classList.remove("pulse_Anim");
        document.getElementById("ripple3-container").classList.remove("pulse_Anim");
        document.getElementById("ripple4-container").classList.remove("pulse_Anim");
        document.getElementById("ripple5-container").classList.remove("pulse_Anim");
        document.getElementById("ripple6-container").classList.remove("pulse_Anim");
    }
}

function firePulseAnimation() {
    document.getElementById("ripple1-container").classList.add("pulse_Anim");
    setTimeout(function () {
        document.getElementById("ripple2-container").classList.add("pulse_Anim");
    }, 100)
    setTimeout(function () {
        document.getElementById("ripple3-container").classList.add("pulse2_Anim");
    }, 300)
    setTimeout(function () {
        document.getElementById("ripple4-container").classList.add("pulse_Anim");
    }, 200)
    setTimeout(function () {
        document.getElementById("ripple5-container").classList.add("pulse2_Anim");
    }, 400)
    setTimeout(function () {
        document.getElementById("ripple6-container").classList.add("pulse_Anim");
    }, 300)
    setTimeout(function () {
        document.getElementById("ripple7-container").classList.add("pulse2_Anim");
    }, 500)
}
/**
 * Go to state resolve
 */
function callStateResolve() {
    cta_button_container.classList.add("fadeIn");
    tunein_container.classList.add("fadeIn");
}

/**
 * Video has started
 */
function videoPlayed(e) {
    videoPlaying = true;
    document.getElementById("video-1-loader").style.display = "none";
}

/**
 * Video has completed
 */
function videoComplete(e) {
    videoPlaying = false;
    destroyStateInitial();
}

/**
 * Image sequence has completed
 */
function imageSequenceComplete(e) {
    videoPlaying = false;
    state_resolve_background.style.opacity = 1;
    destroyStateInitial();
}

/**
 * Clicked clicktag on state initial
 * @param e
 */
function ClicktagHandler(e) {
    APP.destroy();
    videoPlaying = false;
    if (activeVideoComponent) {
        activeVideoComponent.removeVideoEvents();
        if (activeVideoComponent.isVideoPlaying) {
            activeVideoComponent.pause();
        }
        activeVideoComponent = null;
        callStateResolve();
    }
    cta_button_container.style.opacity = 1;
    tunein_container.style.opacity = 1;
    state_resolve_background.style.opacity = 1;
    if (whichDate == "ton") {
        EB.clickthrough("clickTag2");
    } else {
        EB.clickthrough("clickTag1");
    }
}


/**
 * User cancelled video
 */
function videoEndFullscreen() {
    callStateResolve();
}

/**
 * Cleanup state initial video/sound and other
 */
function destroyStateInitial() {
    APP.destroy();
    if (activeVideoComponent) {
        activeVideoComponent.removeVideoEvents();
        if (activeVideoComponent.isVideoPlaying) {
            activeVideoComponent.pause();
        }
        activeVideoComponent = null;
    }
    /*document.getElementById("video-1-container").innerHTML = "";*/
}

/**
 * Cleanup state resolve video/sound and other
 */
function destroyStateResolve() {}

/**
 * ArsonalDCVideo observer callback handler
 * @param notification
 */
function receiveNotification(notification) {
    var data = notification.data;
    var type = notification.type;
    switch (type) {
    case "playing":
        videoPlayed();
        break;
    case "ended":
        videoComplete();
        break;
    case "fullscreenchange":
        videoEndFullscreen();
        break;
    case "cue1":
        callStateResolve();
        state_resolve_background.classList.add("fadeInBackground");
        break;

    }
}

/**
 * Tab/window focus has changed change
 */
function windowFocusHandler() {
    // console.log("windowFocusHandler: " + isWindowNotFocused());
    if (isWindowNotFocused()) {
        /* This tab/window blur */
        if (activeVideoComponent || isMobileDevice) {
            //state_resolve_background.style.opacity = 1;
        }
        //callStateResolve();
    } else {
        /* This tab/window focused */
    }
}

/**
 * get url variable value
 * @param name
 * @returns {string}
 */
function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

/**
 * Is tab/window focused
 * @returns {*}
 */
function isWindowNotFocused() {
    var prop = getHiddenProp();
    if (!prop) return false;
    return document[prop];
}

/**
 * get 'hidden' property
 * @returns {*}
 */
function getHiddenProp() {
    var prefixes = ['webkit', 'moz', 'ms', 'o'];
    // if 'hidden' is natively supported just return it
    if ('hidden' in document) return 'hidden';
    // otherwise loop over all the known prefixes until we find one
    for (var i = 0; i < prefixes.length; i++) {
        if ((prefixes[i] + 'Hidden') in document)
            return prefixes[i] + 'Hidden';
    }
    // otherwise it's not supported
    return null;
}

/**
 * Loop
 */
window.APP = window.APP || {};
APP.isPaused = true;
APP.accumulator = 0;
APP.seconds = 0;
APP.counter = 0;
APP.dt = (1000 / 30);

APP.testCrowseBrowserLoopPrefered = function () {
    try {
        window.requestAnimationFrame(function () {});
    } catch (e) {
        return "setInterval";
    }
    return "window.requestAnimationFrame";
};

APP.pause = function () {
    APP.isPaused = true;
    if (APP.testCrowseBrowserLoopPrefered() === "window.requestAnimationFrame") {
        window.cancelAnimationFrame(APP.core.animationFrame);
    } else {
        clearInterval(APP.core.animationFrame);
    }
};

APP.play = function () {
    APP.isPaused = false;
    APP.core.then = Date.now();
    // console.log("using preferred loop: " + APP.testCrowseBrowserLoopPrefered());
    if (APP.testCrowseBrowserLoopPrefered() === "window.requestAnimationFrame") {
        APP.core.frame();
    } else {
        APP.core.animationFrame = setInterval(APP.core.frameInterval, 1000 / 30);
    }
};

APP.destroy = function () {
    APP.pause();
    if (APP.testCrowseBrowserLoopPrefered() === "window.requestAnimationFrame") {
        APP.core.frame = function () {};
    } else {
        clearInterval(APP.core.animationFrame);
    }
};

APP.core = {
    frame: function () {
        if (APP.isPaused) return;
        APP.core.setDelta();
        APP.core.update();
        // APP.core.render();
        APP.seconds = Math.floor(APP.accumulator);
        APP.core.animationFrame = window.requestAnimationFrame(APP.core.frame);
    },
    frameInterval: function () {
        if (APP.isPaused) return;
        APP.core.setDelta();
        APP.core.update();
        APP.core.render();
        APP.seconds = Math.floor(APP.accumulator);
    },
    setDelta: function () {
        APP.core.now = Date.now();
        APP.core.delta = (APP.core.now - APP.core.then) / 1000; // seconds since last frame
        APP.core.then = APP.core.now;
        APP.accumulator += APP.core.delta;
    },
    update: function () {},
    render: function () {}
};

APP.core.update = function () {
    if (APP.counter % 4 === 0) {
        activeVideoVO.imageSequenceImg.setAttribute("src", activeVideoVO.imageSequenceImages[activeVideoVO.imageSequenceFrame]);
        if (activeVideoVO.imageSequenceFrame === activeVideoVO.imageSequenceTotalFrames) {
            imageSequenceComplete(null);
        } else if (activeVideoVO.imageSequenceFrame == 219) {
            callStateResolve();
        }
        activeVideoVO.imageSequenceFrame++;
    }
    APP.counter = ++APP.counter % 30;
};

APP.core.render = function () {};