function displayWhatsThisBox() {
	var whatsthisDiv = document.getElementById("guest-blog-box");
	if (whatsthisDiv != null){ 
		document.body.removeChild(whatsthisDiv);
	}else{
    var theMenuPosition = $(".guest-blog-link").offset();
    var theMenuLeft = theMenuPosition.left;
    var theMenuTop = theMenuPosition.top;
    var theBox = document.createElement("div");
    theBox.id = "guest-blog-box";
    var theBoxContent = "Sponsored <b>Guest Blogs</b> allow our strategic marketing partners to engage with our audience directly by leveraging UBM Tech's community publishing platform. Each guest post is created by the marketing partner and allows our audience to fully participate in the dialog, and to utilize all content sharing tools.";
    theBox.innerHTML=theBoxContent;
    document.body.appendChild(theBox);
    $(theBox).css("top",theMenuTop + 27).css("left",theMenuLeft).fadeIn("slow");
	}
	
	
}
function displayPartnerPerspectivesBox() {
    var theMenuPosition = $(".partner-perspectives-link").offset();
    var theMenuLeft = theMenuPosition.left;
    var theMenuTop = theMenuPosition.top;
    var theBox = document.createElement("div");
    theBox.id = "guest-blog-box";
    var theBoxContent = "Dark Reading's <i>Partner Perspectives</i> lets thought leaders from our sponsor community connect directly with Dark Reading's audience -- and participate in the conversation -- on the Dark Reading digital publishing platform. Each <i>Partner Perspectives</i> post is written by the sponsor. For more information on <i>Partner Perspectives</i> please email us directly at <a href='mailto:partnerperspectives@ubm.com'>partnerperspectives@ubm.com</a>.";
    theBox.innerHTML=theBoxContent;
    document.body.appendChild(theBox);
    $(theBox).css("top",theMenuTop + 27).css("left",theMenuLeft).fadeIn("slow");
}
function displayBitdefenderPartnerPerspectivesBox() {
    var theMenuPosition = $(".bitdefender-partner-perspectives-link").offset();
    var theMenuLeft = theMenuPosition.left;
    var theMenuTop = theMenuPosition.top;
    var theBox = document.createElement("div");
    theBox.id = "guest-blog-box";
    var theBoxContent = "Dark Reading's <i>Partner Perspectives</i> allows thought leaders from our sponsor community connect directly with Dark Reading's audience - and participate in the conversation - on the Dark Reading digital publishing platform. Each <i>Partner Perspectives</i> post is written by the sponsor. For more information on <i>Partner Perspectives</i> please email us directly at <a href='mailto:partnerperspectives@ubm.com'>partnerperspectives@ubm.com</a>.";
    theBox.innerHTML=theBoxContent;
    document.body.appendChild(theBox);
    $(theBox).css("top",theMenuTop + 27).css("left",theMenuLeft).fadeIn("slow");
}
function displayGeneralDynamicsFidelisPartnerPerspectivesBox() {
    var theMenuPosition = $(".GeneralDynamicsFidelis-partner-perspectives-link").offset();
    var theMenuLeft = theMenuPosition.left;
    var theMenuTop = theMenuPosition.top;
    var theBox = document.createElement("div");
    theBox.id = "guest-blog-box";
    var theBoxContent = "Dark Reading's <i>Partner Perspectives</i> allows thought leaders from our sponsor community connect directly with Dark Reading's audience - and participate in the conversation - on the Dark Reading digital publishing platform. Each <i>Partner Perspectives</i> post is written by the sponsor. For more information on <i>Partner Perspectives</i> please email us directly at <a href='mailto:partnerperspectives@ubm.com'>partnerperspectives@ubm.com</a>.";
    theBox.innerHTML = theBoxContent;
    document.body.appendChild(theBox);
    $(theBox).css("top", theMenuTop + 27).css("left", theMenuLeft).fadeIn("slow");
}
function displayPartnerPerspectivesBoxArticle() {
    var theMenuPosition = $(".partner-perspectives-link-article").offset();
    var theMenuLeft = theMenuPosition.left;
    var theMenuTop = theMenuPosition.top;
    var theBox = document.createElement("div");
    theBox.id = "guest-blog-box";
    var theBoxContent = "Dark Reading's <i>Partner Perspectives</i> lets thought leaders from our sponsor community connect directly with Dark Reading's audience -- and participate in the conversation -- on the Dark Reading digital publishing platform. Each <i>Partner Perspectives</i> post is written by the sponsor. For more information on <i>Partner Perspectives</i> please email us directly at <a href='mailto:partnerperspectives@ubm.com'>partnerperspectives@ubm.com</a>.";
    theBox.innerHTML=theBoxContent;
    document.body.appendChild(theBox);
    $(theBox).css("top",theMenuTop + 27).css("left",theMenuLeft).fadeIn("slow");
}
function displayAuthorInfoBox(el, authorName, authorTitle) {
    if ($('#featured-writer-box').length > 0) {
        document.getElementById("featured-writer-box").remove();
    }
    var theMenuPosition = $(el).offset();
    var theMenuLeft = theMenuPosition.left;
    var theMenuTop = theMenuPosition.top;
    var theBox = document.createElement("div");
    theBox.id = "featured-writer-box";
    var theBoxContent = "<span class='tiny allcaps'>" + authorName + "</span><br /><span class='tiny'>" + authorTitle + "</span>";
    theBox.innerHTML=theBoxContent;
    document.body.appendChild(theBox);
    $(theBox).css("top",theMenuTop + 47).css("left",theMenuLeft + 10).fadeIn("slow");
}
function highlightTopStory(theStory) {
    if ($(".top-headline.active").length > 0) {
        $(".top-headline.active").removeClass("active");
    }
    if ($(theStory).hasClass('theTopHeadline')) {
        // Do nothing
    } else {
        $(theStory).addClass("active");
    }
}
function showMobileIconOverlay(theName) {
// This function will display the selected mobile navigation while closing any that may be currently open
    if ($("#mobile-menu-on").length > 0) {
        var theMenu = $("#mobile-menu-on").attr("name");
        closeMobileOverlayMenu(theMenu);
    }
    $("div#mobile-menu-" + theName).attr("id","mobile-menu-on");
    goToByScroll("container-main");
}
function closeMobileOverlayMenu(theName) {
// This function will close the selected mobile navigation
    $("div#mobile-menu-on").attr("id","mobile-menu-" + theName);
}
function goToByScroll(e) {
// This function will scroll the supplied element into view
    $("html,body").animate({scrollTop:$("#"+e).offset().top},"normal");
}
function ToggleNavButtonMenu(inButtonName, inOnOrOff) {
    var menuName = inButtonName + '_popmenu';
    //alert(inButtonName + ' ' + inOnOrOff + ' ' + menuName);
    if (inOnOrOff == 'on') {
        if (inButtonName == "inside_lr_events" || inButtonName == "inside_show_news" || inButtonName == "inside_video") {
            PopMenu(menuName,(returnPosXofObj(GetObject(inButtonName)) ),(returnPosYofObj(GetObject(inButtonName)) + 18));
        } else {
            PopMenu(menuName,(returnPosXofObj(GetObject(inButtonName)) ),(returnPosYofObj(GetObject(inButtonName)) + 33));
        }
        lockPoppedMenu = true;
        lockedPoppedMenuObjName = menuName;
        ToggleNavButton(inButtonName,'on');
    } else {
        lockPoppedMenu = false;
        lockedPoppedMenuObjName = '';
        PopMenuOff(menuName, -9990, 38);
        ToggleNavButton(inButtonName,'off');
    }
}
function ToggleNavButton(inButtonName, inOnOrOff) {
    var currentTab = $("#"+inButtonName).hasClass("theSelectedNav");
    if (inButtonName == "inside_lr_events" || inButtonName == "inside_show_news" || inButtonName == "inside_video") {
        if (inOnOrOff == 'on') {
            //$('#' + inButtonName).css('background-color', '#000000').css('color','#FFFFFF');;
            //$('#' + inButtonName.replace('inside','outside')).css('background-color', '#000000');
        } else {
            if (currentTab) {
                // Do Nothing
            } else {
                //$('#' + inButtonName).css('background-color', '#F5F6F6').css('color','#484848');;
                //$('#' + inButtonName.replace('inside','outside')).css('background-color', '#ffffff');
            }
        }
    } else {
        if (inOnOrOff == 'on') {
            $('#' + inButtonName).find('a').css('color','#fff');
            $('#' + inButtonName).css('color','#fff').css('background-color','');
            //$('#' + inButtonName.replace('inside','outside')).css('background-color', '#000000');
        } else {
            if (currentTab) {
                // Do Nothing
            } else {
                $('#' + inButtonName).find('a').css('color','#fff');
                $('#' + inButtonName).css('color','#fff').css('background-color','');
                //$('#' + inButtonName.replace('inside','outside')).css('background-color', '#ffffff');
            }
        }
    }
}


var designlinesSliderHandler = new LRSliderHandler();

designlinesSliderHandler.thisSliderElementName = 'designlinesSliderHandler';
designlinesSliderHandler.sliderElementCount = 2;
designlinesSliderHandler.sliderElementSize = 798;
designlinesSliderHandler.sliderObjectViewsize = 1;
designlinesSliderHandler.sliderRightLimit = designlinesSliderHandler.sliderElementSize * ((designlinesSliderHandler.sliderElementCount - designlinesSliderHandler.sliderObjectViewsize) * -1) + 1;
designlinesSliderHandler.currentSliderElement = 1;
designlinesSliderHandler.sliderObjectId = 'designlines_outside';
designlinesSliderHandler.sliderDoSlide = false;

var designlinesLeftArrowButtonMouseoutImgSrc = 'http://img.deusm.com/eetimes/eetimes_designlines_arrow_dark_left.gif';
var designlinesRightArrowButtonMouseoutImgSrc = 'http://img.deusm.com/eetimes/eetimes_designlines_arrow_light_right.gif';

designlinesSliderHandler.LRSliderNavGraphicsHandlerSlideLeft = function() {
    // change the input box value
    //GetObject('designlines_navform_selector').value = this.currentSliderElement;
    // now deal with the images

    var currentImage = GetObject('designlines_rightarrowbutton');
    // if we're at currentSliderElement < sliderElementCount make sure the right button is active
    if (this.currentSliderElement < this.sliderElementCount) {
        currentImage.src = 'http://img.deusm.com/eetimes/eetimes_designlines_arrow_light_right.gif';
    } else {
        currentImage.src = 'http://img.deusm.com/eetimes/eetimes_designlines_arrow_dark_right.gif';
    }
    designlinesRightArrowButtonMouseoutImgSrc = currentImage.src;

    // if sliding left, change when currentSliderElement gets to 1
    currentImage = GetObject('designlines_leftarrowbutton');
    if (this.currentSliderElement == 1) {
        currentImage.src = 'http://img.deusm.com/eetimes/eetimes_designlines_arrow_dark_left.gif';
    } else {
        currentImage.src = 'http://img.deusm.com/eetimes/eetimes_designlines_arrow_light_left.gif';
    }
    designlinesLeftArrowButtonMouseoutImgSrc = currentImage.src;

}

designlinesSliderHandler.LRSliderNavGraphicsHandlerSlideRight = function() {
    // change the input box value
    //GetObject('designlines_navform_selector').value = this.currentSliderElement;
    // now deal with the images

    var currentImage = GetObject('designlines_leftarrowbutton');
    // if we're at currentSliderElement > 1 make sure the left button is active
    if (this.currentSliderElement > 1) {
        currentImage.src = 'http://img.deusm.com/eetimes/eetimes_designlines_arrow_light_left.gif';
    } else {
        currentImage.src = 'http://img.deusm.com/eetimes/eetimes_designlines_arrow_dark_left.gif';
    }
    designlinesLeftArrowButtonMouseoutImgSrc = currentImage.src;

    currentImage = GetObject('designlines_rightarrowbutton');
    // sliding right, change when currentSliderElement gets to this.sliderElementCount
    if (this.currentSliderElement == this.sliderElementCount) {
        currentImage.src = 'http://img.deusm.com/eetimes/eetimes_designlines_arrow_dark_right.gif';
    } else {
        currentImage.src = 'http://img.deusm.com/eetimes/eetimes_designlines_arrow_light_right.gif';
    }
    designlinesRightArrowButtonMouseoutImgSrc = currentImage.src;
}

var oneScrollHeight = 26;
var currentTickerItem = 0;
var numberOfTickerItems = 0;
var tickerIsPopulated = false;
var tickerTimeout;
var tickerStopped = false;

function InitializeNewsTicker() {
    if (tickerIsPopulated) {
        // attach rotate stop command to hover state and start command to hover out
        $('.newstickerwindow_item').hover(function() {
            if (tickerIsPopulated && !tickerStopped) {
                StopNewsTicker();
            }
        }, function() {
            if (tickerIsPopulated  && tickerStopped) {
                StartNewsTicker();
            }
        });
        StartNewsTicker();
    }
}

function RotateNewsTicker() {
    var newTopValue = 0;
    var newTopValueString = newTopValue.toString();
    newTopValueString = newTopValueString + 'px';
    var newCurrentTickerItem = 1;
    if (tickerIsPopulated && !tickerStopped) {
        // move down one unless we are already at the bottom, in which case scroll all the way back to the top
        if (currentTickerItem >= numberOfTickerItems) {
            // leave top value b/c we want to scroll back
            // set newCurrentPosition
            newCurrentTickerItem = 0;
            currentTickerItem = newCurrentTickerItem;
        } else {
            newCurrentTickerItem = currentTickerItem + 1;
            currentTickerItem = newCurrentTickerItem;
            newTopValue = currentTickerItem * oneScrollHeight * -1;
            newTopValueString = newTopValue.toString();
            newTopValueString = newTopValueString + 'px';
        }
        // animate
        //$('#citynewswindow_scrollcontainer').animate({ top: newTopValueString },'slow',function() { StartNewsTicker(); };);
        var tickerAnimateParams = {};
        tickerAnimateParams['top'] = newTopValueString;
        $('#citynewswindow_scrollcontainer').animate(
            tickerAnimateParams,
            'slow',
            function() {
                StartNewsTicker();
            }
        );
    }
}

function StartNewsTicker() {
    if (tickerIsPopulated) {
        tickerStopped = false;
        clearTimeout(tickerTimeout);
        tickerTimeout = setTimeout('RotateNewsTicker();',10000);
    }
}

function StopNewsTicker() {
    if (tickerIsPopulated) {
        clearTimeout(tickerTimeout);
        tickerStopped = true;
    }
}

var superNavEventsMenuOpen = false;
function ToggleSuperNavEventsMenu() {
    var menuName = 'supernav_events_popmenu';
    if (!superNavEventsMenuOpen) {
        PopMenu(menuName,(returnPosXofObj(GetObject('supernav_events_link')) - 1),(returnPosYofObj(GetObject('supernav_events_link')) + 15));
        superNavEventsMenuOpen = true;
    } else {
        superNavEventsMenuOpen = false;
        PopMenuOff(menuName, -500, 38);
    }
}
// Mobile Swipe Functionality
function swipeleftHandler(event){
    var theVideoContent = $(this).attr("id");
    theVideoContent = theVideoContent.replace('LRSlider_Content_','');
    eval(theVideoContent + "SliderHandler.LRSliderSlideRight(1)");
}
function swiperightHandler(event){
    var theVideoContent = $(this).attr("id");
    theVideoContent = theVideoContent.replace('LRSlider_Content_','');
    eval(theVideoContent + "SliderHandler.LRSliderSlideLeft(1)");
}
// Mobile Touch-Enabled Drop Down Functions
function tapholdHandler(event){
    $(".navbuttonbuttonhasmenu").not(this).each(function() {
        var buttonName = $(this).attr("name");
        ToggleNavButtonMenu(buttonName, 'off');
    });
    var buttonName = $(this).attr("name");
    ToggleNavButtonMenu(buttonName, 'on');
    $(this).find("a.color-link").click(function(event) {
        event.preventDefault();
    });
    }
    function tapholdOutHandler(event){
    $(".navbuttonbuttonhasmenu").each(function() {
        var buttonName = $(this).attr("name");
        ToggleNavButtonMenu(buttonName, 'off');
    });
}
function sizeAnyBrightcoveObjects() {
// This function scales Brightcove objects
    $("span[id^='_containermyExperience_']").css("width","100%");
    $("span[id^='_containermyExperience_'] object").width("100%");
    $("object[id^='myExperience_']").width("100%").css("width","100%");
    $("div[id^='bcplayer_'] object").width("100%").css("width","100%");
    $("#radio_player object, object, BrightcoveExperience").width("100%").css("width","100%");
}
function sizeDocImageClass() {
// This image scales docimages relative to their container
    $(".docimage").each(function() {
        var imgWidth = $(this).width();
        var colWidth = $(this).parent().width();
        if (imgWidth > colWidth) {
            $(this).width("100%");
        }
    })
}


menuMaxOpacity = 90;
$(window).load(function() {
    sizeDocImageClass();
});

$(document).ready(function() {
    $(".top-stories-image").not(":first").hide();
    $(".top-headline, .theTopHeadline").hover(function() {
        var whichHeadline = $(this).index();
        $(".top-stories-image").not("#image-"+whichHeadline).hide();
        $("#image-"+whichHeadline).show();
        if ($(this).not('.theTopHeadline')) {
            highlightTopStory(this);
        }
    });
    $(".social-icon, .intel-social-icon").hover(function() {
        $(this).css("backgroundPosition","top right");
    }, function() {
        $(this).css("backgroundPosition","top left");
    });

    $(".hottopics-item").hover(function() {
        $(this).addClass("hottopics-item-selected");
    }, function() {
        $(this).removeClass("hottopics-item-selected");
    });

    setTimeout(function() {
        sizeAnyBrightcoveObjects();
    }, 500);

    $(".partner-perspectives-link").hover(function() {
        displayPartnerPerspectivesBox();
    }, function() {
        setTimeout(function() {
            document.getElementById("guest-blog-box").remove();
        }, 500);
    });   

    $(".bitdefender-partner-perspectives-link").hover(function () {
        
        displayBitdefenderPartnerPerspectivesBox();
    }, function() {
        setTimeout(function() {
            document.getElementById("guest-blog-box").remove();
        }, 500);
    });

	$(".GeneralDynamicsFidelis-partner-perspectives-link").hover(function () {	    
	    displayGeneralDynamicsFidelisPartnerPerspectivesBox();
	}, function () {
	    setTimeout(function () {
	        document.getElementById("guest-blog-box").remove();
	    }, 500);
	});
	
	
	$(".partner-perspectives-link-article").hover(function() {
        displayPartnerPerspectivesBoxArticle();
    }, function() {
        setTimeout(function() {
            document.getElementById("guest-blog-box").remove();
        }, 200);
    });
    
	$(".intel-featured-writer").hover(function() {
        var theElement = $(this);
        var theName = $(this).find("img").attr("alt");
        var theTitle = $(this).find("img").attr("name");
        displayAuthorInfoBox(theElement, theName, theTitle);
    }, function() {
            document.getElementById("featured-writer-box").remove();
    });
	$(".carbonblack-featured-writer").hover(function() {
        var theElement = $(this);
        var theName = $(this).find("img").attr("alt");
        var theTitle = $(this).find("img").attr("name");
        displayAuthorInfoBox(theElement, theName, theTitle);
    }, function() {
            document.getElementById("featured-writer-box").remove();
    });

    // Mobile Functionality Start
        $("div.main-video-content").bind({"swipeleft": swipeleftHandler, "swiperight": swiperightHandler});
        $(".navbuttonbuttonhasmenu" ).bind("taphold", tapholdHandler);
    // Mobile Functionality End

    $('.navbuttonbutton').hover(function() {
        var buttonName = $(this).attr("name");
        ToggleNavButton(buttonName,'on');
    }, function() {
        var buttonName = $(this).attr("name");
        ToggleNavButton(buttonName,'off');
    });

    $('.navbuttonbuttonhasmenu, .navbuttonbuttonhasmenu_first').hover(function() {
        var buttonName = $(this).attr("name");
        ToggleNavButtonMenu(buttonName, 'on');
    }, function() {
        var buttonName = $(this).attr("name");
        ToggleNavButtonMenu(buttonName, 'off');
    });

    $('.popmenu').hover(function() {
        var menuName = $(this).attr("name");
        var buttonName = menuName.replace('_popmenu','');
        ToggleNavButtonMenu(buttonName, 'on');
    }, function() {
        var menuName = $(this).attr("name");
        var buttonName = menuName.replace('_popmenu','');
        ToggleNavButtonMenu(buttonName, 'off');
    });
});
