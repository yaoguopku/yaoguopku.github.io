window.rtbsBidA = (typeof window.rtbsBidA  === 'object' ) ? window.rtbsBidA : {}; 
window.rtbsBidA["538535755"] = {bl:[{bidder_id: 23, ext_placement_code: "biz-desk", no_bid: true, logging_pixels: [], og_bid: 0.0, fb: true, publisher_id: "8CU2553YN", nbc: 0, at: "O", mnet_id: "538535755", size: "300x250"}]}
