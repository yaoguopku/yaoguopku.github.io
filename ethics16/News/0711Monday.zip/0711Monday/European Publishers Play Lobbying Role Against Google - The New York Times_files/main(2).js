(function(){
	var $ = function(selector){return document.querySelector(selector);};

	if (Enabler.isInitialized()) {
	    dynamicInvocation();
	} else {
	    Enabler.addEventListener(studio.events.StudioEvent.INIT, dynamicInvocation);
	}

	function dynamicInvocation() {
		Enabler.setProfileId(1074236);

	    var devDynamicContent = {};
	    
	    devDynamicContent.AutomatedFeed= [{}];
    devDynamicContent.AutomatedFeed[0]._id = 0;
    devDynamicContent.AutomatedFeed[0].aprterm1 = "FOR UP TO 60";
    devDynamicContent.AutomatedFeed[0].AsShownDisclaimer = "As Shown $37,070 MSRP 2015 370Z Coupe Sport Tech 6M/T , other optional equipment shown, see dealer for details";
    devDynamicContent.AutomatedFeed[0].leaseCost1 = "$159";
    devDynamicContent.AutomatedFeed[0].offerTypeTemplate = ["cashback"];
    devDynamicContent.AutomatedFeed[0].aprtermcopy2 = "MONTHS";
    devDynamicContent.AutomatedFeed[0].offerPrice3 = "$750";
    devDynamicContent.AutomatedFeed[0].offerPrice4 = "$500";
    devDynamicContent.AutomatedFeed[0].startDate = {};
    devDynamicContent.AutomatedFeed[0].startDate.RawValue = "2014-12-02T00:00:00-06:00";
    devDynamicContent.AutomatedFeed[0].startDate.UtcValue = 1417500000000;
    devDynamicContent.AutomatedFeed[0].genDisclaimer = "*More Price Information";
    devDynamicContent.AutomatedFeed[0].cashbackAPRcopy1 = "APR FINANCING";
    devDynamicContent.AutomatedFeed[0].offerCopy = "Starting At";
    devDynamicContent.AutomatedFeed[0].leaseTerm2 = "36 Months, $1,799 Initial Payment";
    devDynamicContent.AutomatedFeed[0].cashbackAmount = "$2,275";
    devDynamicContent.AutomatedFeed[0].year = 2014;
    devDynamicContent.AutomatedFeed[0].offerCopy4 = "Bonus Cash<sup>[4]</sup>";
    devDynamicContent.AutomatedFeed[0].offerCopy3 = "NMAC Cash<sup>[3]</sup>";
    devDynamicContent.AutomatedFeed[0].offerCopy2 = "Package Savings<sup>[2]</sup>";
    devDynamicContent.AutomatedFeed[0].offerCopy1 = "Nissan Cash Back<sup>[1]</sup>";
    devDynamicContent.AutomatedFeed[0].DIMEOfferSetId = 923;
    devDynamicContent.AutomatedFeed[0].dma = "501,803,504,506,528,511,623,618,524,539,753,534,807,659,533,512,622,609,751,641,825,839,548,640,544,517,862,560,635,561,636,693,819,744,650,770,518,514,521,571,616,630,820,567,556,538,557,532,716,686,555,573,691,625,789,671,652,718,500,612,600,765,670,575,709,866,519,543,790,746,642,507,752,531,651,523,606,627,570,520,546,678,537,565,569,576,526,502,584,549,647,657,725,605,644,692,604,673,724,773,710,628,633,619,662,634,759,734,603,643,749,722,711,687,740,764,661,638,626,503,698,545,530,525,522,639,656,592,550,881,810,801,828,855,757,868,758,813,762,804,811,771,743,800,821,756,754,802,745,755,766,760,767,798,747,552,602,508,510,613,505,566,527,535,617,577,515,541,529,679,542,637,563,559,682,632,648,649,658,669,611,588,547,536,513,702,551,675,581,705,598,676,516,509,582,558,737,553,597,610,540,554,596,574,624,564,736,583,631,717";
    devDynamicContent.AutomatedFeed[0].modelCode = ["ZC"];
    devDynamicContent.AutomatedFeed[0].aprtermcopy1 = "FOR WELL-QUALIFIED BUYERS";
    devDynamicContent.AutomatedFeed[0].msrpCopy1 = "MSRP*";
    devDynamicContent.AutomatedFeed[0].offerPrice1 = "$1,500";
    devDynamicContent.AutomatedFeed[0].language = ["en"];
    devDynamicContent.AutomatedFeed[0].offerPrice2 = "$1,025";
    devDynamicContent.AutomatedFeed[0].offerType = "msrp";
    devDynamicContent.AutomatedFeed[0].apr_1 = "505";
    devDynamicContent.AutomatedFeed[0].offernetPricecopy = "Total Savings*";
    devDynamicContent.AutomatedFeed[0].cashbackCopy1 = "Bonus Cash<sup>[1]</sup>";
    devDynamicContent.AutomatedFeed[0].leaseTerm1 = "PER MONTH LEASE*";
    devDynamicContent.AutomatedFeed[0].model = "370Z\u00AE COUPE";
    devDynamicContent.AutomatedFeed[0].offerRollover = "2014 370Z Coupe 370Z Coupe 6M\/T Starting MSRP $29,990. Price excludes tax, title, license, options and destination charge. Dealer sets actual price. See dealer for details.  ";
    devDynamicContent.AutomatedFeed[0].DIMEOfferId = ["141860"];
    devDynamicContent.AutomatedFeed[0].offernetPrice1 = "$19,150";
    devDynamicContent.AutomatedFeed[0].region = "Central,Florida,Midwest,Northeast,Southeast,West";
    devDynamicContent.AutomatedFeed[0].offerMsrp1 = "$29,990";
    devDynamicContent.AutomatedFeed[0].endDate = {};
    devDynamicContent.AutomatedFeed[0].endDate.RawValue = "2015-1-02T23:59:59-06:00";
    devDynamicContent.AutomatedFeed[0].endDate.UtcValue = 1420264799000;
    devDynamicContent.AutomatedFeed[0].cashbackOperatorCopy1 = "APR FINANCING";
    devDynamicContent.AutomatedFeed[0].UniqueID = "en_141860";
    
    devDynamicContent.dabAwarenessOffers= [{}];

    devDynamicContent.dabAwarenessOffers[0]._id = 0;
    devDynamicContent.dabAwarenessOffers[0].DIMEOfferSetId = 942;
    devDynamicContent.dabAwarenessOffers[0].DIMEOfferId = ["144891"];

    devDynamicContent.dabAwarenessOffers[0].offerTypeTemplate = "cashback";//leasesignndrivecashback

    devDynamicContent.dabAwarenessOffers[0].isActive = true;
    devDynamicContent.dabAwarenessOffers[0].isDefault = false;
    devDynamicContent.dabAwarenessOffers[0].startDate = {};
    devDynamicContent.dabAwarenessOffers[0].startDate.RawValue = "2015-1-06T00:00:00-06:00";
    devDynamicContent.dabAwarenessOffers[0].startDate.UtcValue = 1420524000000;
    devDynamicContent.dabAwarenessOffers[0].endDate = {};
    devDynamicContent.dabAwarenessOffers[0].endDate.RawValue = "2015-2-02T23:59:59-06:00";
    devDynamicContent.dabAwarenessOffers[0].endDate.UtcValue = 1422943199000;
    devDynamicContent.dabAwarenessOffers[0].language = "en";
    devDynamicContent.dabAwarenessOffers[0].modelCode = "AS";
    devDynamicContent.dabAwarenessOffers[0].model = "370Z\u00AE COUPE";
    devDynamicContent.dabAwarenessOffers[0].year = "2014";
    devDynamicContent.dabAwarenessOffers[0].region = "Central,Florida,Midwest,Northeast,Southeast,West";
    devDynamicContent.dabAwarenessOffers[0].dma = {};
    devDynamicContent.dabAwarenessOffers[0].dma.Value = ["501", "803", "504", "506", "602", "528", "511", "524", "539", "753", "534", "807", "659", "508", "533", "512", "510", "613", "751", "825", "839", "548", "640", "544", "517", "862", "560", "561", "819", "744", "505", "770", "566", "518", "514", "527", "521", "571", "630", "820", "535", "567", "617", "577", "556", "538", "557", "532", "515", "686", "541", "555", "573", "691", "789", "500", "575", "866", "519", "543", "529", "507", "752", "679", "531", "542", "523", "637", "563", "606", "570", "520", "546", "559", "537", "682", "632", "648", "649", "658", "669", "611", "588", "547", "536", "513", "702", "551", "675", "581", "705", "598", "676", "516", "509", "582", "558", "737", "553", "597", "610", "540", "554", "596", "565", "569", "574", "576", "526", "502", "584", "549", "773", "624", "759", "564", "503", "698", "545", "530", "525", "736", "522", "639", "656", "592", "550", "881", "810", "801", "828", "855", "757", "868", "758", "813", "762", "804", "811", "771", "743", "800", "821", "756", "754", "802", "745", "755", "766", "760", "583", "767", "747", "631", "552", "717", "623", "618", "622", "609", "641", "635", "636", "693", "650", "616", "716", "625", "671", "652", "718", "612", "600", "765", "670", "709", "790", "746", "642", "651", "627", "678", "647", "657", "725", "605", "644", "692", "604", "673", "724", "710", "628", "633", "619", "662", "634", "734", "603", "643", "749", "722", "711", "687", "740", "764", "661", "638", "626", "798"];
    devDynamicContent.dabAwarenessOffers[0].apr_1 = "0.0";
    devDynamicContent.dabAwarenessOffers[0].aprtermcopy1 = "FOR WELL-QUALIFIED BUYERS";
    devDynamicContent.dabAwarenessOffers[0].aprtermcopy2 = "MONTHS";
    devDynamicContent.dabAwarenessOffers[0].aprterm1 = "FOR UP TO 60";
    devDynamicContent.dabAwarenessOffers[0].cashbackAPRcopy1 = "APR FINANCING";
    devDynamicContent.dabAwarenessOffers[0].cashbackOperatorCopy1 = "PLUS";
    devDynamicContent.dabAwarenessOffers[0].cashbackCopy1 = "PRESIDENT'S DAY BONUS CASH<sup>[1]</sup>";
    devDynamicContent.dabAwarenessOffers[0].cashbackAmount = "$1,000";
    devDynamicContent.dabAwarenessOffers[0].leaseCost1 = "$329";
    devDynamicContent.dabAwarenessOffers[0].leaseTerm1 = "PER MONTH LEASE*";
    devDynamicContent.dabAwarenessOffers[0].leaseTerm2 = "EXCLUDES DEALER FEES, TAXES, TITLE AND LICENSE";
    devDynamicContent.dabAwarenessOffers[0].SignnDrive_leaseTerm = "Lease 36 Months, $209 Per Month*";
    devDynamicContent.dabAwarenessOffers[0].offerCopy = "Starting At";
    devDynamicContent.dabAwarenessOffers[0].Lease_LeaseCash_OfferCopy = "36 Months, $2,999 Initial Payment, Excl. taxes, title and license";
    devDynamicContent.dabAwarenessOffers[0].offerCopy1 = "Federal Tax Savings<sup>[2]</sup>";
    devDynamicContent.dabAwarenessOffers[0].offerCopy2 = "NMAC Cash<sup>[3]</sup>";
    devDynamicContent.dabAwarenessOffers[0].offerCopy3 = "Local EV Incentive<sup>[4]</sup>";
    devDynamicContent.dabAwarenessOffers[0].offerCopy4 = "Bonus Cash<sup>[4]</sup>";
    devDynamicContent.dabAwarenessOffers[0].offernetPricecopy = "Total Savings*";
    devDynamicContent.dabAwarenessOffers[0].offerMsrp1 = "$29,990";
    devDynamicContent.dabAwarenessOffers[0].msrpCopy1 = "MSRP*";
    devDynamicContent.dabAwarenessOffers[0].offernetPrice1 = "$3,275";
    devDynamicContent.dabAwarenessOffers[0].offerPrice1 = "$1,000";
    devDynamicContent.dabAwarenessOffers[0].offerPrice2 = "$1,025";
    devDynamicContent.dabAwarenessOffers[0].offerPrice3 = "";
    devDynamicContent.dabAwarenessOffers[0].offerPrice4 = "";
    devDynamicContent.dabAwarenessOffers[0].AsShownDisclaimer = "As Shown $43,020 MSRP 2014 370Z Coupe 370Z Coupe 6M\/T Nismo, other optional equipment shown, see dealer for details";
    devDynamicContent.dabAwarenessOffers[0].genDisclaimer = "*More Price Information";
    devDynamicContent.dabAwarenessOffers[0].offerRollover = "As shown, $43,020 MSRP. 2014 370Z Coupe 370Z Coupe 6M\/T Nismo (other optional equipment shown; see dealer for details).  Excludes tax, title, license, destination charge and options.  Dealer sets actual price. Subject to residency restrictions. <br\/><br\/>2014 370Z Coupe 370Z Coupe 6M\/T Starting MSRP $29,990. Price excludes tax, title, license, options and destination charge. Dealer sets actual price. See dealer for details.  ";
    devDynamicContent.dabAwarenessOffers[0].offerRollover_Complete = "*As shown, $43,020 MSRP. 2014 370Z Coupe 370Z Coupe 6M\/T Nismo (other optional equipment shown; see dealer for details).  Excludes tax, title, license, destination charge and options.  Dealer sets actual price. Subject to residency restrictions. <br\/><br\/>2014 370Z Coupe 370Z Coupe 6M\/T Starting MSRP $29,990. Price excludes tax, title, license, options and destination charge. Dealer sets actual price. See dealer for details.  ";
    devDynamicContent.dabAwarenessOffers[0].Template_swf_160x600 = {};
    devDynamicContent.dabAwarenessOffers[0].Template_swf_160x600.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].Template_swf_160x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/38258102/9341_20150901231622976_DAB_160x600.swf";
    devDynamicContent.dabAwarenessOffers[0].Template_swf_300x250 = {};
    devDynamicContent.dabAwarenessOffers[0].Template_swf_300x250.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].Template_swf_300x250.Url = "https://s0.2mdn.net/ads/richmedia/studio/38257355/9341_20150901231632542_DAB_300x250.swf";
    devDynamicContent.dabAwarenessOffers[0].Template_swf_728x90 = {};
    devDynamicContent.dabAwarenessOffers[0].Template_swf_728x90.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].Template_swf_728x90.Url = "https://s0.2mdn.net/ads/richmedia/studio/38257535/9341_20150901231652233_DAB_728x90.swf";
    devDynamicContent.dabAwarenessOffers[0].Template_swf_300x600 = {};
    devDynamicContent.dabAwarenessOffers[0].Template_swf_300x600.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].Template_swf_300x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/38256588/9341_20150901231642357_DAB_300x600.swf";
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_160x600 = {};
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_160x600.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_160x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/35247475/9341_20141218225607281_msrp_160.swf";
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_300x250 = {};
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_300x250.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_300x250.Url = "https://s0.2mdn.net/ads/richmedia/studio/35257491/9341_20141219150625868_msrp_300.swf";
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_728x90 = {};
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_728x90.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_728x90.Url = "https://s0.2mdn.net/ads/richmedia/studio/35284655/9341_20141223151704625_msrp_728.swf";
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_300x600 = {};
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_300x600.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].Offertype_Swf_300x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/35259620/9341_20141219150643024_msrp_600.swf";
    devDynamicContent.dabAwarenessOffers[0].background_image_url_160x600 = {};
    devDynamicContent.dabAwarenessOffers[0].background_image_url_160x600.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].background_image_url_160x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/35159731/9341_20141210074944280_linearGray_160x600.jpg";
    devDynamicContent.dabAwarenessOffers[0].background_image_url_300x250 = {};
    devDynamicContent.dabAwarenessOffers[0].background_image_url_300x250.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].background_image_url_300x250.Url = "https://s0.2mdn.net/ads/richmedia/studio/35158164/9341_20141210074951704_linearGray_300x250.jpg";
    devDynamicContent.dabAwarenessOffers[0].background_image_url_728x90 = {};
    devDynamicContent.dabAwarenessOffers[0].background_image_url_728x90.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].background_image_url_728x90.Url = "https://s0.2mdn.net/ads/richmedia/studio/35161404/9341_20141210075012486_linearGray_728x90.jpg";
    devDynamicContent.dabAwarenessOffers[0].background_image_url_300x600 = {};
    devDynamicContent.dabAwarenessOffers[0].background_image_url_300x600.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].background_image_url_300x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/35158742/9341_20141210075003855_linearGray_300x600.jpg";
    devDynamicContent.dabAwarenessOffers[0].buildTxt = "BUILD";
    devDynamicContent.dabAwarenessOffers[0].baseBuildUrl = {};
    devDynamicContent.dabAwarenessOffers[0].baseBuildUrl.Url = "http://www.nissanusa.com/tools/build/zcoupe";
    devDynamicContent.dabAwarenessOffers[0].brochureTxt = "SHOP NOW";
    devDynamicContent.dabAwarenessOffers[0].baseBrochureUrl = {};
    devDynamicContent.dabAwarenessOffers[0].baseBrochureUrl.Url = "http://www.choosenissan.com/";
    devDynamicContent.dabAwarenessOffers[0].baseLandingUrl = {};
    devDynamicContent.dabAwarenessOffers[0].baseLandingUrl.Url = "http://www.choosenissan.com/";
    devDynamicContent.dabAwarenessOffers[0].modelyear = "ZC 2014";
    devDynamicContent.dabAwarenessOffers[0].creativeId = [0, 56210607, 56210605, 57037199, 56210602, 58248980, 58249417, 58249048, 58249644];
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_160x600 = {};
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_160x600.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_160x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/35163618/9341_20141210101651869_370zCoupe_160x600.png";
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_300x250 = {};
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_300x250.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_300x250.Url = "https://s0.2mdn.net/ads/richmedia/studio/35164502/9341_20141210101945001_370zCoupe_300x250.png";
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_300x600 = {};
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_300x600.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_300x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/35160162/9341_20141210102258866_370zCoupe_300x600.png";
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_728x90 = {};
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_728x90.Type = "file";
    devDynamicContent.dabAwarenessOffers[0].DAB_carImage_728x90.Url = "https://s0.2mdn.net/ads/richmedia/studio/35164513/9341_20141210102654229_370zCoupe_728x90.png";
    devDynamicContent.dabAwarenessOffers[0].DMA_reporting_field = "501,803,504,506,602,528,511,524,539,753,534,807,659,508,533,512,510,613,751,825,839,548,640,544,517,862,560,561,819,744,505,770,566,518,514,527,521,571,630,820,535,567,617,577,556,538,557,532,515,686,541,555,573,691,789,500,575,866,519,543,529,507,752,679,531,542,523,637,563,606,570,520,546,559,537,682,632,648,649,658,669,611,588,547,536,513,702,551,675,581,705,598,676,516,509,582,558,737,553,597,610,540,554,596,565,569,574,576,526,502,584,549,773,624,759,564,503,698,545,530,525,736,522,639,656,592,550,881,810,801,828,855,757,868,758,813,762,804,811,771,743,800,821,756,754,802,745,755,766,760,583,767,747,631,552,717,623,618,622,609,641,635,636,693,650,616,716,625,671,652,718,612,600,765,670,709,790,746,642,651,627,678,647,657,725,605,644,692,604,673,724,710,628,633,619,662,634,734,603,643,749,722,711,687,740,764,661,638,626,798";
	
	//ADD THIS COLUMN TO THE "OFFERS" FEED.
    //THIS IS WHERE THE EVENT SHOTS WILL BE CALLED IF THE CONDITIONS ARE MET OR 
    //THERE IS AN EVENT RUNNING
	devDynamicContent.dabAwarenessOffers[0].Sale_carImage_300x250 = {};
	devDynamicContent.dabAwarenessOffers[0].Sale_carImage_300x250 .Type = "file";
	devDynamicContent.dabAwarenessOffers[0].Sale_carImage_300x250 .Url = "https://s0.2mdn.net/ads/richmedia/studio/39675372/9341_20151103151739553_dab_murano_300x250.png";
	
	//SALE EVENT FEED
    devDynamicContent.salesEvent= [{}];
	
    devDynamicContent.salesEvent[0]._id = 0;
    devDynamicContent.salesEvent[0].ID = "nosale_1";
    devDynamicContent.salesEvent[0].title = "cy16";
    devDynamicContent.salesEvent[0].sales_swf = "nosale";
    devDynamicContent.salesEvent[0].creativeId = [];
    devDynamicContent.salesEvent[0].isActive = false;
    devDynamicContent.salesEvent[0].default_sale = true;
    devDynamicContent.salesEvent[0].startDate = {};
    devDynamicContent.salesEvent[0].startDate.RawValue = " ";
    devDynamicContent.salesEvent[0].startDate.UtcValue = 0;
    devDynamicContent.salesEvent[0].endDate = {};
    devDynamicContent.salesEvent[0].endDate.RawValue = "";
    devDynamicContent.salesEvent[0].endDate.UtcValue = 0;
    devDynamicContent.salesEvent[0].swfUrl_160x600 = {};
    devDynamicContent.salesEvent[0].swfUrl_160x600.Type = "file";
    devDynamicContent.salesEvent[0].swfUrl_160x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/36207871/9341_20150401160326581__Filler.png";
    devDynamicContent.salesEvent[0].swfUrl_300x250 = {};
    devDynamicContent.salesEvent[0].swfUrl_300x250.Type = "file";
    devDynamicContent.salesEvent[0].swfUrl_300x250.Url = "https://s0.2mdn.net/ads/richmedia/studio/40686702/9341_20151230073600786_2016_dab_300x250_e.png";
    devDynamicContent.salesEvent[0].swfUrl_728x90 = {};
    devDynamicContent.salesEvent[0].swfUrl_728x90.Type = "file";
    devDynamicContent.salesEvent[0].swfUrl_728x90.Url = "https://s0.2mdn.net/ads/richmedia/studio/36207871/9341_20150401160326581__Filler.png";
    devDynamicContent.salesEvent[0].swfUrl_300x600 = {};
    devDynamicContent.salesEvent[0].swfUrl_300x600.Type = "file";
    devDynamicContent.salesEvent[0].swfUrl_300x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/36207871/9341_20150401160326581__Filler.png";
    devDynamicContent.salesEvent[0].saleEventH5_160x600 = {};
    devDynamicContent.salesEvent[0].saleEventH5_160x600.Type = "file";
    devDynamicContent.salesEvent[0].saleEventH5_160x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/36207871/9341_20150401160326581__Filler.png";
    devDynamicContent.salesEvent[0].saleEventH5_300x250 = {};
    devDynamicContent.salesEvent[0].saleEventH5_300x250.Type = "file";
    devDynamicContent.salesEvent[0].saleEventH5_300x250.Url = "https://s0.2mdn.net/ads/richmedia/studio/38628192/9341_20150917172445302_default_300x250_en.png";
    devDynamicContent.salesEvent[0].saleEventH5_300x600 = {};
    devDynamicContent.salesEvent[0].saleEventH5_300x600.Type = "file";
    devDynamicContent.salesEvent[0].saleEventH5_300x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/36207871/9341_20150401160326581__Filler.png";
    devDynamicContent.salesEvent[0].saleEventH5_728x90 = {};
    devDynamicContent.salesEvent[0].saleEventH5_728x90.Type = "file";
    devDynamicContent.salesEvent[0].saleEventH5_728x90.Url = "https://s0.2mdn.net/ads/richmedia/studio/36207871/9341_20150401160326581__Filler.png";
	
    devDynamicContent.salesEvent[0].DABIntroVideo_160x600 = {};
    devDynamicContent.salesEvent[0].DABIntroVideo_160x600.Type = "file";
    devDynamicContent.salesEvent[0].DABIntroVideo_160x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/36207871/9341_20150401160326581__Filler.png";
    devDynamicContent.salesEvent[0].DABIntroVideo_300x600 = {};
    devDynamicContent.salesEvent[0].DABIntroVideo_300x600.Type = "file";
    devDynamicContent.salesEvent[0].DABIntroVideo_300x600.Url = "https://s0.2mdn.net/ads/richmedia/studio/36207871/9341_20150401160326581__Filler.png";
    devDynamicContent.salesEvent[0].DABIntroVideo_728x90 = {};
    devDynamicContent.salesEvent[0].DABIntroVideo_728x90.Type = "file";
    devDynamicContent.salesEvent[0].DABIntroVideo_728x90.Url = "https://s0.2mdn.net/ads/richmedia/studio/36207871/9341_20150401160326581__Filler.png";
    devDynamicContent.salesEvent[0].DABIntroVideo_300x250 = {};
    devDynamicContent.salesEvent[0].DABIntroVideo_300x250.Type = "file";
    devDynamicContent.salesEvent[0].DABIntroVideo_300x250.Url = "https://s0.2mdn.net/ads/richmedia/studio/36207871/9341_20150401160326581__Filler.png";
    devDynamicContent.salesEvent[0].H5DABIntroVideo_160x600 = "DRM_Asset:Nissan Dynamic - Unibucket\/Nissan Dynamic - Asset Library\/_Filler.png";
    devDynamicContent.salesEvent[0].H5DABIntroVideo_300x600 = "DRM_Asset:Nissan Dynamic - Unibucket\/Nissan Dynamic - Asset Library\/_Filler.png";
    devDynamicContent.salesEvent[0].H5DABIntroVideo_728x90 = "DRM_Asset:Nissan Dynamic - Unibucket\/Nissan Dynamic - Asset Library\/_Filler.png";
    devDynamicContent.salesEvent[0].H5DABIntroVideo_300x250 = "DRM_Asset:Nissan Dynamic - Unibucket\/Nissan Dynamic - Asset Library\/_Filler.png";
    devDynamicContent.salesEvent[0].textColor = "";
    devDynamicContent.salesEvent[0].impTracker1 = "";
    devDynamicContent.salesEvent[0].impTracker2 = "";
    devDynamicContent.salesEvent[0].model_year_prefix_color_handler = "#2E64FE";
    devDynamicContent.salesEvent[0].nissan_copy_color_handler = "#2E64FE";
    devDynamicContent.salesEvent[0].apr_up_to_copy = "#2E64FE";
    devDynamicContent.salesEvent[0].cashbackOperator_static_color_handler = "#2E64FE";
    devDynamicContent.salesEvent[0].leasesigndrive_0_static_color_handler = "#2E64FE";
    devDynamicContent.salesEvent[0].leasesigndrive_text_static_color_handler = "#2E64FE";
    devDynamicContent.salesEvent[0].line_divider_color_handler = "#2E64FE";
    devDynamicContent.salesEvent[0].model_color_handler = "#2E64FE";
    devDynamicContent.salesEvent[0].year_color_handler = "#2E64FE";
    devDynamicContent.salesEvent[0].apr_1_color_handler = "#2E64FE";
    devDynamicContent.salesEvent[0].aprtermcopy1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].aprtermcopy2_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].aprterm1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].cashbackAPRcopy1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].cashbackOperatorCopy1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].cashbackCopy1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].cashbackAmount_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].leaseCost1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].leaseTerm1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].leaseTerm2_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].SignnDrive_leaseTerm_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerCopy_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].Lease_LeaseCash_OfferCopy_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerCopy1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerCopy2_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerCopy3_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerCopy4_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offernetPricecopy_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerMsrp1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].msrpCopy1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offernetPrice1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerPrice1_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerPrice2_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerPrice3_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerPrice4_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].AsShownDisclaimer_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].genDisclaimer_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].offerRollover_Complete_color_hander = "#2E64FE";
    devDynamicContent.salesEvent[0].buildTxt_color_handler = "#2E64FE";
    devDynamicContent.salesEvent[0].brochureTxt_color_handler = "#2E64FE";
	
	devDynamicContent.salesEvent[0].SpecialSale_carImage_300x250 = {};
	devDynamicContent.salesEvent[0].SpecialSale_carImage_300x250.Type = "file";
	devDynamicContent.salesEvent[0].SpecialSale_carImage_300x250.Url = "https://s0.2mdn.net/ads/richmedia/studio/38566411/9341_20150915174339092_altima_300x250_template.jpg";

    //MODEL CODE and OFFERTYPE FILTER COLUMNS
    devDynamicContent.salesEvent[0].modelCodeFilter = "AS,MU,FT,ZC";
    devDynamicContent.salesEvent[0].offerTypeFilter = "apr,leasecash,msrp,leasesignndrivecashback,lease,aprcashback";
	
    Enabler.setDevDynamicContent(devDynamicContent);
	    
		var carExitURL1 = [];
		var carExitURL2 = [];
		carExitURL1 = dynamicContent.dabAwarenessOffers[0].baseBrochureUrl.Url.split("/");
		carExitURL2 = dynamicContent.dabAwarenessOffers[0].baseBuildUrl.Url.split("/");
		brochureExit = carExitURL1[0]+ "//" + carExitURL1[2] + "/";
		baseLandingUrl = carExitURL2[0]+ "//" + carExitURL2[2] + "/";

        Enabler.loadScript("https://s0.2mdn.net/ads/richmedia/studio/36493392/9341_20150428192342420_dab_dmaRegional.js");

		return new Offer();
	};

	function Offer(){
		console.log(this);

        //ADD MODEL AND OFFERTYPE FILTERS TO THE SALEEVENT FEED
        //ADDED ON 1/11/2016
        var offerType = dynamicContent.salesEvent[0].offerTypeFilter.split(",");
        var model = dynamicContent.salesEvent[0].modelCodeFilter.split(",");

        if( ( offerType.length > -1 || model.length > -1) && (  offerType.indexOf( dynamicContent.dabAwarenessOffers[0].offerTypeTemplate ) > -1 || model.indexOf( dynamicContent.dabAwarenessOffers[0].modelCode ) > -1 ) ) {
            dynamicContent.salesEvent[0].saleEventH5_300x250.Url = dynamicContent.salesEvent[0].swfUrl_300x250.Url;
            dynamicContent.dabAwarenessOffers[0].Sale_carImage_300x250.Url = dynamicContent.dabAwarenessOffers[0].Sale_carImage_300x250.Url;
        } else {
            dynamicContent.salesEvent[0].saleEventH5_300x250.Url = dynamicContent.salesEvent[0].saleEventH5_300x250.Url;
            dynamicContent.dabAwarenessOffers[0].Sale_carImage_300x250.Url =  dynamicContent.dabAwarenessOffers[0].DAB_carImage_300x250.Url;
        }

        //END OF ADDED LINES

		//dynamicContent.salesEvent[0].saleEventH5_300x250.Url = (dynamicContent.dabAwarenessOffers[0].modelCode == "AS" && (dynamicContent.salesEvent[0].title == "royl" || dynamicContent.salesEvent[0].title == "cy16" )) ? dynamicContent.salesEvent[0].swfUrl_300x250.Url : dynamicContent.salesEvent[0].saleEventH5_300x250.Url;
		dynamicContent.dabAwarenessOffers[0].background_image_url_300x250.Url = ( dynamicContent.dabAwarenessOffers[0].modelCode == "AS" ) ? dynamicContent.salesEvent[0].SpecialSale_carImage_300x250.Url : dynamicContent.dabAwarenessOffers[0].background_image_url_300x250.Url;
		this.content = "";
    	this.offer = dynamicContent.dabAwarenessOffers[0].offerTypeTemplate;
    	this.model = dynamicContent.dabAwarenessOffers[0].model.split("®").join("<sup>\u00AE</sup>");
    	this.year = dynamicContent.dabAwarenessOffers[0].year;
    	this.salesEvent = dynamicContent.salesEvent[0].title;
        this.salesEventImg = (this.salesEvent == "l4l" || this.salesEvent == "minievent" || this.salesEvent == "nosale") ? dynamicContent.dabAwarenessOffers[0].background_image_url_300x250.Url : dynamicContent.salesEvent[0].saleEventH5_300x250.Url;
        this.bgImg = (this.salesEventImg.length > 0 && this.salesEventImg.indexOf("Filler") < 0 && this.salesEventImg.indexOf("filler") < 0) ? "background-image:url("+ this.salesEventImg +")":"background-image:url("+ dynamicContent.offer[0].background_image_url_300x250.Url +")";
		
		//ADDED ON 1/7/2016
		this.salesCarImg = (this.salesEvent == "l4l" || this.salesEvent == "minievent" || this.salesEvent == "nosale") ? dynamicContent.dabAwarenessOffers[0].DAB_carImage_300x250.Url : dynamicContent.dabAwarenessOffers[0].Sale_carImage_300x250.Url;
		this.carImg = ( this.salesCarImg.length > 0 && this.salesCarImg.indexOf( "Filler" ) < 0 && this.salesCarImg.indexOf( "filler" ) < 0 ) ? "background-image:url("+ this.salesCarImg +")" : "background-image:url("+ dynamicContent.offer[0].DAB_carImage_300x250.Url +")";
		
    	//this.carImg = (dynamicContent.dabAwarenessOffers[0].DAB_carImage_300x250.Url.length > 0)? "background-image:url(" + dynamicContent.dabAwarenessOffers[0].DAB_carImage_300x250.Url + ")":"background-color:rgba(0,0,0,0)";
        this.landingUrl = dynamicContent.dabAwarenessOffers[0].baseLandingUrl.Url;
    	this.buildUrl = dynamicContent.dabAwarenessOffers[0].baseBuildUrl.Url;
    	this.buildTxt = dynamicContent.dabAwarenessOffers[0].buildTxt;
    	this.brochureTxt = dynamicContent.dabAwarenessOffers[0].brochureTxt;
    	this.brochureUrl = dynamicContent.dabAwarenessOffers[0].baseBrochureUrl.Url;
    	this.disclaimerTxt = (dynamicContent.dabAwarenessOffers[0].genDisclaimer.indexOf("*") >= 0) ? dynamicContent.dabAwarenessOffers[0].genDisclaimer : "*" + dynamicContent.dabAwarenessOffers[0].genDisclaimer;
    	this.asShownDisclaimerTxt = dynamicContent.dabAwarenessOffers[0].AsShownDisclaimer;
		this.offerRollover = "*" + dynamicContent.dabAwarenessOffers[0].offerRollover;
	
    	disclaimerContentL4L = "This information does not constitute tax or legal advice.  Lease price depends on individual circumstances, including the availability of certain tax credits.  All persons should consult with their own tax and/or legal professional and state law to determine eligibility and any further details.<br>";
    	this.disclaimerContent = (this.salesEvent == "l4l")?(this.offer == "lease" || this.offer == "leasecash") ? disclaimerContentL4L + this.offerRollover : this.offerRollover : this.offerRollover;
        //General Colors
        this.model_year_prefix_color = dynamicContent.salesEvent[0].model_year_prefix_color_handler;
        this.nissan_copy_color = dynamicContent.salesEvent[0].nissan_copy_color_handler;
        this.apr_up_to_copy = dynamicContent.salesEvent[0].apr_up_to_copy;
        this.line_divider_color = dynamicContent.salesEvent[0].line_divider_color_handler;
        this.model_color = dynamicContent.salesEvent[0].model_color_handler;
        this.year_color = dynamicContent.salesEvent[0].year_color_handler;
        this.genDisclaimer_color = dynamicContent.salesEvent[0].genDisclaimer_color_hander;
        this.AsShownDisclaimer_color = dynamicContent.salesEvent[0].AsShownDisclaimer_color_hander;
        this.offerRollover_Complete_color = dynamicContent.salesEvent[0].offerRollover_Complete_color_hander;
        this.cashbackOperator_static_color = dynamicContent.salesEvent[0].cashbackOperator_static_color_handler;
    	//apr
		this.apr = (dynamicContent.dabAwarenessOffers[0].apr_1 == 0) ? "0" : dynamicContent.dabAwarenessOffers[0].apr_1;
		this.aprCopy = dynamicContent.dabAwarenessOffers[0].cashbackAPRcopy1;
        this.apr_1_color = dynamicContent.salesEvent[0].apr_1_color_handler;
        this.cashbackAPRcopy1_color = dynamicContent.salesEvent[0].cashbackAPRcopy1_color_hander;
		// this.aprTerm = dynamicContent.dabAwarenessOffers[0].aprterm1 + " " + dynamicContent.dabAwarenessOffers[0].aprtermcopy2 + "<BR>" + dynamicContent.dabAwarenessOffers[0].aprtermcopy1;
		this.aprTerm = dynamicContent.dabAwarenessOffers[0].aprterm1 + " " + dynamicContent.dabAwarenessOffers[0].aprtermcopy2;
		this.aprTerm2 = dynamicContent.dabAwarenessOffers[0].aprtermcopy1;
        this.aprtermcopy1_color = dynamicContent.salesEvent[0].aprtermcopy1_color_hander;
        this.aprtermcopy2_color = dynamicContent.salesEvent[0].aprtermcopy2_color_hander; // same as aprterm1_color_hander
		//lease
		this.leaseCost = this.checkCurrency(dynamicContent.dabAwarenessOffers[0].leaseCost1);
		this.leaseTerm = dynamicContent.dabAwarenessOffers[0].leaseTerm1;
		this.leaseCopy = dynamicContent.dabAwarenessOffers[0].Lease_LeaseCash_OfferCopy;
        this.leaseCost1_color = dynamicContent.salesEvent[0].leaseCost1_color_hander;
        this.leaseTerm1_color = dynamicContent.salesEvent[0].leaseTerm1_color_hander;
        this.Lease_LeaseCash_OfferCopy_color = dynamicContent.salesEvent[0].Lease_LeaseCash_OfferCopy_color_hander;
		//leasecash
		this.cashbackAmount = (this.offer == "leasesignndrivecashback") ? dynamicContent.dabAwarenessOffers[0].cashbackAmount : this.checkCurrency(dynamicContent.dabAwarenessOffers[0].cashbackAmount);
		this.cashbackCopy = dynamicContent.dabAwarenessOffers[0].cashbackCopy1;
        this.cashbackAmount_color = dynamicContent.salesEvent[0].cashbackAmount_color_hander;
        this.cashbackCopy1_color = dynamicContent.salesEvent[0].cashbackCopy1_color_hander;
		//cashback
		this.netPrice = this.checkCurrency(dynamicContent.dabAwarenessOffers[0].offernetPrice1);
		this.netCopy = dynamicContent.dabAwarenessOffers[0].offernetPricecopy;
		this.operatorCopy = dynamicContent.dabAwarenessOffers[0].cashbackOperatorCopy1;
        this.cashbackOperatorCopy1_color = dynamicContent.salesEvent[0].cashbackOperatorCopy1_color_hander;
        this.offernetPrice1_color = dynamicContent.salesEvent[0].offernetPrice1_color_hander;
        this.offernetPricecopy_color = dynamicContent.salesEvent[0].offernetPricecopy_color_hander;
		//msrp
		this.msrp = this.checkCurrency(dynamicContent.dabAwarenessOffers[0].offerMsrp1);
		this.msrpCopy = dynamicContent.dabAwarenessOffers[0].msrpCopy1;
        this.offerCopy_color = dynamicContent.salesEvent[0].offerCopy_color_hander;
        this.offerMsrp1_color = dynamicContent.salesEvent[0].offerMsrp1_color_hander;
        this.msrpCopy1_color = dynamicContent.salesEvent[0].msrpCopy1_color_hander;
		//mathstack
		this.posOfferPrice = [dynamicContent.dabAwarenessOffers[0].offerPrice1.toLowerCase().replace("up to",""),
							dynamicContent.dabAwarenessOffers[0].offerPrice2,
							dynamicContent.dabAwarenessOffers[0].offerPrice3,
							dynamicContent.dabAwarenessOffers[0].offerPrice4];

        this.posOfferPriceColor = [dynamicContent.salesEvent[0].offerPrice1_color_hander,
                            dynamicContent.salesEvent[0].offerPrice2_color_hander,
                            dynamicContent.salesEvent[0].offerPrice3_color_hander,
                            dynamicContent.salesEvent[0].offerPrice4_color_hander];

		this.posOfferCopy = [dynamicContent.dabAwarenessOffers[0].offerCopy1,
					dynamicContent.dabAwarenessOffers[0].offerCopy2,
					dynamicContent.dabAwarenessOffers[0].offerCopy3,
					dynamicContent.dabAwarenessOffers[0].offerCopy4];

        this.posOfferCopyColor = [dynamicContent.salesEvent[0].offerCopy1_color_hander,
                    dynamicContent.salesEvent[0].offerCopy2_color_hander,
                    dynamicContent.salesEvent[0].offerCopy3_color_hander,
                    dynamicContent.salesEvent[0].offerCopy4_color_hander];

		this.negOfferPrice = [dynamicContent.dabAwarenessOffers[0].offerMsrp1,
							dynamicContent.dabAwarenessOffers[0].offerPrice1.toLowerCase().replace("up to",""),
							dynamicContent.dabAwarenessOffers[0].offerPrice2,
							dynamicContent.dabAwarenessOffers[0].offerPrice3];

        this.negOfferPriceColor = [dynamicContent.salesEvent[0].offerMsrp1_color_hander,
                            dynamicContent.salesEvent[0].offerPrice1_color_hander,
                            dynamicContent.salesEvent[0].offerPrice2_color_hander,
                            dynamicContent.salesEvent[0].offerPrice3_color_hander];

		this.negOfferCopy = [dynamicContent.dabAwarenessOffers[0].msrpCopy1,
					dynamicContent.dabAwarenessOffers[0].offerCopy1,
					dynamicContent.dabAwarenessOffers[0].offerCopy2,
					dynamicContent.dabAwarenessOffers[0].offerCopy3];

        this.negOfferCopyColor = [dynamicContent.salesEvent[0].msrpCopy1_color_hander,
                    dynamicContent.salesEvent[0].offerCopy1_color_hander,
                    dynamicContent.salesEvent[0].offerCopy2_color_hander,
                    dynamicContent.salesEvent[0].offerCopy3_color_hander];

		this.offerPrice = (this.offer == "mathstack") ? this.posOfferPrice : (this.offer == "negmathstack") ? this.negOfferPrice : "";
		this.offerCopy = (this.offer == "mathstack") ? this.posOfferCopy: (this.offer == "negmathstack") ? this.negOfferCopy : "";
        this.offerPriceColor = (this.offer == "mathstack") ? this.posOfferPriceColor : (this.offer == "negmathstack") ? this.negOfferPriceColor : "";
        this.offerCopyColor = (this.offer == "mathstack") ? this.posOfferCopyColor: (this.offer == "negmathstack") ? this.negOfferCopyColor : "";

		this.headCopy = dynamicContent.dabAwarenessOffers[0].offerCopy;
        this.leaseTerm_snd = dynamicContent.dabAwarenessOffers[0].leaseTerm2;
		//snd
		this.snd_leaseTerm = dynamicContent.dabAwarenessOffers[0].SignnDrive_leaseTerm;
        this.leasesigndrive_text_static_color = dynamicContent.salesEvent[0].leasesigndrive_text_static_color_handler;
        this.leasesigndrive_0_static_color = dynamicContent.salesEvent[0].leasesigndrive_0_static_color_handler;
        this.leaseTerm2_color = dynamicContent.salesEvent[0].leaseTerm2_color_hander;
        this.SignnDrive_leaseTerm_color = dynamicContent.salesEvent[0].SignnDrive_leaseTerm_color_hander;
		
		//this.videoURLS = dynamicContent.salesEvent[0].H5DABIntroVideo_300x250;

	    this.createContent();
		this.addClick();
	}

	Offer.prototype.createContent = function() {
		$('.container').classList.add(this.offer);
		$('.container').setAttribute('style', this.bgImg);
		this.content += "<div class='carImg' style=" + this.carImg + ">";
		this.content += "<div class='logo'></div>";//logo
		this.addOfferContent();
		this.content += "<div class='model'>"
		this.content += (this.model.toUpperCase().indexOf("LEAF") >= 0) ? "<div class='year' style='font-size:9px!important'><span style=color:"+this.model_year_prefix_color+">THE</span> <span style=color:"+this.year_color+">" + this.year + "</span></div>" : "<div class='year'><span style=color:"+this.model_year_prefix_color+">THE</span> <span style=color:"+this.year_color+">" + this.year + "</span></div>";
		this.content += (this.model.toUpperCase().indexOf("HYBRID") >= 0 || this.model.toUpperCase().indexOf("CROSSCABRIOLET") >= 0) ? "<div class='name' style='font-size:10px!important'><span style=color:"+this.nissan_copy_color+">NISSAN</span> <span style=color:"+this.model_color+">" + this.model + "</span></div>" : "<div class='name'><span style=color:"+this.nissan_copy_color+">NISSAN</span> <span style=color:"+this.model_color+">" + this.model + "</span></div>";
		this.content += "</div>"//model year and name
		this.content += "<div class='cta cta1'>";
		this.content +=	"<div class='ctaTxt'>" + this.brochureTxt + "</div>";
		this.content +=	"</div>";//brochure button
		this.content += "<div class='cta cta2'>";
		this.content +=	"<div class='ctaTxt'>" + this.buildTxt + "</div>";
		this.content +=	"</div>";//build button
		this.content +=	"<div class='disclaimerTxt' style=color:"+this.genDisclaimer_color+">" + this.disclaimerTxt + "</div>";//dialog text
		this.content +=	"<div class='asShownDisclaimerTxt' style=color:"+this.AsShownDisclaimer_color+">" + this.asShownDisclaimerTxt + "</div>";
		this.content +=	"<div class='disclaimerBox'>";
		this.content +=	"<div class='closeBtn'></div>";//close button
		this.content +=	"<div class='disclaimerContent' style=color:"+this.offerRollover_Complete_color+">" + this.disclaimerContent + "</div>";//dialog content
		this.content +=	"</div>";//dialog box
		this.content += "</div>";
		//this.addVideo();
		$(".container").innerHTML = this.content;

		this.setContent();

        // if ( navigator.userAgent.indexOf("Chrome") != -1 ) {
        //     $(".logo").style.left = "12px";
        //     //alert("-- logo -- " + document.getElementsByClassName('logo').style);
        // }
	};

	//Offer.prototype.addVideo = function() {
	//	if(this.videoURLS.length > 0 && this.videoURLS.indexOf("Filler") < 0 && this.videoURLS.indexOf("filler") < 0){
	//		var videoURL = this.videoURLS.split("|");
	//		var extension;
	//		console.log(videoURL);
	//
	//		this.content += "<div class='videobox'>"
	//		this.content += "<video class='vid' autoplay>";
	//		for (var i = 0; i < videoURL.length; i++) {
	//			extension = videoURL[i].substr(videoURL[i].lastIndexOf(".")+1, videoURL[i].length);
	//			this.content += "<source src=" + videoURL[i] + " type='video/"+ extension +"'>";
	//		}
	//		this.content += "</video>";
	//		this.content += "</div>"
	//	}
	//
	//	return this.content;
	//};
	//
	//Offer.prototype.setVideo = function() {
	//	if(this.videoURLS.length > 0 && this.videoURLS.indexOf("Filler") < 0 && this.videoURLS.indexOf("filler") < 0){
	//        Enabler.loadModule(studio.module.ModuleId.VIDEO, function() {
	//            studio.video.Reporter.attach('video_play', $(".vid"));
	//        });
	//
	//        $(".vid").addEventListener('ended',function(){
	//        	this.style.display = "none";
	//        	$(".videobox").addEventListener('transitionend',function(){
	//        		this.style.display = "none";
	//        	});
	//        	$(".videobox").classList.add('fadeOut');
	//        });
	//    }
	//};

	Offer.prototype.priceCount = function() {
		var priceNum = 0;
		for(var i in this.offerPrice){
			this.offerPrice[i] = this.offerPrice[i].replace(/^\s+|\s+$/gm,'');
			(this.offerPrice[i] || '')? priceNum++:priceNum;
		}
		return priceNum;
	};

	Offer.prototype.checkCurrency = function(amount) {
		amount = (amount.indexOf("$") >= 0) ? amount : "$" + amount;
		return this.superScriptText(amount,'$');
	};

	Offer.prototype.addOfferContent = function() {
		switch(this.offer){
			case 'apr':
				this.content += "<div class='content'>";
				this.content += "<div class='tr'>";
				this.content += "<div class='rate td' style=color:"+this.apr_1_color+">" + this.apr + "<div class='sup'>%</div></div>";
				this.content += "</div>";
				this.content += "<div class='tr'>";
				this.content += "<div class='td' style=color:"+this.cashbackAPRcopy1_color+">" + this.aprCopy;
				this.content += "<span style=color:"+this.aprtermcopy2_color+">" + this.aprTerm + "</span>";
				this.content += "</div>";
				this.content += "</div>";
				this.content += "<div class='tr'>";
				//this.content += "<div class='td'>" + this.superScriptBracket(this.aprTerm2) + "</div>";
				this.content += "<div class='td' style=color:"+this.aprtermcopy1_color+">" + this.aprTerm2 + "</div>";
				this.content += "</div>";
				this.content += "</div>";
			break;
			case 'cashback':
				this.content += "<div class='content'>";
				this.content += (this.netCopy.toUpperCase().indexOf("TOTAL SAVING") >= 0) ? "<p class='amountUpto' style=color:"+this.offernetPrice1_color+">" + this.netPrice + "</p>" : "<p class='amount' style=color:"+this.offernetPrice1_color+">" + this.netPrice + "</p>";
				this.content += "<p class='copy' style=color:"+this.offernetPricecopy_color+">" + this.netCopy + "</p>";
				this.content += "</div>";
			break;
			case 'lease':
				this.content += "<div class='content'>";
				this.content += "<p class='amount' style=color:"+this.leaseCost1_color+">" + this.leaseCost + "</p>";
				this.content += "<p style=color:"+this.leaseTerm1_color+">" + this.leaseTerm + "</p>";
				this.content += "<p class='copy' style=color:"+this.Lease_LeaseCash_OfferCopy_color+">" + this.leaseCopy + "</p>";
				this.content += "</div>";
			break;
			case 'leasecash':
				this.content += "<div class='content'>";
				this.content += "<p class='amount' style=color:"+this.leaseCost1_color+">" + this.leaseCost + "</p>";
				this.content += "<p style=color:"+this.leaseTerm1_color+">" + this.leaseTerm + "</p>";
				this.content += "<p class='copy' style=color:"+this.Lease_LeaseCash_OfferCopy_color+";border-color:"+this.line_divider_color+">" + this.leaseCopy + "</p>";
				this.content += "<div class='cashback'>";
				this.content += "<div style=color:"+this.cashbackOperator_static_color+">PLUS";
				this.content += (this.cashbackCopy.toUpperCase().indexOf("TOTAL SAVING") >= 0) ? "<br><span style=color:"+this.apr_up_to_copy+">Up To</span></div>" : "</div>";
				this.content += "<div class='amount' style=color:"+this.cashbackAmount_color+">" + this.cashbackAmount + "</div>";
				this.content += "<div class='copy' style=color:"+this.cashbackCopy1_color+">" + this.cashbackCopy + "</div>";
				this.content += "</div>";
				this.content += "</div>";
			break;
			case 'aprcashback':
				this.content += "<div class='content'>";
				this.content += "<div class='tr'>";
				this.content += "<div class='rate td' style=color:"+this.apr_1_color+">" + this.apr + "<div class='sup'>%</div></div>";
				this.content += "</div>";
				this.content += "<div class='tr'>";
				this.content += "<div class='td' style=color:"+this.cashbackAPRcopy1_color+">" + this.aprCopy;
				this.content += "<span style=color:"+this.aprtermcopy2_color+">" + this.aprTerm + "</span>";
				this.content += "</div>";
				this.content += "</div>";
				this.content += "<div class='tr' style=border-color:"+this.line_divider_color+">";
				this.content += "<div class='td' style=color:"+this.aprtermcopy1_color+">" + this.aprTerm2 + "</div>";
				this.content += "</div>";
				this.content += "<div class='cashback'>";
				this.content += "<div style=color:"+this.cashbackOperatorCopy1_color+">" + this.operatorCopy ;
				this.content += (this.cashbackCopy.toUpperCase().indexOf("TOTAL SAVING") >= 0) ? "<br><span style=color:"+this.apr_up_to_copy+">Up To</span></div>" : "</div>";
				this.content += "<div class='amount' style=color:"+this.cashbackAmount_color+">" + this.cashbackAmount + "</div>";
				this.content += "<div class='copy' style=color:"+this.cashbackCopy1_color+">" + this.cashbackCopy + "</div>";
				this.content += "</div>";
				this.content += "</div>";
			break;
			case 'msrp':
				this.content += "<div class='content'>";
				this.content += "<div class='copy' style=color:"+this.offerCopy_color+">" + this.headCopy + "</div>";
				this.content += "<div class='amount' style=color:"+this.offerMsrp1_color+">" + this.msrp + "</div>";
				this.content += "<div style=color:"+this.msrpCopy1_color+">" + this.msrpCopy + "</div>";
				this.content += "</div>";
			break;
			case 'mathstack':
				if(this.priceCount() > 1 && this.priceCount() < 4){
					var price1 = this.offerPrice[0].split("$");
					console.log(price1);
					this.content += "<div class='wrappeR'>"
					this.content += "<div class='content table' style=border-color:"+this.line_divider_color+">"
					for (var i = 0; i < this.priceCount(); i++) {
						this.content += "<div class='tr'>";
						this.content += "<div class='td amount' style=color:"+this.offerPriceColor[i]+">";
						this.content +=	(i > 0) ? "<span>+</span>":"";
						this.content += this.checkCurrency(this.offerPrice[i]);
						this.content += "</div>";
						this.content += "<div class='td copy' style=color:"+this.offerCopyColor[i]+"><span>" + this.offerCopy[i] + "</span></div>";
						this.content += "</div>";
					}
					this.content += "</div>";
					this.content += (this.netCopy.toUpperCase().indexOf("TOTAL SAVING") >= 0) ? "<div class='upto' style=color:"+this.apr_up_to_copy+">Up To</div>" : "";
					this.content += "<div class='net' style=color:"+this.offernetPrice1_color+">" + this.netPrice + "</div>";
					this.content += "<p class='copy' style=color:"+this.offernetPricecopy_color+">" + this.netCopy + "</p>";
					this.content += "</div>"
				}else{
					this.content += "<div class='contentCond'>";
					this.content += "<div class='amountCond' style=color:"+this.offernetPrice1_color+">";
					this.content += (this.netCopy.toUpperCase().indexOf("TOTAL SAVING") >= 0) ? "<div class='headCopy' style=color:"+this.apr_up_to_copy+">Up To</div>" : "";
					this.content += this.netPrice + "</div>"
					this.content += "<p class='copy' style=color:"+this.offernetPricecopy_color+">" + this.netCopy + "</p>";
					this.content += "</div>";
				}
			break;
			case 'negmathstack':
				if(this.priceCount() > 1 && this.priceCount() < 4){
					var price1 = this.offerPrice[1].split("$");
					this.content += "<div class='wrappeR'>"
					this.content += "<div class='content table' style=border-color:"+this.line_divider_color+">"
					for (var i = 0; i < this.priceCount(); i++) {
						this.content += "<div class='tr'>";
						this.content += "<div class='td amount' style=color:"+this.offerPriceColor[i]+">";
						this.content +=	(i > 0) ? "<span>-</span>":"";
						this.content += this.checkCurrency(this.offerPrice[i]);
						this.content += "</div>";
						this.content += "<div class='td copy' style=color:"+this.offerCopyColor[i]+"><span>" + this.negOfferCopy[i] + "</span></div>";
						this.content += "</div>";
					}
					this.content += "</div>";
					this.content += (this.netCopy.toUpperCase().indexOf("TOTAL SAVING") >= 0) ? "<div class='upto' style=color:"+this.apr_up_to_copy+">Up To</div>" : (this.headCopy.toUpperCase().indexOf("UP TO") >= 0) ? "" : "<div class='upto' style=color:"+this.offerCopy_color+">" + this.headCopy + "</div>";
					this.content += "<div class='net' style=color:"+this.offernetPrice1_color+">" + this.netPrice + "</div>";
					this.content += "<p class='copy' style=color:"+this.offernetPricecopy_color+">" + this.netCopy + "</p>";
					this.content += "</div>"
				}else{
					this.content += "<div class='contentCond'>";
					this.content += "<div class='amountCond' style=color:"+this.offernetPrice1_color+">";
					this.content += (this.netCopy.toUpperCase().indexOf("TOTAL SAVING") >= 0) ? "<div class='headCopy' style=color:"+this.apr_up_to_copy+">Up To</div>" : (this.headCopy.toUpperCase().indexOf("UP TO") >= 0) ? "" : "<div class='headCopy' style=color:"+this.offerCopy_color+">" + this.headCopy + "</div>";;
					this.content += this.netPrice + "</div>"
					this.content += "<p class='copy' style=color:"+this.offernetPricecopy_color+">" + this.netCopy + "</p>";
					this.content += "</div>";
				}
			break;
			case 'leasesignndrive':
				this.content += "<div class='content'>"
				this.content += "<div class='table'>";
				this.content += "<div class='tr'>";
				this.content += "<div class='td amount' style=color:"+this.leasesigndrive_0_static_color+"><sup>$</sup>0</div>";
				this.content += "<div class='td copy' style=color:"+this.leasesigndrive_text_static_color+"><span>Initial<br/>Payment<sup>[1]</sup></span></div>";
				this.content += "</div>";
				this.content += "<div class='tr'>";
				this.content += "<div class='td amount' style=color:"+this.leasesigndrive_0_static_color+"><sup>$</sup>0</div>";
				this.content += "<div class='td copy' style=color:"+this.leasesigndrive_text_static_color+"><span>Down<br/>Payment<sup>[2]</sup></span></div>";
				this.content += "</div>";
				this.content += "<div class='tr'>";
				this.content += "<div class='td amount' style=color:"+this.leasesigndrive_0_static_color+"><sup>$</sup>0</div>";
				this.content += "<div class='td copy' style=color:"+this.leasesigndrive_text_static_color+"><span>Security<br/>Deposit<sup>[3]</sup></span></div>";
				this.content += "</div>";
				this.content += "<div class='tr'>";
				this.content += "<div class='td amount' style=color:"+this.leasesigndrive_0_static_color+"><sup>$</sup>0</div>";
				this.content += "<div class='td copy' style=color:"+this.leasesigndrive_text_static_color+"><span>Drive-off<br/>Lease<sup>[4]</sup></span></div>";
				this.content += "</div>";
				this.content += "</div>";//add table
				this.content += "<p class='copy' style=color:"+this.leaseTerm2_color+">" + this.leaseTerm_snd + "</p>";
				this.content += "<p style=color:"+this.SignnDrive_leaseTerm_color+">" + this.snd_leaseTerm.toUpperCase() + "</p>";
				this.content += "</div>";
			break;
		    case 'leasesignndrivecashback':
			    this.content += "<div class='content'>"
			    this.content += "<div class='table'>";
			    this.content += "<div class='tr'>";
			    this.content += "<div class='td amount' style=color:"+this.leasesigndrive_0_static_color+"><sup>$</sup>0</div>";
			    this.content += "<div class='td copy' style=color:"+this.leasesigndrive_text_static_color+"><span>Initial<br/>Payment<sup>[1]</sup></span></div>";
			    this.content += "</div>";
			    this.content += "<div class='tr'>";
			    this.content += "<div class='td amount' style=color:"+this.leasesigndrive_0_static_color+"><sup>$</sup>0</div>";
			    this.content += "<div class='td copy' style=color:"+this.leasesigndrive_text_static_color+"><span>Down<br>Payment<sup>[2]</sup></span></div>";
			    this.content += "</div>";
			    this.content += "<div class='tr'>";
			    this.content += "<div class='td amount' style=color:"+this.leasesigndrive_0_static_color+"><sup>$</sup>0</div>";
			    this.content += "<div class='td copy' style=color:"+this.leasesigndrive_text_static_color+"><span>Security<br/>Deposit<sup>[3]</sup></span></div>";
			    this.content += "</div>";
			    this.content += "<div class='tr'>";
		     	this.content += "<div class='td amount' style=color:"+this.leasesigndrive_0_static_color+"><sup>$</sup>0</div>";
		    	this.content += "<div class='td copy' style=color:"+this.leasesigndrive_text_static_color+"><span>Drive-off<br/>Lease<sup>[4]</sup></span></div>";
			    this.content += "</div>";
			    this.content += "</div>";//add table
				this.content += "<p class='bonuscopy' style=color:"+ this.SignnDrive_leaseTerm_color +">+ "+ this.cashbackAmount +" "+" "+ this.cashbackCopy.toUpperCase() + "</p>";//dynamic content within the <p> tag should be "this.cashbackAmount + this.cashbackCopy"
			    this.content += "<p class='copy' style=color:"+this.leaseTerm2_color+">" + this.leaseTerm_snd + "</p>";
			    this.content += "<p style=color:"+this.SignnDrive_leaseTerm_color+">" + this.snd_leaseTerm.toUpperCase() + "</p>";
			    this.content += "</div>";
		    break;
		}
	};

	Offer.prototype.setContent = function() {
		switch(this.offer){
			case 'apr':
			break;
			case 'cashback':
               // document.styleSheets[0].addRule('.cashback p.amountUpto:before','color: '+this.apr_up_to_copy+';');
	       var style = (function() {
					// Create the <style> tag
					var style = document.createElement("style");
				    
					// WebKit hack
					style.appendChild(document.createTextNode(""));
				    
					// Add the <style> element to the page
					document.head.appendChild(style);
				      
					console.log(style.sheet.cssRules); // length is 0, and no rules
				    
					return style;
				})();
				    style.sheet.insertRule('.foo{color:red;}', 0);
				if(document.styleSheets[0].addRule){
					document.styleSheets[0].addRule('.cashback p.amountUpto:before','color: '+this.apr_up_to_copy+';');
				}else{
					style.sheet.insertRule('.cashback p.amountUpto:before {color: '+this.apr_up_to_copy+'}',0);
				}
			break;
			case 'lease':
				//add here
			break;
			case 'leasecash':
				this.alignCenter(".leasecash .cashback",".content");
			break;
			case 'aprcashback':
				this.alignCenter(".aprcashback .cashback",".content");
			break;
			case 'msrp':
				this.alignCenter(".msrp .amount",".content");
				$(".msrp .copy").style.marginLeft = $(".msrp .amount").offsetLeft + "px";
				$(".msrp .amount+div").style.marginLeft = ($(".msrp .amount").offsetWidth + $(".msrp .amount").offsetLeft) - $(".msrp .amount+div").offsetWidth + "px";
			break;
			case 'mathstack':
				if(this.priceCount() > 1 && this.priceCount() < 4){
					this.alignCenter(".mathstack .table.content",".wrappeR");
					this.alignCenter(".mathstack .net",".wrappeR");
					$(".mathstack .content+div").style.marginLeft = $(".mathstack .net").offsetLeft + "px";
				}
			break;
			case 'negmathstack':
				if(this.priceCount() > 1 && this.priceCount() < 4){
					this.alignCenter(".negmathstack .table.content",".wrappeR");
					this.alignCenter(".negmathstack .net",".wrappeR");
					$(".negmathstack .content+div").style.marginLeft = $(".negmathstack .net").offsetLeft + "px";
				}
			break;
			case 'leasesignndrive':
				this.alignCenter(".leasesignndrive .table",".content");
			break;
		    case 'leasesignndrivecashback':
				this.alignCenter( ".leasesignndrivecashback .table",".content" );
			break;
		}
		if(this.salesEventImg.length > 0 && this.salesEventImg.indexOf("Filler") < 0 && this.salesEventImg.indexOf("filler") < 0){
            if(this.salesEvent == "l4l"){
				if(this.offer == "lease" || this.offer == "leasecash") {
					$(".logo").innerHTML += "<div class='salesLogo'></div>";
					$(".salesLogo").style.backgroundImage = "url(" + dynamicContent.salesEvent[0].saleEventH5_300x250.Url + ")";
				}
			} else if (this.salesEvent == "minievent") {
				$(".logo").innerHTML += "<div class='salesLogo " + this.salesEvent + "'></div>";
				$(".salesLogo").style.backgroundImage = "url(" + dynamicContent.salesEvent[0].saleEventH5_300x250.Url + ")";
			} else if (this.salesEvent == "nosale") {
				//do nothing
			} else {
				//updated for the logo visibility revision 09/10/2015 - sam
				$(".logo").style.opacity = 0;
				$(".cta.cta1").classList.add("salesEvent");
				$(".cta.cta2").classList.add("salesEvent");
			}
        }
	    this.centerValignText(".cta.cta1 .ctaTxt");
		this.centerValignText(".cta.cta2 .ctaTxt");
		//this.setVideo();

        
	};

	Offer.prototype.centerValignText = function(target) {
		console.log(arguments);
		$(target).style.height = $(target).offsetHeight + "px";
	    $(target).style.top = 0;
	    $(target).style.bottom = 0;
	    $(target).style.marginTop = "auto";
	    $(target).style.marginBottom = "auto";
	};

	Offer.prototype.centerHAlignText = function(target) {
		console.log(arguments);
		$(target).style.width = $(target).offsetWidth + 3 + "px";
	    $(target).style.left = 0;
	    $(target).style.right = 0;
	    $(target).style.marginLeft = "auto";
	    $(target).style.marginRight = "auto";
	};

	Offer.prototype.alignCenter = function(target, centerTo) {
		console.log(arguments);
		$(target).style.marginLeft = ($(centerTo).offsetWidth - $(target).offsetWidth) / 2 + "px";
	};

	Offer.prototype.superScriptBracket = function(text) {
		console.log(arguments);
		text = text.split("[").join("<sup>[");
		text = text.split("]").join("]</sup>");
		return text;
	};

	Offer.prototype.superScriptText = function(text, sup){
		console.log(arguments);
		var word = text;
		return word.split(sup).join("<sup>" + sup + "</sup>");
	};

	Offer.prototype.addClick = function() {
		$(".container").addEventListener('click',function(e){
			console.log(arguments + " : " + e.target.getAttribute("class"));
			switch(e.target.getAttribute("class")){
				case 'cta cta1 salesEvent':
                	Enabler.exitOverride("brochure_exit", dynamicContent.dabAwarenessOffers[0].baseBrochureUrl.Url + customUrl);
				break;
				case 'cta cta2 salesEvent':
                	Enabler.exitOverride("build_exit", dynamicContent.dabAwarenessOffers[0].baseBuildUrl.Url + customUrl2);
				break;
				case 'cta cta1':
                	Enabler.exitOverride("brochure_exit", dynamicContent.dabAwarenessOffers[0].baseBrochureUrl.Url + customUrl);
				break;
				case 'cta cta2':
                	Enabler.exitOverride("build_exit", dynamicContent.dabAwarenessOffers[0].baseBuildUrl.Url + customUrl2);
				break;
				case 'disclaimerTxt':
					$(".disclaimerBox").style.display = "block";
				break;
				case 'closeBtn':
					$(".disclaimerBox").style.display = "none";
				break;
		 		default:
					$(".disclaimerBox").style.display = "none";
					Enabler.exitOverride("Main_Exit", dynamicContent.dabAwarenessOffers[0].baseLandingUrl.Url + customUrl);
				break;
			}
		},false);
	};

    //function adjustLogo
    // function getBrowser(){
    //     var type = "";
    //     if(navigator.userAgent.indexOf("Chrome") != -1 ) 
    //     {
    //         type = "chrome";
    //         alert('Chrome');
    //     }
    //     else if(navigator.userAgent.indexOf("Opera") != -1 )
    //     {
    //         type = "opera";
    //         // alert('Opera');
    //     }
    //     else if(navigator.userAgent.indexOf("Firefox") != -1 ) 
    //     {
    //         type = "firefox";
    //          // alert('Firefox');
    //     }
    //     else if((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) //IF IE > 10
    //     {
    //         type = "ie";
    //       // alert('IE'); 
    //     }  
    //     else 
    //     {
    //        // alert('unknown');
    //     }

    //     return type;
    // }

    // if ( navigator.userAgent.indexOf("Chrome") != -1 ) {
    //     $(".logo").style.left = "12px";
    //     //alert("-- logo -- " + document.getElementsByClassName('logo').style);
    // }
})();



