window.rtbsBidA = (typeof window.rtbsBidA  === 'object' ) ? window.rtbsBidA : {}; 
window.rtbsBidA["680791762"] = {bl:[{bidder_id: 23, ext_placement_code: "biz-desk", no_bid: true, logging_pixels: [], og_bid: 0.0, fb: true, publisher_id: "8CU2553YN", nbc: 0, at: "O", mnet_id: "680791762", size: "300x250"}]}
