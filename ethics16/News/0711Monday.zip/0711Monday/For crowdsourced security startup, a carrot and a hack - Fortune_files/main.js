//IIFE TO EXTRACT DIMENSION DATA
var dimensions = (function(){
        var str = document.querySelectorAll("[name='ad.size']")[0].getAttributeNode("content").value;
        var widthMatch = /width\=(\d+)/.exec(str);
        var heightMatch = /height\=(\d+)/.exec(str);
        return {
            width: parseInt(widthMatch[1]),
            height: parseInt(heightMatch[1])
        }
})();

var tl;
var stopWatch;
var numberOfDiffCels=7;
var initialCels=6;
var addCelSpeed=600;
var celAddFlag=true;
var celTimer;

//INITIALIZE
function init(){
    IDsToVars();

    container.style.width = dimensions.width + 'px';
    container.style.height = dimensions.height + 'px';
    
    bCell_Holder.style.width = dimensions.width + 'px';
    bCell_Holder.style.height = dimensions.height + 'px';

    //set timeline
    tl = new TimelineLite();

    addListeners();

    animate();
}

//ANIMATE
function animate(){
    stopWatch=new Date().getTime(); 

    for (var q=1; q<=initialCels; q++){
        addSingleBCel(true);
    }

    addBCells();

    TweenLite.delayedCall(15, stopCels);

    //timeline animation here
    tl.set([container, mainBG, square_logo, mainHolder, bCell_Holder], {transformStyle:"flat"})
    .set(square_logo, {transformPerspective: 300, rotationX:40, rotationY:-30, rotationZ:-5})
    .add("copyTime", "+=2")
    .from(copy_HelpingHealthcare, .5, {alpha:0}, "copyTime")
    .to(copy_AcceleratingCures_White, .3, {alpha:0}, "copyTime")
    .from(copy_AcceleratingCures_Grey, .3, {alpha:0}, "copyTime")
    .from(square_logo, 4, {y:-(120)}, "copyTime")
    .add(function(){square_logo.style.zIndex="10000";}, "copyTime+=3.5")
    .to(square_logo, 1, {rotationX:0, rotationY:0, rotationZ:0}, "copyTime+=3.5")
    .add("finalFrame", "-=1")
    .to(copy_HelpingHealthcare, .3, {alpha:0}, "finalFrame")
    .from(copy_95, .5, {alpha:0}, "finalFrame+=.3")
    .from([CTA,legal_btn], .5, {alpha:0}, "finalFrame+=1")
    .from(copy_AcceleratingNext, .5, {alpha:0}, "finalFrame+=1.5")
    //.call(returnTimer)
}

function addBCells(){
    celTimer=setInterval( function(){addSingleBCel(false);}, addCelSpeed);
}

function addSingleBCel(initialFlag){
    var tempCel=document.createElement('div');
    var randCel=Math.ceil(Math.random()*numberOfDiffCels);
    tempCel.className="bCell"+randCel;
    tempCel.className+=" sprite";

    bCell_Holder.appendChild(tempCel);

    TweenLite.set(tempCel, {transformPerspective: 300, transformStyle:"flat"});

    var startX=(Math.random()*dimensions.width)-40;
    
    var startY;
    if (initialFlag){
        startY=Math.random()*dimensions.height-40;
    } else {
        startY=-tempCel.offsetHeight-40;
    }
    
    var startRot=Math.random()*360;
    var endRot=Math.random()*360;
    var randSpeed=(Math.random()*6)+3;

    TweenLite.set(tempCel, {x:startX, y:startY});
    TweenLite.to(tempCel, randSpeed, {y:dimensions.height, ease:Power0.easeNone, onComplete:removeCel, onCompleteParams:[tempCel]});
    randomDimensions(tempCel);
}

function stopCels(){
    clearInterval(celTimer);

    var childDivs = bCell_Holder.getElementsByTagName('div');

    for( i=0; i<childDivs.length; i++ ){
        var childDiv = childDivs[i];
        TweenLite.killTweensOf( childDiv );
    }
}

function removeCel(whichOne){
    whichOne.parentNode.removeChild(whichOne);
}

function returnTimer(){
    stopWatch=((new Date().getTime())-stopWatch)*.001;
    console.log(stopWatch+" seconds");
}

function randomDimensions(whichOne){
    var tempX=(Math.random()*80)-40;
    var tempY=(Math.random()*80)-40;
    var tempZ=(Math.random()*160)-80;
    var tempSpeed=(Math.random()*2)+1
    TweenLite.to(whichOne, tempSpeed, {ease:Power1.easeInOut, rotationX:tempX, rotationY:tempY, rotationZ:tempZ, overwrite:false, onComplete:randomDimensions, onCompleteParams:[whichOne]});
}

function addListeners(){

    CTA.addEventListener('mouseover',function(){
        CTABG.style.backgroundColor="#ff8d6d";
    })

    CTA.addEventListener('mouseout', function(){
        CTABG.removeAttribute("style");
    })


    legal_btn.addEventListener('click',function(){
        legal_container.style.display = "block";
        TweenLite.to(legal_container,.5,{opacity:1})
    })
    legal_close.addEventListener('click',function(){
        TweenLite.to(legal_container,.5,{opacity:0});
        legal_container.style.display = "none";
    })
}

function clickThrough(){
    window.open(clicktag);
}

//SET IDs IN DOM TO GLOBAL VARIABLES
function IDsToVars(){
    var allElements = document.getElementsByTagName("*");
    
    for (var q = 0; q<allElements.length; q++){
         var el = allElements[q];
         if (el.id){
            window[el.id]=document.getElementById(el.id);
        }
    }
};