/**
 * Edited by Frederic.Gurnot on 11/16/15.
 */
// Growl Meter Count, Login Detect, & Expander
// ~matt.milligan 20150417
//New version includes ability to track clicks in ADX

(function (global) {
    "use strict";

    var $, Meter;

    // -----------------------------------------
    // ------      Select NYT4/NYT5       ------

    function isFoundation() {
        // foundation/main is used for modern browsers;
        // foundation/legacy_main is used for old browsers.
        // So at least one is always on the page
        return document.querySelectorAll('[data-main="foundation/main"],[data-main="foundation/legacy_main"]').length > 0;
    }

    function run($, Meter) {
        var meterCount = Meter.pageCount;

        var addCampaignId = function(selector, cid) {
            var href = $(selector).attr('href');
            href = href.replace('campaignId%3D', 'campaignId%3D' + cid);
            $(selector).attr('href', href);
        };

        setTimeout(function () {
            $("#growl-container").addClass("show-growl");
        }, 1000);

        // Update meter message
        var textMapping = {
            "2": 'You have read <span class="bold">2 of 10 free articles</span> this month.',
            "5": 'You have read <span class="bold">5 of 10 free articles</span> this month.',
            "9": 'You have read <span class="bold">9 of 10 free articles</span> this month.',
            "10": 'This is your <span class="bold">last free article</span> this month.'
        };

        //Display article count and unhide CTA
        $('.growl_art').replaceWith(textMapping[meterCount]);
        var campaignId = $('#growl-container').attr("data-campaign-id-m"+meterCount);
        addCampaignId('#growl-cta',  campaignId);
        addCampaignId('#growl-cta-btn', campaignId);

        if (meterCount === 2) {
            $("#growl-container").addClass('meter-2');
            $('#growl-cta').addClass('registration-modal-trigger');
        }
        if (meterCount === 5) {
            $("#growl-container").addClass('meter-5');
        }

        if (meterCount > 8) {
            $("#growl-container").addClass('meter-9-10');
            //$(".nytdGrowlUIContainer").trigger("growl.expandable");

            $("#growl-container").addClass('expanded').removeClass('collapsed');

            var growltimer;

            growltimer = setTimeout(function () {
                $("#growl-container").addClass('collapsed').removeClass('expanded');
            }, 3000);

            $(".growl__content").on("mouseenter", function () {
                clearTimeout(growltimer);
                $("#growl-container").addClass('expanded').removeClass('collapsed');
            });

            $("#growl-container").on("mouseleave", function () {
                $("#growl-container").addClass('collapsed').removeClass('expanded');
            });

        }

    }

    if (isFoundation()) {
        require(['foundation/main'], function () {
            $ = require('jquery/nyt');
            Meter = require('auth/mtr');
            run($, Meter);
        });
    } else {
        $ = window.NYTD && window.NYTD.jQuery || window.jQuery;
        Meter = NYTD.Meter || {};
        run($, Meter);
    }




})(window);