// Detect login or logout - NYT4 and NYT5


(function (global) {
    "use strict";

    var $;

    // -----------------------------------------
    // ------      Select NYT4/NYT5       ------

    function isNyt5() {
            var nyt5meta = document.getElementsByName('sourceApp');
            var nytApps = {'nyt-v5': true , 'blogs': true};
            return (typeof nyt5meta[0] !== "undefined") && (nyt5meta[0].getAttribute('content') in nytApps) ;
        }

    if (isNyt5()) {
        require(['foundation/main'], function () {
            $ = require('jquery/nyt');
            run($);
        });
    } else {
        $ = window.NYTD && window.NYTD.jQuery || window.jQuery;
        run($);
        
    }

    


    // -----------------------------------------
    // ------      retrieve user id     ------

    function run($) {
        var userinfoAPI = "http://www.nytimes.com/svc/web-products/userinfo.json";
        $.getJSON( userinfoAPI, function(data) {
            // console.log( "user id: " + data.data.id );
            if (data.data.id === '0') {
                // if user is logged out
                // show the login button
                $('#growl-login').removeClass("hide_login"); 
                $('#growl-container').css("bottom","0px");             
            } 
        })
        
    }

})(window); 