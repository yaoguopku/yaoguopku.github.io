/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
            'Cabin, Arial, sans-serif': '<link href=\'https://fonts.googleapis.com/css?family=Cabin:400,500,600,700\' rel=\'stylesheet\' type=\'text/css\'>'        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
            "stage": {
                version: "5.0.1",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.1.386",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'icims-st-lures-728x90-R7-i1',
                            type: 'image',
                            rect: ['0px', '0', '728px', '90px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"icims-st-lures-728x90-R7-i1.jpg",'0px','0px']
                        },
                        {
                            id: 'icims-st-lures-728x90-R7-i2',
                            type: 'image',
                            rect: ['-1207px', '0', '728px', '90px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"icims-st-lures-728x90-R7-i2.jpg",'0px','0px']
                        },
                        {
                            id: 'icims-st-lures-728x90-R7-i22',
                            display: 'none',
                            type: 'image',
                            rect: ['-885px', '0', '728px', '90px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"icims-st-lures-728x90-R7-i2.jpg",'0px','0px']
                        },
                        {
                            id: 'icims-st-lures-728x90-R7-i23',
                            display: 'none',
                            type: 'image',
                            rect: ['546px', '0', '728px', '90px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"icims-st-lures-728x90-R7-i2.jpg",'0px','0px']
                        },
                        {
                            id: 'icims-st-lures-728x90-R7-i24',
                            display: 'none',
                            type: 'image',
                            rect: ['127px', '0', '728px', '90px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"icims-st-lures-728x90-R7-i2.jpg",'0px','0px']
                        },
                        {
                            id: 'AGOOD-RedField1',
                            type: 'rect',
                            rect: ['128px', '100px', '578px', '121px', 'auto', 'auto'],
                            opacity: '1',
                            fill: ["rgba(205,5,5,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"],
                            userClass: "field"
                        },
                        {
                            id: 'AGOOD',
                            type: 'text',
                            rect: ['153px', '117px', '366px', '64px', 'auto', 'auto'],
                            opacity: '1',
                            text: "A GOOD CATCH REQUIRES<br>A SOPHISTICATED APPROACH",
                            align: "left",
                            font: ['Cabin, Arial, sans-serif', [26, "px"], "rgba(255,255,255,1.00)", "700", "none solid rgb(205, 5, 5)", "normal", "break-word", "normal"],
                            textStyle: ["", "", "29px", ""]
                        },
                        {
                            id: 'THEMOST-RedField2',
                            type: 'rect',
                            rect: ['128px', '100px', '578px', '121px', 'auto', 'auto'],
                            fill: ["rgba(205,5,5,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"],
                            userClass: "field"
                        },
                        {
                            id: 'THEMOST',
                            type: 'text',
                            rect: ['149px', '121px', '239px', '57px', 'auto', 'auto'],
                            text: "THE MOST SOPHISTICATED<br>TALENT ACQUISITION SOFTWARE<br>AVAILABLE TODAY",
                            align: "left",
                            font: ['Cabin, Arial, sans-serif', [15, "px"], "rgba(255,255,255,1)", "700", "none solid rgb(255, 255, 255)", "normal", "break-word", "normal"],
                            textStyle: ["", "", "16px", ""]
                        },
                        {
                            id: 'Logo',
                            type: 'image',
                            rect: ['428px', '103px', '96px', '64px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"Logo.png",'0px','0px']
                        },
                        {
                            id: 'Button',
                            symbolName: 'Button',
                            display: 'none',
                            type: 'rect',
                            rect: ['554px', '109px', '133', '29', 'auto', 'auto'],
                            opacity: '1'
                        },
                        {
                            id: 'Button-png',
                            symbolName: 'Button-png',
                            type: 'rect',
                            rect: ['549px', '103px', '144', '43', 'auto', 'auto'],
                            transform: [[],[],[],['1.01','1.01']]
                        },
                        {
                            id: 'Border',
                            symbolName: 'Border',
                            type: 'rect',
                            rect: ['0', '0', '728', '90', 'auto', 'auto']
                        },
                        {
                            id: 'HotSpot',
                            type: 'rect',
                            rect: ['0px', '0px', '728px', '90px', 'auto', 'auto'],
                            fill: ["rgba(192,192,192,0.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '728px', '90px', 'auto', 'auto'],
                            overflow: 'hidden',
                            fill: ["rgba(255,255,255,1)"]
                        }
                    }
                },
                timeline: {
                    duration: 13000,
                    autoPlay: true,
                    data: [
                        [
                            "eid80",
                            "display",
                            0,
                            0,
                            "linear",
                            "${icims-st-lures-728x90-R7-i22}",
                            'none',
                            'none'
                        ],
                        [
                            "eid81",
                            "display",
                            5000,
                            0,
                            "linear",
                            "${icims-st-lures-728x90-R7-i22}",
                            'none',
                            'block'
                        ],
                        [
                            "eid109",
                            "display",
                            0,
                            0,
                            "easeOutQuint",
                            "${Button}",
                            'none',
                            'none'
                        ],
                        [
                            "eid76",
                            "left",
                            5000,
                            4000,
                            "linear",
                            "${icims-st-lures-728x90-R7-i22}",
                            '595px',
                            '-145px'
                        ],
                        [
                            "eid77",
                            "left",
                            9000,
                            4000,
                            "linear",
                            "${icims-st-lures-728x90-R7-i22}",
                            '-145px',
                            '-885px'
                        ],
                        [
                            "eid82",
                            "display",
                            0,
                            0,
                            "linear",
                            "${icims-st-lures-728x90-R7-i23}",
                            'none',
                            'none'
                        ],
                        [
                            "eid83",
                            "display",
                            8000,
                            0,
                            "linear",
                            "${icims-st-lures-728x90-R7-i23}",
                            'none',
                            'block'
                        ],
                        [
                            "eid41",
                            "top",
                            6000,
                            500,
                            "easeInQuart",
                            "${THEMOST-RedField2}",
                            '100px',
                            '-10px'
                        ],
                        [
                            "eid35",
                            "top",
                            6500,
                            1000,
                            "easeOutQuint",
                            "${THEMOST-RedField2}",
                            '-10px',
                            '0px'
                        ],
                        [
                            "eid63",
                            "top",
                            6000,
                            500,
                            "easeInQuart",
                            "${THEMOST}",
                            '121px',
                            '11px'
                        ],
                        [
                            "eid62",
                            "top",
                            6500,
                            1000,
                            "easeOutQuint",
                            "${THEMOST}",
                            '11px',
                            '21px'
                        ],
                        [
                            "eid59",
                            "opacity",
                            5000,
                            500,
                            "easeOutQuint",
                            "${AGOOD}",
                            '1',
                            '0'
                        ],
                        [
                            "eid108",
                            "top",
                            9000,
                            500,
                            "easeInQuart",
                            "${Button-png}",
                            '103px',
                            '23px'
                        ],
                        [
                            "eid107",
                            "top",
                            9500,
                            1000,
                            "easeOutQuint",
                            "${Button-png}",
                            '23px',
                            '33px'
                        ],
                        [
                            "eid91",
                            "left",
                            11000,
                            2000,
                            "linear",
                            "${icims-st-lures-728x90-R7-i24}",
                            '497px',
                            '126px'
                        ],
                        [
                            "eid89",
                            "left",
                            8000,
                            1000,
                            "linear",
                            "${icims-st-lures-728x90-R7-i23}",
                            '546px',
                            '361px'
                        ],
                        [
                            "eid79",
                            "left",
                            9000,
                            4000,
                            "linear",
                            "${icims-st-lures-728x90-R7-i23}",
                            '361px',
                            '-379px'
                        ],
                        [
                            "eid57",
                            "top",
                            2000,
                            500,
                            "easeInQuart",
                            "${AGOOD}",
                            '117px',
                            '7px'
                        ],
                        [
                            "eid56",
                            "top",
                            2500,
                            1000,
                            "easeOutQuint",
                            "${AGOOD}",
                            '7px',
                            '17px'
                        ],
                        [
                            "eid27",
                            "top",
                            2000,
                            500,
                            "easeInQuart",
                            "${AGOOD-RedField1}",
                            '100px',
                            '-10px'
                        ],
                        [
                            "eid26",
                            "top",
                            2500,
                            1000,
                            "easeOutQuint",
                            "${AGOOD-RedField1}",
                            '-10px',
                            '0px'
                        ],
                        [
                            "eid45",
                            "top",
                            8000,
                            500,
                            "easeInQuart",
                            "${Logo}",
                            '103px',
                            '3px'
                        ],
                        [
                            "eid44",
                            "top",
                            8500,
                            1000,
                            "easeOutQuint",
                            "${Logo}",
                            '3px',
                            '13px'
                        ],
                        [
                            "eid48",
                            "top",
                            9000,
                            500,
                            "easeInQuart",
                            "${Button}",
                            '109px',
                            '29px'
                        ],
                        [
                            "eid47",
                            "top",
                            9500,
                            1000,
                            "easeOutQuint",
                            "${Button}",
                            '29px',
                            '39px'
                        ],
                        [
                            "eid73",
                            "left",
                            0,
                            4000,
                            "linear",
                            "${icims-st-lures-728x90-R7-i2}",
                            '1013px',
                            '273px'
                        ],
                        [
                            "eid74",
                            "left",
                            4000,
                            4000,
                            "linear",
                            "${icims-st-lures-728x90-R7-i2}",
                            '273px',
                            '-467px'
                        ],
                        [
                            "eid84",
                            "left",
                            8000,
                            4000,
                            "linear",
                            "${icims-st-lures-728x90-R7-i2}",
                            '-467px',
                            '-1207px'
                        ],
                        [
                            "eid31",
                            "opacity",
                            5000,
                            500,
                            "easeOutQuint",
                            "${AGOOD-RedField1}",
                            '1',
                            '0'
                        ],
                        [
                            "eid92",
                            "display",
                            0,
                            0,
                            "linear",
                            "${icims-st-lures-728x90-R7-i24}",
                            'none',
                            'none'
                        ],
                        [
                            "eid93",
                            "display",
                            11000,
                            0,
                            "linear",
                            "${icims-st-lures-728x90-R7-i24}",
                            'none',
                            'block'
                        ],
                        [
                            "eid70",
                            "left",
                            0,
                            4000,
                            "linear",
                            "${icims-st-lures-728x90-R7-i1}",
                            '740px',
                            '0px'
                        ],
                        [
                            "eid71",
                            "left",
                            4000,
                            4000,
                            "linear",
                            "${icims-st-lures-728x90-R7-i1}",
                            '0px',
                            '-740px'
                        ]
                    ]
                }
            },
            "Button": {
                version: "5.0.1",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.1.386",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            type: 'rect',
                            rect: ['0px', '0px', '133px', '29px', 'auto', 'auto'],
                            id: 'Field1',
                            stroke: [0, 'rgb(0, 0, 0)', 'none'],
                            display: 'block',
                            fill: ['rgba(255,255,255,1)']
                        },
                        {
                            type: 'text',
                            rect: ['9px', '3px', '133px', '29px', 'auto', 'auto'],
                            id: 'LMR',
                            text: 'LEARN MORE',
                            display: 'block',
                            font: ['Cabin, Arial, sans-serif', [19, 'px'], 'rgba(205,5,5,1.00)', '700', 'none', '', 'break-word', 'normal']
                        },
                        {
                            type: 'rect',
                            rect: ['-1px', '-1px', '133px', '29px', 'auto', 'auto'],
                            id: 'Field2',
                            stroke: [1, 'rgba(255,255,255,1.00)', 'solid'],
                            display: 'none',
                            fill: ['rgba(205,5,5,1.00)']
                        },
                        {
                            type: 'text',
                            rect: ['9px', '3px', '133px', '29px', 'auto', 'auto'],
                            id: 'LMW',
                            text: 'LEARN MORE',
                            display: 'none',
                            font: ['Cabin, Arial, sans-serif', [19, 'px'], 'rgba(255,255,255,1.00)', '700', 'none', '', 'break-word', 'normal']
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            rect: [null, null, '133px', '29px']
                        }
                    }
                },
                timeline: {
                    duration: 1000,
                    autoPlay: true,
                    data: [
                        [
                            "eid176",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Field2}",
                            'none',
                            'none'
                        ],
                        [
                            "eid179",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${Field2}",
                            'none',
                            'block'
                        ],
                        [
                            "eid14",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Field1}",
                            'block',
                            'block'
                        ],
                        [
                            "eid15",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${Field1}",
                            'block',
                            'none'
                        ],
                        [
                            "eid54",
                            "display",
                            0,
                            0,
                            "linear",
                            "${LMR}",
                            'block',
                            'block'
                        ],
                        [
                            "eid53",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${LMR}",
                            'block',
                            'none'
                        ],
                        [
                            "eid51",
                            "display",
                            0,
                            0,
                            "linear",
                            "${LMW}",
                            'none',
                            'none'
                        ],
                        [
                            "eid52",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${LMW}",
                            'none',
                            'block'
                        ]
                    ]
                }
            },
            "Border": {
                version: "5.0.1",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.1.386",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            rect: ['0px', '0px', '728px', '90px', 'auto', 'auto'],
                            id: 'BorderGray-728x90',
                            type: 'image',
                            display: 'block',
                            fill: ['rgba(0,0,0,0)', 'images/BorderGray-728x90.png', '0px', '0px']
                        },
                        {
                            rect: ['0px', '0px', '728px', '90px', 'auto', 'auto'],
                            id: 'BorderRed-728x90',
                            type: 'image',
                            display: 'none',
                            fill: ['rgba(0,0,0,0)', 'images/BorderRed-728x90.png', '0px', '0px']
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            rect: [null, null, '728px', '90px']
                        }
                    }
                },
                timeline: {
                    duration: 1000,
                    autoPlay: true,
                    data: [
                        [
                            "eid7",
                            "display",
                            0,
                            0,
                            "linear",
                            "${BorderRed-728x90}",
                            'none',
                            'none'
                        ],
                        [
                            "eid8",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${BorderRed-728x90}",
                            'none',
                            'none'
                        ],
                        [
                            "eid6",
                            "display",
                            0,
                            0,
                            "linear",
                            "${BorderGray-728x90}",
                            'block',
                            'block'
                        ],
                        [
                            "eid9",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${BorderGray-728x90}",
                            'block',
                            'block'
                        ]
                    ]
                }
            },
            "Button-png": {
                version: "5.0.1",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.1.386",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            type: 'image',
                            display: 'block',
                            rect: ['0px', '0px', '144px', '43px', 'auto', 'auto'],
                            id: 'Button-1',
                            fill: ['rgba(0,0,0,0)', 'images/Button-1.png', '0px', '0px']
                        },
                        {
                            type: 'image',
                            display: 'none',
                            rect: ['0px', '0px', '144px', '43px', 'auto', 'auto'],
                            id: 'Button-2',
                            fill: ['rgba(0,0,0,0)', 'images/Button-2.png', '0px', '0px']
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            rect: [null, null, '144px', '43px']
                        }
                    }
                },
                timeline: {
                    duration: 1000,
                    autoPlay: true,
                    data: [
                        [
                            "eid467",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Button-2}",
                            'none',
                            'none'
                        ],
                        [
                            "eid468",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${Button-2}",
                            'none',
                            'block'
                        ],
                        [
                            "eid465",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Button-1}",
                            'block',
                            'block'
                        ],
                        [
                            "eid464",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${Button-1}",
                            'block',
                            'none'
                        ]
                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("iCIMS-st-Lures-728x90_edgeActions.js");
})("EDGE-21124494");
