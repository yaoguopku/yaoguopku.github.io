/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
            'Cabin, Arial, sans-serif': '<link href=\'https://fonts.googleapis.com/css?family=Cabin:400,500,600,700\' rel=\'stylesheet\' type=\'text/css\'>'        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
            "stage": {
                version: "5.0.1",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.1.386",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'Hammer',
                            display: 'block',
                            type: 'image',
                            rect: ['0', '0', '300px', '250px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"icims-st-hardtools-300x250-R7-i1.jpg",'0px','0px']
                        },
                        {
                            id: 'Snips',
                            display: 'none',
                            type: 'image',
                            rect: ['0', '0', '300px', '250px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"icims-st-hardtools-300x250-R7-i2.jpg",'0px','0px']
                        },
                        {
                            id: 'AllenWrenches',
                            display: 'none',
                            type: 'image',
                            rect: ['0', '0', '300px', '250px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"icims-st-hardtools-300x250-R7-i3.jpg",'0px','0px']
                        },
                        {
                            id: 'Wrench',
                            display: 'none',
                            type: 'image',
                            rect: ['0', '0', '300px', '250px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"icims-st-hardtools-300x250-R7-i4.jpg",'0px','0px']
                        },
                        {
                            id: 'SmallScrewdriver',
                            display: 'none',
                            type: 'image',
                            rect: ['7px', '0', '300px', '250px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"icims-st-hardtools-300x250-R7-i5.jpg",'0px','0px'],
                            transform: [[],[],[],['1.14999','1.14999']]
                        },
                        {
                            id: 'LockPliers',
                            display: 'none',
                            type: 'image',
                            rect: ['-6px', '-165px', '314px', '607px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"LockPliers.jpg",'0px','0px'],
                            transform: [[],[],[],['0.62','0.62']]
                        },
                        {
                            id: 'AdjustableWrench',
                            display: 'none',
                            type: 'image',
                            rect: ['-6px', '-148px', '314px', '607px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"AdjustableWrench.jpg",'0px','0px'],
                            transform: [[],[],[],['0.62','0.62']]
                        },
                        {
                            id: 'TapeMeasure',
                            display: 'none',
                            type: 'image',
                            rect: ['-6px', '-212px', '314px', '607px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"TapeMeasure.jpg",'0px','0px'],
                            transform: [[],[],[],['0.62','0.62']]
                        },
                        {
                            id: 'NeedleNosePliers',
                            display: 'none',
                            type: 'image',
                            rect: ['-9px', '-178px', '314px', '607px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"NeedleNosePliers.jpg",'0px','0px'],
                            transform: [[],[],[],['0.6','0.6']]
                        },
                        {
                            id: 'BG',
                            display: 'none',
                            type: 'image',
                            rect: ['-88px', '69px', '300px', '250px', 'auto', 'auto'],
                            opacity: '1',
                            fill: ["rgba(0,0,0,0)",im+"icims-st-hardtools-300x250-R7-i7.jpg",'0px','0px'],
                            transform: [[],[],[],['1.55','1.55']]
                        },
                        {
                            id: 'Level',
                            display: 'none',
                            type: 'image',
                            rect: ['46px', '-189px', '314px', '607px', 'auto', 'auto'],
                            opacity: '1',
                            fill: ["rgba(0,0,0,0)",im+"Level.jpg",'0px','0px'],
                            transform: [[],[],[],['0.4','0.4']]
                        },
                        {
                            id: 'ITMEET-FieldRed',
                            type: 'rect',
                            rect: ['310px', '40px', '330px', '171px', 'auto', 'auto'],
                            opacity: '1',
                            fill: ["rgba(205,5,5,1.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"],
                            userClass: "field"
                        },
                        {
                            id: 'ITMEET-1',
                            type: 'text',
                            rect: ['332px', '55px', '350px', '171px', 'auto', 'auto'],
                            opacity: '1',
                            text: "IT TAKES THE<br>RIGHT TOOLS TO<br>",
                            align: "left",
                            font: ['Cabin, Arial, sans-serif', [25, "px"], "rgba(255,255,255,1)", "700", "none solid rgb(255, 255, 255)", "normal", "break-word", "normal"],
                            textStyle: ["", "", "28px", ""]
                        },
                        {
                            id: 'ITMEET-2',
                            type: 'text',
                            rect: ['332px', '112px', '350px', '171px', 'auto', 'auto'],
                            opacity: '1',
                            text: "MEET THE COMPLEX<br>DEMANDS OF TALENT<br>ACQUISITION",
                            align: "left",
                            font: ['Cabin, Arial, sans-serif', [25, "px"], "rgba(255,255,255,1)", "700", "none solid rgb(255, 255, 255)", "normal", "break-word", "normal"],
                            textStyle: ["", "", "28px", ""]
                        },
                        {
                            id: 'THEMOST-FieldRed',
                            type: 'rect',
                            rect: ['310px', '40px', '330px', '171px', 'auto', 'auto'],
                            fill: ["rgba(205,5,5,1.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"],
                            userClass: "field"
                        },
                        {
                            id: 'THEMOST',
                            type: 'text',
                            rect: ['333px', '58px', '263px', '64px', 'auto', 'auto'],
                            text: "THE MOST SOPHISTICATED<br>TALENT ACQUISITION SOFTWARE<br>AVAILABLE TODAY",
                            align: "left",
                            font: ['Cabin, Arial, sans-serif', [16, "px"], "rgba(255,255,255,1)", "700", "none solid rgb(255, 255, 255)", "normal", "break-word", "normal"],
                            textStyle: ["", "", "16px", ""]
                        },
                        {
                            id: 'Logo',
                            type: 'image',
                            rect: ['21px', '119px', '96px', '64px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"Logo.png",'0px','0px']
                        },
                        {
                            id: 'Button-png',
                            symbolName: 'Button-png',
                            type: 'rect',
                            rect: ['309px', '140px', '144', '43', 'auto', 'auto']
                        },
                        {
                            id: 'Button',
                            symbolName: 'Button',
                            display: 'none',
                            type: 'rect',
                            rect: ['143px', '144px', '133', '29', 'auto', 'auto'],
                            opacity: '1'
                        },
                        {
                            id: 'Border',
                            symbolName: 'Border',
                            type: 'rect',
                            rect: ['0', '0', '300', '250', 'auto', 'auto']
                        },
                        {
                            id: 'HotSpot',
                            type: 'rect',
                            rect: ['1px', '0px', '300px', '250px', 'auto', 'auto'],
                            cursor: 'pointer',
                            fill: ["rgba(192,192,192,0.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '300px', '250px', 'auto', 'auto'],
                            overflow: 'hidden',
                            fill: ["rgba(255,255,255,1)"]
                        }
                    }
                },
                timeline: {
                    duration: 11500,
                    autoPlay: true,
                    data: [
                        [
                            "eid150",
                            "left",
                            9000,
                            500,
                            "easeInQuart",
                            "${Logo}",
                            '304px',
                            '16px'
                        ],
                        [
                            "eid149",
                            "left",
                            9500,
                            1000,
                            "easeOutQuint",
                            "${Logo}",
                            '16px',
                            '21px'
                        ],
                        [
                            "eid382",
                            "left",
                            7000,
                            500,
                            "easeInQuart",
                            "${THEMOST}",
                            '333px',
                            '13px'
                        ],
                        [
                            "eid381",
                            "left",
                            7500,
                            1000,
                            "easeOutQuint",
                            "${THEMOST}",
                            '13px',
                            '23px'
                        ],
                        [
                            "eid376",
                            "left",
                            2000,
                            500,
                            "easeInQuart",
                            "${ITMEET-1}",
                            '332px',
                            '12px'
                        ],
                        [
                            "eid375",
                            "left",
                            2500,
                            1000,
                            "easeOutQuint",
                            "${ITMEET-1}",
                            '12px',
                            '22px'
                        ],
                        [
                            "eid401",
                            "display",
                            0,
                            0,
                            "linear",
                            "${BG}",
                            'none',
                            'none'
                        ],
                        [
                            "eid414",
                            "display",
                            6400,
                            0,
                            "linear",
                            "${BG}",
                            'none',
                            'block'
                        ],
                        [
                            "eid432",
                            "scaleY",
                            6400,
                            500,
                            "linear",
                            "${BG}",
                            '1.55',
                            '1'
                        ],
                        [
                            "eid399",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Wrench}",
                            'none',
                            'none'
                        ],
                        [
                            "eid408",
                            "display",
                            1800,
                            0,
                            "linear",
                            "${Wrench}",
                            'none',
                            'block'
                        ],
                        [
                            "eid409",
                            "display",
                            2400,
                            0,
                            "linear",
                            "${Wrench}",
                            'block',
                            'none'
                        ],
                        [
                            "eid446",
                            "left",
                            6400,
                            500,
                            "linear",
                            "${Level}",
                            '-8px',
                            '46px'
                        ],
                        [
                            "eid159",
                            "left",
                            9000,
                            500,
                            "easeInQuart",
                            "${Button}",
                            '311px',
                            '138px'
                        ],
                        [
                            "eid158",
                            "left",
                            9500,
                            1000,
                            "easeOutQuint",
                            "${Button}",
                            '138px',
                            '143px'
                        ],
                        [
                            "eid477",
                            "left",
                            10000,
                            500,
                            "easeInQuart",
                            "${Button-png}",
                            '309px',
                            '136px'
                        ],
                        [
                            "eid478",
                            "left",
                            10500,
                            1000,
                            "easeOutQuint",
                            "${Button-png}",
                            '136px',
                            '141px'
                        ],
                        [
                            "eid433",
                            "left",
                            6400,
                            500,
                            "linear",
                            "${BG}",
                            '-88px',
                            '0px'
                        ],
                        [
                            "eid434",
                            "top",
                            6400,
                            500,
                            "linear",
                            "${BG}",
                            '69px',
                            '0px'
                        ],
                        [
                            "eid378",
                            "opacity",
                            6000,
                            500,
                            "easeOutQuint",
                            "${ITMEET-1}",
                            '1',
                            '0'
                        ],
                        [
                            "eid348",
                            "left",
                            2000,
                            500,
                            "easeInQuart",
                            "${ITMEET-FieldRed}",
                            '310px',
                            '-10px'
                        ],
                        [
                            "eid349",
                            "left",
                            2500,
                            1000,
                            "easeOutQuint",
                            "${ITMEET-FieldRed}",
                            '-10px',
                            '0px'
                        ],
                        [
                            "eid445",
                            "scaleY",
                            6400,
                            500,
                            "linear",
                            "${Level}",
                            '0.62',
                            '0.4'
                        ],
                        [
                            "eid479",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Button}",
                            'none',
                            'none'
                        ],
                        [
                            "eid472",
                            "left",
                            3500,
                            500,
                            "easeInQuart",
                            "${ITMEET-2}",
                            '332px',
                            '12px'
                        ],
                        [
                            "eid473",
                            "left",
                            4000,
                            1000,
                            "easeOutQuint",
                            "${ITMEET-2}",
                            '12px',
                            '22px'
                        ],
                        [
                            "eid453",
                            "left",
                            2400,
                            0,
                            "linear",
                            "${SmallScrewdriver}",
                            '7px',
                            '7px'
                        ],
                        [
                            "eid398",
                            "display",
                            0,
                            0,
                            "linear",
                            "${AllenWrenches}",
                            'none',
                            'none'
                        ],
                        [
                            "eid406",
                            "display",
                            1200,
                            0,
                            "linear",
                            "${AllenWrenches}",
                            'none',
                            'block'
                        ],
                        [
                            "eid407",
                            "display",
                            1800,
                            0,
                            "linear",
                            "${AllenWrenches}",
                            'block',
                            'none'
                        ],
                        [
                            "eid460",
                            "display",
                            0,
                            0,
                            "linear",
                            "${TapeMeasure}",
                            'none',
                            'none'
                        ],
                        [
                            "eid461",
                            "display",
                            4200,
                            0,
                            "linear",
                            "${TapeMeasure}",
                            'none',
                            'block'
                        ],
                        [
                            "eid462",
                            "display",
                            4800,
                            0,
                            "linear",
                            "${TapeMeasure}",
                            'block',
                            'none'
                        ],
                        [
                            "eid354",
                            "left",
                            7000,
                            500,
                            "easeInQuart",
                            "${THEMOST-FieldRed}",
                            '310px',
                            '-10px'
                        ],
                        [
                            "eid355",
                            "left",
                            7500,
                            1000,
                            "easeOutQuint",
                            "${THEMOST-FieldRed}",
                            '-10px',
                            '0px'
                        ],
                        [
                            "eid400",
                            "display",
                            0,
                            0,
                            "linear",
                            "${SmallScrewdriver}",
                            'none',
                            'none'
                        ],
                        [
                            "eid448",
                            "display",
                            2400,
                            0,
                            "linear",
                            "${SmallScrewdriver}",
                            'none',
                            'block'
                        ],
                        [
                            "eid410",
                            "display",
                            3000,
                            0,
                            "linear",
                            "${SmallScrewdriver}",
                            'block',
                            'none'
                        ],
                        [
                            "eid411",
                            "display",
                            7500,
                            0,
                            "linear",
                            "${SmallScrewdriver}",
                            'none',
                            'none'
                        ],
                        [
                            "eid463",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${Level}",
                            '1',
                            '1'
                        ],
                        [
                            "eid464",
                            "opacity",
                            5600,
                            0,
                            "linear",
                            "${Level}",
                            '1',
                            '1'
                        ],
                        [
                            "eid443",
                            "opacity",
                            6400,
                            500,
                            "linear",
                            "${Level}",
                            '1',
                            '0'
                        ],
                        [
                            "eid471",
                            "opacity",
                            6000,
                            500,
                            "easeOutQuint",
                            "${ITMEET-2}",
                            '1',
                            '0'
                        ],
                        [
                            "eid351",
                            "opacity",
                            6000,
                            500,
                            "linear",
                            "${ITMEET-FieldRed}",
                            '1',
                            '0'
                        ],
                        [
                            "eid431",
                            "scaleX",
                            6400,
                            500,
                            "linear",
                            "${BG}",
                            '1.55',
                            '1'
                        ],
                        [
                            "eid444",
                            "scaleX",
                            6400,
                            500,
                            "linear",
                            "${Level}",
                            '0.62',
                            '0.4'
                        ],
                        [
                            "eid457",
                            "display",
                            0,
                            0,
                            "linear",
                            "${AdjustableWrench}",
                            'none',
                            'none'
                        ],
                        [
                            "eid458",
                            "display",
                            3600,
                            0,
                            "linear",
                            "${AdjustableWrench}",
                            'none',
                            'block'
                        ],
                        [
                            "eid459",
                            "display",
                            4200,
                            0,
                            "linear",
                            "${AdjustableWrench}",
                            'block',
                            'none'
                        ],
                        [
                            "eid397",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Snips}",
                            'none',
                            'none'
                        ],
                        [
                            "eid404",
                            "display",
                            600,
                            0,
                            "linear",
                            "${Snips}",
                            'none',
                            'block'
                        ],
                        [
                            "eid405",
                            "display",
                            1200,
                            0,
                            "linear",
                            "${Snips}",
                            'block',
                            'none'
                        ],
                        [
                            "eid454",
                            "display",
                            0,
                            0,
                            "linear",
                            "${LockPliers}",
                            'none',
                            'none'
                        ],
                        [
                            "eid455",
                            "display",
                            3000,
                            0,
                            "linear",
                            "${LockPliers}",
                            'none',
                            'block'
                        ],
                        [
                            "eid456",
                            "display",
                            3600,
                            0,
                            "linear",
                            "${LockPliers}",
                            'block',
                            'none'
                        ],
                        [
                            "eid436",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Level}",
                            'none',
                            'none'
                        ],
                        [
                            "eid437",
                            "display",
                            5600,
                            0,
                            "linear",
                            "${Level}",
                            'none',
                            'block'
                        ],
                        [
                            "eid447",
                            "top",
                            6400,
                            500,
                            "linear",
                            "${Level}",
                            '-126px',
                            '-189px'
                        ],
                        [
                            "eid396",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Hammer}",
                            'block',
                            'block'
                        ],
                        [
                            "eid403",
                            "display",
                            600,
                            0,
                            "linear",
                            "${Hammer}",
                            'block',
                            'none'
                        ],
                        [
                            "eid480",
                            "display",
                            0,
                            0,
                            "linear",
                            "${NeedleNosePliers}",
                            'none',
                            'none'
                        ],
                        [
                            "eid481",
                            "display",
                            4800,
                            0,
                            "linear",
                            "${NeedleNosePliers}",
                            'none',
                            'block'
                        ],
                        [
                            "eid482",
                            "display",
                            5600,
                            0,
                            "linear",
                            "${NeedleNosePliers}",
                            'block',
                            'none'
                        ]
                    ]
                }
            },
            "Border": {
                version: "5.0.1",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.1.386",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            type: 'image',
                            display: 'block',
                            rect: ['0', '0', '300px', '250px', 'auto', 'auto'],
                            id: 'BorderGray-300x250',
                            fill: ['rgba(0,0,0,0)', 'images/BorderGray-300x250.png', '0px', '0px']
                        },
                        {
                            type: 'image',
                            display: 'none',
                            rect: ['0px', '0px', '300px', '250px', 'auto', 'auto'],
                            id: 'BorderRed-300x250',
                            fill: ['rgba(0,0,0,0)', 'images/BorderRed-300x250.png', '0px', '0px']
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            rect: [null, null, '300px', '250px']
                        }
                    }
                },
                timeline: {
                    duration: 1000,
                    autoPlay: true,
                    data: [
                        [
                            "eid392",
                            "display",
                            0,
                            0,
                            "linear",
                            "${BorderGray-300x250}",
                            'block',
                            'block'
                        ],
                        [
                            "eid395",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${BorderGray-300x250}",
                            'block',
                            'block'
                        ],
                        [
                            "eid393",
                            "display",
                            0,
                            0,
                            "linear",
                            "${BorderRed-300x250}",
                            'none',
                            'none'
                        ],
                        [
                            "eid394",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${BorderRed-300x250}",
                            'none',
                            'none'
                        ]
                    ]
                }
            },
            "Button": {
                version: "5.0.1",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.1.386",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            rect: ['0px', '0px', '133px', '29px', 'auto', 'auto'],
                            type: 'rect',
                            id: 'RectangleWhite',
                            stroke: [0, 'rgba(0,0,0,1)', 'none'],
                            display: 'block',
                            fill: ['rgba(255,255,255,1.00)']
                        },
                        {
                            font: ['Cabin, Arial, sans-serif', [20, 'px'], 'rgba(205,5,5,1.00)', '700', 'none', '', 'break-word', 'normal'],
                            type: 'text',
                            id: 'LMR',
                            text: 'LEARN MORE',
                            display: 'block',
                            rect: ['5px', '3px', '124px', '22px', 'auto', 'auto']
                        },
                        {
                            rect: ['-1px', '-1px', '133px', '29px', 'auto', 'auto'],
                            type: 'rect',
                            id: 'RectangleRed',
                            stroke: [1, 'rgba(255,255,255,1.00)', 'solid'],
                            display: 'none',
                            fill: ['rgba(205,5,5,1.00)']
                        },
                        {
                            font: ['Cabin, Arial, sans-serif', [20, 'px'], 'rgba(255,255,255,1.00)', '700', 'none', '', 'break-word', 'normal'],
                            type: 'text',
                            id: 'LMW',
                            text: 'LEARN MORE',
                            display: 'none',
                            rect: ['5px', '3px', '124px', '22px', 'auto', 'auto']
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            rect: [null, null, '133px', '29px']
                        }
                    }
                },
                timeline: {
                    duration: 1000,
                    autoPlay: true,
                    data: [
                        [
                            "eid327",
                            "display",
                            0,
                            0,
                            "linear",
                            "${RectangleWhite}",
                            'block',
                            'block'
                        ],
                        [
                            "eid328",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${RectangleWhite}",
                            'block',
                            'none'
                        ],
                        [
                            "eid367",
                            "display",
                            0,
                            0,
                            "linear",
                            "${LMW}",
                            'none',
                            'none'
                        ],
                        [
                            "eid368",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${LMW}",
                            'none',
                            'block'
                        ],
                        [
                            "eid391",
                            "left",
                            0,
                            0,
                            "linear",
                            "${LMR}",
                            '5px',
                            '5px'
                        ],
                        [
                            "eid389",
                            "left",
                            1000,
                            0,
                            "linear",
                            "${LMW}",
                            '5px',
                            '5px'
                        ],
                        [
                            "eid365",
                            "display",
                            0,
                            0,
                            "linear",
                            "${LMR}",
                            'block',
                            'block'
                        ],
                        [
                            "eid366",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${LMR}",
                            'block',
                            'none'
                        ],
                        [
                            "eid176",
                            "display",
                            0,
                            0,
                            "linear",
                            "${RectangleRed}",
                            'none',
                            'none'
                        ],
                        [
                            "eid179",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${RectangleRed}",
                            'none',
                            'block'
                        ]
                    ]
                }
            },
            "Button-png": {
                version: "5.0.1",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.1.386",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            type: 'image',
                            display: 'block',
                            rect: ['0px', '0px', '144px', '43px', 'auto', 'auto'],
                            id: 'Button-1',
                            fill: ['rgba(0,0,0,0)', 'images/Button-1.png', '0px', '0px']
                        },
                        {
                            type: 'image',
                            display: 'none',
                            rect: ['0px', '0px', '144px', '43px', 'auto', 'auto'],
                            id: 'Button-2',
                            fill: ['rgba(0,0,0,0)', 'images/Button-2.png', '0px', '0px']
                        }
                    ],
                    style: {
                        '${symbolSelector}': {
                            rect: [null, null, '144px', '43px']
                        }
                    }
                },
                timeline: {
                    duration: 1000,
                    autoPlay: true,
                    data: [
                        [
                            "eid467",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Button-2}",
                            'none',
                            'none'
                        ],
                        [
                            "eid468",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${Button-2}",
                            'none',
                            'block'
                        ],
                        [
                            "eid465",
                            "display",
                            0,
                            0,
                            "linear",
                            "${Button-1}",
                            'block',
                            'block'
                        ],
                        [
                            "eid464",
                            "display",
                            1000,
                            0,
                            "linear",
                            "${Button-1}",
                            'block',
                            'none'
                        ]
                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("iCIMS-st-HardTools-300x250_edgeActions.js");
})("EDGE-9612537");
