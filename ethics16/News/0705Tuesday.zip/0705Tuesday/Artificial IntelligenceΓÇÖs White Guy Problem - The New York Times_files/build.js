require([
	'jquery/nyt',
	'underscore/1.5',
	'foundation/views/page-manager',
	'd3/3',
	'queue/1'
	// 'resizerScript'	// uncomment this line to include resizerScript
	], function($, _, PageManager, d3, queue) {
	
	
	// Go!
	$('#d-promo-realestate').closest('.mobile.page-interactive-embedded').addClass('d-wrapper');
	
	
	
	
	
	
}); // end require;
define("script", function(){});

