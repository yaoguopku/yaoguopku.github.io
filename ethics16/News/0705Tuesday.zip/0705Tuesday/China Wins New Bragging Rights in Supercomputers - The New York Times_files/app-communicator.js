/**
 * Creates a default new instance of the interactive app communicator
 *
 * <p><b>Require Path:</b> shared/interactive/instances/app-communicator</p>
 *
 * @module Shared
 * @submodule Shared.Interactive
 * @class AppCommunicatorInstance
 * @static
**/
define([
    'shared/interactive/views/app-communicator'
], function (AppCommunicator) {
    'use strict';
    return new AppCommunicator();
});
