(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "LINCOLN",
      'continent': "NA",
      'country': "US",
      'region': "NE"
    },
    'ip':"76.85.196.158"
  }]);
})
//
()

;