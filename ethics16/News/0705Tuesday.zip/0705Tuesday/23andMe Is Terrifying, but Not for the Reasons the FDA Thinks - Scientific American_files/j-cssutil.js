/**
* @fileoverview Utility function for working with CSS.
* @author paulyang@google.com (Paul Yang)
*/


var CssUtil = {};


/**
* An array of browser prefixes. Note that the first element is an empty string.
* @type {!Array.<string>}
* @const
* @private
*/
CssUtil.browserPrefixes_ = ['', '-ms-', '-moz-', '-webkit-'];


/**
* Applies named CSS property with given value to the provided element.
* @param {!Element} element the element.
* @param {string} name The name of the css attribute to set.
* @param {string} value The value of the css to set.
* @param {boolean=} opt_prefixOnValue Whether or not to add the borwser prefix
*     to the value, too.
*/
CssUtil.applyCssWithBrowserPrefix = function(
   element, name, value, opt_prefixOnValue) {
 for (var i = 0; i < CssUtil.browserPrefixes_.length; ++i) {
 	try{
   element.style[CssUtil.browserPrefixes_[i] + name] =
       (opt_prefixOnValue ? CssUtil.browserPrefixes_[i] : '') + value;
   }catch(e){}
 }
};