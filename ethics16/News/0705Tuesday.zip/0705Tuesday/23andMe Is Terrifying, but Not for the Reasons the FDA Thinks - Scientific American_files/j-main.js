// ------------------------------------------------------------
//  Variable Declarations
// ------------------------------------------------------------

var nDuration 		= 0;
var nCurrent 		= 0;
var bLoaderHidden 	= false;
var bFinalFrame 	= false;
var bPixelClick 	= false;

// IDS
var idLoader;
var idContainer;
var idFrame1;
var idFrame2;
var idFrame3;
var idFrame4;
var idFooter;
var idCTA;


// ------------------------------------------------------------
// Waiting for Enabler to be initialized
// Any Studio action can be performed only when Enabler is fully loaded 
// ------------------------------------------------------------

function startAnimation (){
	console.log ("[f:startAnimation]");
	
	  setVariables(); //setting variables handling reference to divs
		
	  if (Enabler.isInitialized()) {
		enablerInitHandler();
	  } else {
		Enabler.addEventListener(studio.events.StudioEvent.INIT, enablerInitHandler);
	  }
};  


// ------------------------------------------------------------
// Initializing creative when ad is visible */
// ------------------------------------------------------------

enablerInitHandler = function(e) {
  if(Enabler.isVisible()) {
    startAd();
  } else {
    Enabler.addEventListener(studio.events.StudioEvent.VISIBLE, startAd);
  } 
};


// ------------------------------------------------------------
// Funcation launching ad: adding video, setting dynamic content and method handlers 
// ------------------------------------------------------------

startAd = function(){
	// console.log (">> f:startAd");
	
	setVariables();
	
	var sEventType; //variable changing type click/touchend depend of platform
	
	//Checking browser type and platform. No autoplay on mobile, so we can hide loader. On desktop loader will try to use event handlers.
	if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPad/i)) || (navigator.userAgent.match(/iPod/i)) || (navigator.userAgent.match(/Android/i))){  
  		sEventType = 'touchend';
   		// hideLoader();
	} else {
  		sEventType = 'click';
	}
	
	setHandlers(sEventType); //Attaching handlers
	
	playBanner(); //Launch animation	
}


// ------------------------------------------------------------
// Mapping handlers to divs
// ------------------------------------------------------------

setVariables = function(){
	//console.log (">> f:setVariables");
	
	idLoader 					= document.getElementById('loader');
	idContainer					= document.getElementById('container');
	
	idFrame1					= document.getElementById('frame1');
	idFrame2					= document.getElementById('frame2');
	idFrame3					= document.getElementById('frame3');
	idFrame4					= document.getElementById('frame4');
		
	idFooter					= document.getElementById('footer-container');
	idCTA						= document.getElementById('cta');
	
	idFrame1.style.opacity 	= '0'; 
	idFrame2.style.opacity 	= '0'; 
	idFrame3.style.opacity 	= '0'; 
	idFrame4.style.opacity 	= '0'; 
	// idCTA.style.opacity 		= '0';
	idFooter.style.opacity 		= '0';
	
}


// ------------------------------------------------------------
// Setting event handlers to divs
// ------------------------------------------------------------

setHandlers = function(sEventType){
	console.log (">> f:setHandlers | sEventType: " + sEventType);
	
	// idBgExit.addEventListener(sEventType, bg_exitClick, false);
   	// idTopExitLayer.addEventListener(sEventType, bg_exitClick, false);
}


// ------------------------------------------------------------
// Launch animation event
// ------------------------------------------------------------

playBanner = function(type){
	// console.log (">> f:playBanner");
	
	var del = 0;
	
	// Frame 1
	TweenLite.to(idLoader, 	0.5, {opacity:0, ease:Quad.easeOut, delay:del+=0, overwrite:false, onComplete:hideLoader});
	TweenLite.to(idFrame1, 	0.5, {opacity:1, ease:Quad.easeInOut, delay:del+=0, overwrite:false});
	
	// Frame 2
	TweenLite.to(idFrame1, 	0.5, {opacity:0, ease:Quad.easeInOut, delay:del+=3, overwrite:false});
	TweenLite.to(idFrame2, 	0.5, {opacity:1, ease:Quad.easeInOut, delay:del+=0.5, overwrite:false});
	
	// Frame 3
	TweenLite.to(idFrame2, 	0.5, {opacity:0, ease:Quad.easeInOut, delay:del+=3, overwrite:false});
	TweenLite.to(idFrame3, 	0.5, {opacity:1, ease:Quad.easeInOut, delay:del+=0.5, overwrite:false});
	
	// Frame 4
	TweenLite.to(idFrame3, 	0.5, {opacity:0, ease:Quad.easeInOut, delay:del+=3, overwrite:false});
	TweenLite.to(idFrame4, 	0.5, {opacity:1, ease:Quad.easeInOut, delay:del+=0.5, overwrite:false});
	TweenLite.to(idCTA, 	0.5, {opacity:1, ease:Quad.easeIn, delay:del+=2, overwrite:false});
	TweenLite.to(idFooter, 	0.5, {opacity:1, ease:Quad.easeIn, delay:del+=0, overwrite:false});
	
}


// ------------------------------------------------------------
// CSS Animation function
// ------------------------------------------------------------

function hideLoader () {
	// console.log ("[f:hideLoader");
	
	if (bInit == true) {
		// set visiblilty of overlay	
		var overlay = document.getElementById('overlay');
		overlay.style.display = 'none'; // hide
		bInit = false;
	}
}


// ------------------------------------------------------------ 
// setting final visibility of objects on stage on final frame
// ------------------------------------------------------------

finalDisplayState = function(speed){ //You can set tranistion time by adding speed in ms. If nothing is provided it will be 0ms.
	
	console.log (">> f:finalDisplayState");

	var animationTime = (speed) ? speed : 0;
	idBackground.style.opacity = '0';
	
	bFinalFrame = true;
}


// ------------------------------------------------------------
// hide loader and set flag
// ------------------------------------------------------------

hideLoader = function(e){
	// console.log (">> f:hideLoader");

	// CssUtil.applyCssWithBrowserPrefix(idLoader,'transition','all ' + 5 + 'ms ease-in-out');
	// CssUtil.applyCssWithBrowserPrefix(idLoader,'opacity','0');   
	// CssUtil.applyCssWithBrowserPrefix(idLoader,'opacity','0' + 2 + 'ms ease-in-out');
	
	bLoaderHidden = true;
	idLoader.style.visibility = 'hidden'; 
	idLoader.style.display ='none';
}


// ------------------------------------------------------------
// check tweenlite is loaded before starting ad
// ------------------------------------------------------------

// setTimeout(function(){startAd ();}, 1000);

function TweenLiteLoadHandler() {
	try {
		if (TweenLite) {
			console.log ('TweenLite Loaded');
			startAd();
		}
	}
	catch(err) {
		console.log ('TweenLite NOT Loaded');
		setTimeout(TweenLiteLoadHandler,1000);
	}
}

TweenLiteLoadHandler();