// --------------------------------------------------
// Variable Declarations
// --------------------------------------------------

var bDynamicOn		= true; // True = Populates with dynamic/static vars | False = Inline elements displays
var bDynamicLiveOn	= true; // True = Live Dynamic | Feed, False = Static Dynamic Feed

var bgExit;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var intro = "Flying to";
var destination = "San Francisco?";
var destinationIcon = "dynamic_images/la.png";

var proofPoint1 = "Choose from 15 flights<br />every day";
var proofPoint1Icon = "dynamic_images/experience_britain.png";

var proofPoint2 = "At times that<br />suit you";
var proofPoint2Icon = "dynamic_images/london_connections.png";

var endframeIcon = "dynamic_images/la.png";
var endframe = "Fly to San Francisco";
var price = "£XXX";
var priceInfo = "pp";

var holidays = "Book flights + hotel and save";
var atol = true;

var terms = "T&Cs apply";
var cta = "Search ba.com";

var exitURL = "http://www.britishairways.com";

// var format = 'LEADER'; // *** set on index page ***

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// --------------------------------------------------
// Setup namespace for ad.
// --------------------------------------------------

var creative = {};

creative.init = function () {
  // console.log ("[f:creative.init]");
	
  creative.setupDOMElements();

  // Check if Enabler is initialized.
  if (Enabler.isInitialized()) {
    // Check if ad is visible to user.
    if (Enabler.isVisible()) {
      creative.enablerInitHandler();
    } else {
      Enabler.addEventListener(studio.events.StudioEvent.VISIBLE, creative.enablerInitHandler);
    }
  } else {
    Enabler.addEventListener(studio.events.StudioEvent.INIT, creative.enablerInitHandler);
  }
};


// ------------------------------------------------------------
// setupDOMElements
// ------------------------------------------------------------

creative.setupDOMElements = function () {
  	
	creative.domElements = {};
	  
	creative.domElements.copy1	=  document.getElementById('frame1').getElementsByClassName('copy')[0];
	creative.domElements.icon1	=  document.getElementById('frame1').getElementsByClassName('icon')[0];
	
	creative.domElements.copy2	=  document.getElementById('frame2').getElementsByClassName('copy')[0];
	creative.domElements.icon2	=  document.getElementById('frame2').getElementsByClassName('icon')[0];
	
	creative.domElements.copy3	=  document.getElementById('frame3').getElementsByClassName('copy')[0];
	creative.domElements.icon3	=  document.getElementById('frame3').getElementsByClassName('icon')[0];
	
	creative.domElements.copy4	=  document.getElementById('frame4').getElementsByClassName('copy')[0];
	creative.domElements.icon4	=  document.getElementById('frame4').getElementsByClassName('icon')[0];
	
	creative.domElements.price	=  document.getElementById('price')
	creative.domElements.cta	=  document.getElementById('cta');
	creative.domElements.terms	=  document.getElementById('terms');
	creative.domElements.atol	=  document.getElementById('logo-atol');
};


// ------------------------------------------------------------
// enablerInitHandler
// ------------------------------------------------------------

creative.enablerInitHandler = function (event) {
	// console.log ("[f:creative.enablerInitHandler]");
	
	// Initialise variables
	bgExit 								= document.getElementById('background_exit_dc');
	
	//Bring in listeners i.e. if a user clicks or rollsover
	addListeners();
	
	//Show Ad
	container.style.display = "block";
	
	// Creative Dynamic Available
	creative.dynamicDataAvailable();
	// creative.domElements.button.addEventListener('click', creative.exitClickHandler);
	creative.showAd();
	
	if (Enabler.isPageLoaded()) {
		creative.pageLoadHandler();
	} else {
		Enabler.addEventListener(
			studio.events.StudioEvent.PAGE_LOADED, creative.pageLoadHandler);
		}
};


// ------------------------------------------------------------
// enablerInitHandler
// ------------------------------------------------------------

creative.dynamicDataAvailable = function () {
	 console.log ("[f:creative.dynamicDataAvailable]");
	 
	 /*
	 * Dynamic Content Enable code for Profile: 1070475 
	 *
	 * The following code initializes the following dynamic variables for
	 * development testing and live serving of Fields associated to the above profile
	 */
	 
	 // <!-- DynamicContent Start: HTML5 invocation code. -->
	
	 // Dynamic Content variables and sample values
     Enabler.setProfileId(1070475);
     var devDynamicContent = {};
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1= [{}];
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0]._id = 0;
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ID = 1;
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Label = "Origin";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Exit_URL = {};
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Exit_URL.Url = "http://www.britishairways.com";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].DCM_Placement_ID = [12345];
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Default = false;
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Active = true;
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Creative_Size = {};
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Creative_Size.Value = ["width: 300 height: 250"];
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Intro = "Flying to";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Destination = "New York?";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Destination_icon = {};
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Destination_icon.Type = "file";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Destination_icon.Url = "https://s0.2mdn.net/ads/richmedia/studio/41272163/53109_20160205103325347_nyc.png";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ProofPoint1 = "Choose from 15 flights<br \/>every day";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ProofPoint1_icon = {};
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ProofPoint1_icon.Type = "file";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ProofPoint1_icon.Url = "https://s0.2mdn.net/ads/richmedia/studio/41272162/53109_20160205103314234_2flights.png";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ProofPoint2 = "At times that<br \/>suit you";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ProofPoint2_icon = {};
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ProofPoint2_icon.Type = "file";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ProofPoint2_icon.Url = "https://s0.2mdn.net/ads/richmedia/studio/41272234/53109_20160205103319172_flightimes.png";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Endframe_icon = {};
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Endframe_icon.Type = "file";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Endframe_icon.Url = "https://s0.2mdn.net/ads/richmedia/studio/41272163/53109_20160205103325347_nyc.png";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Endframe = "Fly to<br />New York";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Price = "";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].PriceInfo = "pp";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Holidays = "";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ATOL_boolean = false;
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].Terms = "Es gelten die allgemeinen Geschäftsbedingungen.";
	 devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].CTA = "Consultez www.ba.com";
	 Enabler.setDevDynamicContent(devDynamicContent);

	 /*
	 You may access the variables in the following manner AFTER the Studio Enabler is initialized.
	 var ID = dynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0].ID;
	 Note: be sure to use "dynamicContent", not "devDynamicContent"
	 Note: be sure to use ExitOverride to create your exit URL dynamically; follow the instructions on our Help center: https://support.google.com/richmedia/answer/2664807
	 */
		
	if (bDynamicOn == true) {
		
		// ------------------------------------------------------------------------------
		// Check if live of local del data is displaying
		// ------------------------------------------------------------------------------
		
		var dynamicData = {};
		
		if (bDynamicLiveOn == true) {
			// true - set to live dynamic data
			dynamicData     = dynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0];
			// console.log ("DYNAMIC: " + dynamicData.headline_txt);
		} 
		
		if (bDynamicLiveOn == false) {
			// false  - set to local dynamic fields
			dynamicData     = devDynamicContent.BA_AlwaysOn_DC_DataFeed_Sheet1[0];
			// console.log ("LOCAL: " + dynamicData.headline_txt);
		}
		
		// ------------------------------------------------------------------------------
		// populate dynamic variables
		// ------------------------------------------------------------------------------
		
		// Set format dynamically
		
		/*console.log(dynamicData.Creative_Size);
		var spaces = dynamicData.Creative_Size.Value[0].split(" ");
		switch(spaces[1]) {
		    case "728":
		        format="LEADER";
		        break;
		    case "160":
		        format="SKY";
		        break;
		    default:
				switch(spaces[3]) {
				    case "600":
				        format="DMPU";
				        break;
				    default:
						format="MPU";
				}
		}
		console.log(dynamicData.Creative_Size.Value[0] +' = '+ format);*/
		
		
		intro = dynamicData.Intro;
		destination = dynamicData.Destination;
		destinationIcon = dynamicData.Destination_icon.Url;

		proofPoint1 = dynamicData.ProofPoint1;
		proofPoint1Icon = dynamicData.ProofPoint1_icon.Url;

		proofPoint2 = dynamicData.ProofPoint2;
		proofPoint2Icon = dynamicData.ProofPoint2_icon.Url;

		endframeIcon = dynamicData.Endframe_icon.Url;
		endframe = dynamicData.Endframe;
		price = dynamicData.Price;
		priceInfo = dynamicData.PriceInfo;

		holidays = dynamicData.Holidays;
		atol = dynamicData.ATOL_boolean;

		terms = dynamicData.Terms;
		cta = dynamicData.CTA;
		
		exitURL = dynamicData.Exit_URL.Url;
		
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// Set format class
	
	function hasClass(el, className) {
	  if (el.classList)
	    return el.classList.contains(className)
	  else
	    return !!el.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'))
	}

	function addClass(el, className) {
	  if (el.classList)
	    el.classList.add(className)
	  else if (!hasClass(el, className)) el.className += " " + className
	}
	
	var el = document.getElementById('container');
	addClass(el, format)
	
	
	// ------------------------------------------------------------------------------
	// populate dynamic fields
	// ------------------------------------------------------------------------------
	
	// Destination
	
	creative.domElements.icon1.style.backgroundImage = "url('"+destinationIcon+"')";;
	creative.domElements.copy1.innerHTML = intro +'<div>'+ destination +'</div>';
	
	// Proof Points
	
	creative.domElements.icon2.style.backgroundImage = "url('"+proofPoint1Icon+"')";;
	creative.domElements.copy2.innerHTML = proofPoint1;
	
	creative.domElements.icon3.style.backgroundImage = "url('"+proofPoint2Icon+"')";;
	creative.domElements.copy3.innerHTML = proofPoint2;
	
	// Final Frame
	
	creative.domElements.icon4.style.backgroundImage = "url('"+endframeIcon+"')";;
	//
	if(price) {
		creative.domElements.copy4.innerHTML = endframe;
		creative.domElements.price.innerHTML = price+'<span id="price-info">'+ priceInfo +'</span>';
	}else if(holidays){
		creative.domElements.price.style.display = 'none';
		creative.domElements.copy4.innerHTML = endframe +'<div id="holidays">'+ holidays +'</div>';
		addClass(document.getElementById('frame4'), 'holidays');
	}else {
		creative.domElements.price.style.display = 'none';
		// var brs = endframe.split("<br />");
		// if(endframe.includes("<br />")){
			// creative.domElements.copy4.innerHTML = brs[0] +'<div id="noprice">'+brs[1]+'</div>';
		// }else{
			creative.domElements.copy4.innerHTML = endframe;
		// }
	}
	
	// Footer
	
	if(atol) {
		creative.domElements.atol.style.display = 'block';
		addClass(document.getElementById('terms'), 'atol');
	}else{
		creative.domElements.atol.style.display = 'none';
	}
	creative.domElements.terms.innerHTML = terms;
	creative.domElements.cta.innerHTML   = cta;
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// ----------------------------------------
	// load in Javascript
	// ----------------------------------------
	
	// external JS - MainAnim
	var extJS_MainAnim = document.createElement('script');
	extJS_MainAnim.setAttribute('type', 'text/javascript');
	extJS_MainAnim.setAttribute('src', Enabler.getUrl('j-main.js')); 
	document.getElementsByTagName('head')[0].appendChild(extJS_MainAnim);
	
};


// --------------------------------------------------
// Click Handlers
// --------------------------------------------------


creative.exitClickHandler = function (event) {
  // Enabler.exit('exit', creative.dynamicExitUrl);
  // console.log ("[f:creative.exitClickHandler]");
};

creative.pageLoadHandler = function (event) {
	// console.log ("[f:pageLoadHandler]");
	
};

// Is triggered when the background image in polite.js was fully loaded.
creative.showAd = function () {
	// console.log ("[f:showAd]");
};

// Start creative once all elements in window are loaded.
window.addEventListener('load', creative.init.bind(creative));


// --------------------------------------------------
// Add Event Listeners
// --------------------------------------------------

addListeners = function() {
	// console.log ("[f:addListeners]");
	bgExit.addEventListener('click', bgExitHandler, false);
	// tandcExit.addEventListener('click', tandcExitHandler, false);
}


// --------------------------------------------------
// Background Exit
// --------------------------------------------------

bgExitHandler = function(e) {
	// console.log ("[f:bgExitHandler] "+exitURL);
	Enabler.exit('clickThru');
	
	//Using this method overrides any exit URL entered in the Studio Web UI, DCM or DFP
	// Enabler.exitOverride('clickThru', exitURL);
}