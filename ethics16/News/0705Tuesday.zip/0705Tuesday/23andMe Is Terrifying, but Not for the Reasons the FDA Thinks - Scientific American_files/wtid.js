if (typeof(Webtrends.dcss.dcsobj_0.dcsGetIdCallback)=="function"){
Webtrends.dcss.dcsobj_0.dcsGetIdCallback({"gWtId":"","gTempWtId":"38a6cabb-5766-490e-b5d5-66b8bb6bc7fc","gWtAccountRollup":""});
}
