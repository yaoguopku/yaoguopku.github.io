


var oo_profile={
 tokenType : "1",
 tracking : "",
 tags : "",
 tagcloud : [
  ],
 pixels : [
  { url: "https://pixel.rubiconproject.com/tap.php?v=2372||2373|0||2374|0||"}
  ]
};


try {
oz_onPixelsLoaded(oo_profile);
} catch(ignore) {}
