(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 970,
	height: 250,
	fps: 42,
	color: "#000000",
	manifest: [
		{src:"images/BigMoney.jpg?1465495877803", id:"BigMoney"},
		{src:"images/headline_bold.png?1465495877803", id:"headline_bold"},
		{src:"images/hotspot.png?1465495877803", id:"hotspot"},
		{src:"images/hotspot_shadow.png?1465495877803", id:"hotspot_shadow"},
		{src:"images/magnify_circle.png?1465495877803", id:"magnify_circle"},
		{src:"images/money.jpg?1465495877803", id:"money"},
		{src:"images/toolTip.png?1465495877803", id:"toolTip"}
	]
};



// symbols:



(lib.BigMoney = function() {
	this.initialize(img.BigMoney);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,973,471);


(lib.headline_bold = function() {
	this.initialize(img.headline_bold);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,131,97);


(lib.hotspot = function() {
	this.initialize(img.hotspot);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,105,110);


(lib.hotspot_shadow = function() {
	this.initialize(img.hotspot_shadow);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,24,23);


(lib.magnify_circle = function() {
	this.initialize(img.magnify_circle);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,108,108);


(lib.money = function() {
	this.initialize(img.money);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,582,282);


(lib.toolTip = function() {
	this.initialize(img.toolTip);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,82,40);


(lib.m_headline = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// png
	this.instance = new lib.headline_bold();
	this.instance.setTransform(-453,113);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-453,106,131,110.3);


(lib.m_blank = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.g_magnify_glass = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mask core (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoKIKQjYjYgBkyQABkxDYjZQDZjYExAAQEyAADZDYQDZDZAAExQAAEyjZDYQjZDakygBQkxABjZjagAj5j6QhpBpAACRQAACSBpBpQBoBoCRgBQCTABBnhoQBphpAAiSQAAiRhphpQhnhoiTABQiRgBhoBog");
	mask.setTransform(-0.5,-0.4);

	// png
	this.instance = new lib.magnify_circle();
	this.instance.setTransform(-54,-54);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54,-54,108,108);


(lib.g_hotspot_center = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.hotspot();
	this.instance.setTransform(-18,-18.8,0.343,0.343);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18,-18.8,36,37.7);


(lib.g_cta_meat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYArIAAgHIACABIADAAQAEAAACgDQADgCACgEIAFgNIgXg5IAJAAIARAtIAAACIAAACIAAgCIABgBIASguIAIAAIgbBFQgDAIgFAFQgEADgHAAIgFAAg");
	this.shape.setTransform(74.2,15.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgNAeIAAg6IAHAAIAAANIABAAIACgGIADgFIAEgCIAFgBIADAAIACABIAAAHQgCgBgFAAQgDgBgBACIgDADIgDAFIgBAEIgBAHIgBADIAAAdg");
	this.shape_1.setTransform(69.4,13.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgLAcQgFgCgEgDQgEgFgBgGQgDgFAAgHQAAgGADgFQACgGADgFQAFgEAFgBQAFgDAGAAQAGAAAFADQAFABAEAEQADAFADAGQACAFAAAGQAAAHgCAFQgDAGgDAEQgEAEgFACQgGADgGAAQgFAAgGgDgAgHgWQgEACgDADQgDADgCAFQgBAFAAAEQAAAFABAFQACAEADAEIAHAFQAEABADABQAEgBAFgBQAEgCACgDQADgEACgEIABgKQgBgKgFgHQgFgGgKgBQgDAAgEACg");
	this.shape_2.setTransform(63.5,14);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgFAWIAAgkIgKAAIAAgGIAKAAIAAgPIAGgDIAAASIAPAAIAAAGIgPAAIAAAjQAAAGACADQACADAEAAQAEAAADgDIAAAHQgEACgEAAQgNAAAAgRg");
	this.shape_3.setTransform(58.2,13.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgRAbIAAgJIADADIAFACIAEABIAEABQALgBAAgJIgBgFIgCgCIgFgDIgDgDIgHgCIgFgDIgDgEIgBgGQAAgEABgDQACgDAEgDIAGgCIAGgCQAIAAAGADIAAAIQgHgEgIgBIgDABIgEADIgCADIgBADIABAFIABACIAFADIADADIAHABIAGADIADAFIABAGQAAAEgBADQgCADgEACIgGAEIgHABQgJAAgGgEg");
	this.shape_4.setTransform(54,14);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgJAdQgEgCgEgEQgEgFgBgFQgCgGAAgHQAAgFACgGQACgGADgEQAFgEAEgCQAFgDAEAAQAGAAAFACQAEACADAEQADADACAGQABAFAAAHIAAACIgqAAIACAKQACAEADADIAGAFQAEABACABQALAAAJgIIAAAIQgKAGgMAAQgEAAgFgCgAARgEQAAgJgEgFQgFgFgHgBQgCABgDABIgGAEIgEAGIgCAIIAhAAIAAAAg");
	this.shape_5.setTransform(45.2,14);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAQAsIAAgjQAAgJgEgEQgDgFgIAAQgCAAgDACQgDABgDADQgCADgCABQgBAEAAAFIAAAiIgHAAIAAhXIAHAAIAAAnIABAAQAGgMALABQAKgBAGAHQAEAGAAAKIAAAlg");
	this.shape_6.setTransform(38.9,12.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgFAWIAAgkIgKAAIAAgGIAKAAIAAgPIAGgDIAAASIAPAAIAAAGIgPAAIAAAjQAAAGACADQACADAEAAQAEAAADgDIAAAHQgEACgEAAQgNAAAAgRg");
	this.shape_7.setTransform(33.6,13.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJAdQgEgCgEgEQgEgFgBgFQgCgGAAgHQAAgFACgGQACgGADgEQAFgEAEgCQAFgDAEAAQAGAAAFACQAEACADAEQADADACAGQABAFAAAHIAAACIgqAAIACAKQACAEADADIAGAFQAEABACABQALAAAJgIIAAAIQgKAGgMAAQgEAAgFgCgAARgEQAAgJgEgFQgFgFgHgBQgCABgDABIgGAEIgEAGIgCAIIAhAAIAAAAg");
	this.shape_8.setTransform(25.4,14);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgIAdQgFgCgEgEQgDgFgCgFQgCgGAAgHQAAgFACgGQACgGAEgEQAEgEAFgCQAEgDAEAAQAGAAAEACQAFACADAEQADADACAGQABAFAAAHIAAACIgpAAIABAKQABAEAEADIAFAFQAFABACABQAKAAAJgIIAAAIQgIAGgMAAQgEAAgFgCgAASgEQgBgJgEgFQgEgFgIgBQgCABgDABIgGAEIgEAGIgCAIIAiAAIAAAAg");
	this.shape_9.setTransform(19.3,14);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgHAqIgGgBIgFgBIgEgCIAAgJIAFADIAFACIAFACIAFAAQAIAAAFgEQAEgDAAgIIgBgFIgDgFIgGgEIgHgFIgJgEIgGgFQgDgCgBgEIgBgHQAAgFACgEQACgEAEgDQAEgDAFgBQAFgCADAAQAKAAAHADIAAAIQgHgEgKAAIgGABIgFACIgEAFQgCACAAAEIABAGIADAEIAGAFIAHAEIAJAEIAGAGIAEAFIABAHQAAAGgCAEQgCAEgDAEIgJADQgFACgEAAg");
	this.shape_10.setTransform(13.1,12.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0177D4").s().p("Am2CCIAAkCINuAAIAAECg");
	this.shape_11.setTransform(44,13);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,88,26);


(lib.g_clickHover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.toolTip();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,82,40);


(lib.b_blank = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiECiQg1gegIhnQgIhkAugzQAug0BcgJQBagKA6AnQA6AnAGBfQAFBdgtA1QguA0hfAHIgfABQhIAAgrgYg");
	this.shape.setTransform(0.6,0.1);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.m_magnfiyGlass = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// lense
	this.instance = new lib.g_magnify_glass("synched",0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54,-54,108,108);


(lib.m_hotspot4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{spin:1});

	// timeline functions:
	this.frame_0 = function() {
		//this.stop();
	}
	this.frame_89 = function() {
		this.gotoAndPlay("spin");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(89).call(this.frame_89).wait(1));

	// button
	this.sectionButton = new lib.b_blank();
	this.sectionButton.setTransform(-2.7,-23,3.096,2.54);
	new cjs.ButtonHelper(this.sectionButton, 0, 1, 2, false, new lib.b_blank(), 3);

	this.timeline.addTween(cjs.Tween.get(this.sectionButton).wait(90));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgwAxQgVgUAAgdQAAgbAVgVQAVgVAbAAQAdAAAUAVQAVAVAAAbQAAAdgVAUQgUAVgdAAQgbAAgVgVg");

	// center
	this.instance = new lib.g_hotspot_center("synched",0);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(90));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhNBNQgfggAAgtQAAgsAfghQAhgfAsAAQAtAAAgAfQAhAhgBAsQABAtghAgQggAhgtgBQgsABghghgAgwgwQgVAVAAAbQAAAdAVAUQAVAVAbAAQAdAAAUgVQAVgUAAgdQAAgbgVgVQgUgVgdAAQgbAAgVAVg");

	// hs
	this.instance_1 = new lib.g_hotspot_center("synched",0);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({startPosition:0},0).to({rotation:360},88).wait(1));

	// shadow
	this.instance_2 = new lib.hotspot_shadow();
	this.instance_2.setTransform(-11,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(90));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.3,-70.1,121.2,94.9);


(lib.m_hotspot3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"spin":1});

	// timeline functions:
	this.frame_0 = function() {
		//this.stop();
	}
	this.frame_89 = function() {
		this.gotoAndPlay("spin");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(89).call(this.frame_89).wait(1));

	// button
	this.sectionButton = new lib.b_blank();
	this.sectionButton.setTransform(-3.7,-23.7,2.605,2.645);
	new cjs.ButtonHelper(this.sectionButton, 0, 1, 2, false, new lib.b_blank(), 3);

	this.timeline.addTween(cjs.Tween.get(this.sectionButton).wait(90));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgwAxQgVgUAAgdQAAgbAVgVQAVgVAbAAQAdAAAUAVQAVAVAAAbQAAAdgVAUQgUAVgdAAQgbAAgVgVg");

	// center
	this.instance = new lib.g_hotspot_center("synched",0);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(90));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhNBNQgfggAAgtQAAgsAfghQAhgfAsAAQAtAAAgAfQAhAhgBAsQABAtghAgQggAhgtgBQgsABghghgAgwgwQgVAVAAAbQAAAdAVAUQAVAVAbAAQAdAAAUgVQAVgUAAgdQAAgbgVgVQgUgVgdAAQgbAAgVAVg");

	// hs
	this.instance_1 = new lib.g_hotspot_center("synched",0);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({startPosition:0},0).to({rotation:360},88).wait(1));

	// shadow
	this.instance_2 = new lib.hotspot_shadow();
	this.instance_2.setTransform(-11,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(90));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53,-72.8,101.9,98.9);


(lib.m_hotspot2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"spin":1});

	// timeline functions:
	this.frame_0 = function() {
		//this.stop();
	}
	this.frame_89 = function() {
		this.gotoAndPlay("spin");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(89).call(this.frame_89).wait(1));

	// button
	this.sectionButton = new lib.b_blank();
	this.sectionButton.setTransform(-0.7,-9.7,2.407,2.808);
	new cjs.ButtonHelper(this.sectionButton, 0, 1, 2, false, new lib.b_blank(), 3);

	this.timeline.addTween(cjs.Tween.get(this.sectionButton).wait(90));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgwAxQgVgUAAgdQAAgbAVgVQAVgVAbAAQAdAAAUAVQAVAVAAAbQAAAdgVAUQgUAVgdAAQgbAAgVgVg");

	// center
	this.instance = new lib.g_hotspot_center("synched",0);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(90));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhNBNQgfggAAgtQAAgsAfghQAhgfAsAAQAtAAAgAfQAhAhgBAsQABAtghAgQggAhgtgBQgsABghghgAgwgwQgVAVAAAbQAAAdAVAUQAVAVAbAAQAdAAAUgVQAVgUAAgdQAAgbgVgVQgUgVgdAAQgbAAgVAVg");

	// hs
	this.instance_1 = new lib.g_hotspot_center("synched",0);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({startPosition:0},0).to({rotation:360},88).wait(1));

	// shadow
	this.instance_2 = new lib.hotspot_shadow();
	this.instance_2.setTransform(-11,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(90));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.3,-61.8,94.2,105);


(lib.m_hotspot1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"spin":1});

	// timeline functions:
	this.frame_0 = function() {
		//this.stop();
	}
	this.frame_89 = function() {
		this.gotoAndPlay("spin");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(89).call(this.frame_89).wait(1));

	// button
	this.sectionButton = new lib.b_blank();
	this.sectionButton.setTransform(1.5,-25.7,3.061,2.051);
	new cjs.ButtonHelper(this.sectionButton, 0, 1, 2, false, new lib.b_blank(), 3);

	this.timeline.addTween(cjs.Tween.get(this.sectionButton).wait(90));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgwAxQgVgUAAgdQAAgbAVgVQAVgVAbAAQAdAAAUAVQAVAVAAAbQAAAdgVAUQgUAVgdAAQgbAAgVgVg");

	// center
	this.instance = new lib.g_hotspot_center("synched",0);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(90));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhNBNQgfggAAgtQAAgsAfghQAhgfAsAAQAtAAAgAfQAhAhgBAsQABAtghAgQggAhgtgBQgsABghghgAgwgwQgVAVAAAbQAAAdAVAUQAVAVAbAAQAdAAAUgVQAVgUAAgdQAAgbgVgVQgUgVgdAAQgbAAgVAVg");

	// hs
	this.instance_1 = new lib.g_hotspot_center("synched",0);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({startPosition:0},0).to({rotation:360},88).wait(1));

	// shadow
	this.instance_2 = new lib.hotspot_shadow();
	this.instance_2.setTransform(-11,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(90));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.4,-63.8,119.8,76.8);


(lib.m_CTA_meat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.g_cta_meat("synched",0);
	this.instance.setTransform(44,13,1,1,0,0,0,44,13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,88,26);


(lib.b_CTA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text
	this.cta_meat = new lib.m_CTA_meat();
	this.cta_meat.setTransform(44,13,1,1,0,0,0,44,13);

	this.timeline.addTween(cjs.Tween.get(this.cta_meat).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,88,26);


(lib.MoneyHotSpots = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// hotspot4
	this.hotspot4 = new lib.m_hotspot4();
	this.hotspot4.setTransform(341,219);

	this.timeline.addTween(cjs.Tween.get(this.hotspot4).wait(1));

	// hotspot3
	this.hotspot3 = new lib.m_hotspot3();
	this.hotspot3.setTransform(468,185);

	this.timeline.addTween(cjs.Tween.get(this.hotspot3).wait(1));

	// hotspot1
	this.hotspot1 = new lib.m_hotspot1();
	this.hotspot1.setTransform(90,75);

	this.timeline.addTween(cjs.Tween.get(this.hotspot1).wait(1));

	// hotspot2
	this.hotspot2 = new lib.m_hotspot2();
	this.hotspot2.setTransform(120,147);

	this.timeline.addTween(cjs.Tween.get(this.hotspot2).wait(1));

	// money_big.jpg
	this.instance = new lib.money();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// BigMoney 
	this.instance_1 = new lib.BigMoney();
	this.instance_1.setTransform(53,23.3,0.423,0.423);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,582,282);


// stage content:
(lib.Cloud_TemenosInteractive_US_970x250_RM_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _currentSection;
		var _prevSection;
		var _inSection = null; // set this when in a section, goal is to keep the magnfier from popping up
		var _moneyHotSpots = this.moneyHotSpots;
		var _headline = this.headline;
		var _CTA = this.CTA;
		var _CTAy = _CTA.y;
		var _BkgExit = this.bkgExit;
		
		var _hotspot1 = this.moneyHotSpots.hotspot1;
		var _hotspot2 = this.moneyHotSpots.hotspot2;
		var _hotspot3 = this.moneyHotSpots.hotspot3;
		var _hotspot4 = this.moneyHotSpots.hotspot4;
		var Ease = createjs.Ease; // define the easings
		
		 
		/* FT hook for collapsed 
		myFT.on('collapseEvent', function(){ // reset on collapse. but only if we are in a section
		    //console.log('collapseEvent');
			if (_root._currentSection != null) buttonHomeHandler();
		});*/
		
		var initSections = function() {
			//hotspots
			_CTA.addEventListener("click", exitHandler);
			_CTA.addEventListener("mouseover", ctaOverHandler);
			_CTA.addEventListener("mouseout", ctaOutHandler);
			_BkgExit.addEventListener("click", bkgExitHandler);
			
			for (var hsNumber = 1; hsNumber <=4; hsNumber++) {
				
				var currentHS = eval("_hotspot" + hsNumber);
				
				currentHS.addEventListener("click", hotSpotClickHandler.bind(this, hsNumber));
				// activate each of the 4 sections
			}
		}
		
		function exitHandler(event) {
			// exit goes here
			myFT.clickTag(0);
			handleTracking("CTA2");
		}
		function bkgExitHandler(event) {
			// exit goes here
			myFT.clickTag(1);
		}
		function ctaOverHandler(event) {
			createjs.Tween.get(_CTA, {override:true}).to({y:(_CTAy-5)}, 500, Ease.circOut);
		}
		function ctaOutHandler(event) {
			createjs.Tween.get(_CTA, {override:true}).to({y:_CTAy}, 500, Ease.circOut);
		}
		
		/* HotSpot spin animations // these just spin all the time now
		function animateButton(spinner) {
			spinner.gotoAndPlay("spin");
		}
		function stopAnimateButton(spinner) {
			spinner.stop();
		}*/
		
		// HotSpot Click Handlers
		function hotSpotClickHandler(sectionNumber) {
			//console.log("hsClickHandler:" + sectionNumber);
			//var currentSection = eval("_section" + sectionNumber);
			//createjs.Tween.get(_headline).to({alpha:.3}, 1200, Ease.circOut); //fade out headline
			//_root._currentSection = currentSection;
			//createjs.Tween.get(_root._currentSection).to({alpha:1}, 0, Ease.circOut).call(handleSectionComplete);
			//if (_root._currentSection == _section3) _root._currentSection.gotoAndPlay("animate");
			//endDrag();	
			//myFT.dispatch('autoCollapseEnd'); //Clicking hotspot dispatchs function in base file to cancel banner collapse.
			
			var trackingItem = "hotspot" + sectionNumber;
			handleTracking(trackingItem);
			window.parent.addChildRichLoad(sectionNumber);
		}
		
		// Section Nav Handlers
		function buttonHomeHandler() {
			//console.log("home!");
			createjs.Tween.get(_headline).to({alpha:1}, 1200, Ease.circOut); //headline fade
			//createjs.Tween.get(_root._currentSection).to({alpha:0}, 0, Ease.circOut).call(handleHomeComplete);
			
			var trackingItem;
			switch (_root._currentSection) {
				case _section1: trackingItem = "hotspot1-navback";
					break;
				case _section2: trackingItem = "hotspot2-navback";
					break;
				case _section3: trackingItem = "hotspot3-navback";
					break;
				case _section4: trackingItem = "hotspot4-navback";
					break;
				default: return;
			}
			handleTracking(trackingItem);
		}
		function handleHomeComplete() {
			_root._inSection = false;
			//_root._currentSection.gotoAndStop(0);
			_root._currentSection = null;
		}
		
		
		//Tracking bits
		function handleTracking(trackingItem) {
			console.log("handleTracking("+trackingItem+")");
			myFT.tracker(trackingItem, trackingItem);
		}
		// end tracking
		initSections();
		var _root = this;
		var _bigMoney = new lib.BigMoney();
		_root.pos = null;
		_root.endListener = null;
		_root.moveListener = null;
		_root.MoneyHotSpots = this.moneyHotSpots;
		_root.MagnifyLense = this.magnifyLense;
		_root.Instruct = this.instruct_mc;
		var Ease = createjs.Ease; // define the easings
		
		
		var bmp, magnifier,
		            bitmapFill,
		            scale = 0.61, radius = 80, 
					_initialView = false;
		
		handleComplete(null);
		
		function handleComplete(event) {
			
				image = img.BigMoney;
				bmp = _bigMoney.set({scaleX: scale, scaleY: scale});
				
				bmp.x = 190; //these deterime the placement of the zoom image
				bmp.y = -20;
				
		        magnifier = new createjs.Shape().set({x:-200,y:-200}); // start position of the magnify glass
				//magnifier.shadow = new createjs.Shadow("#000", 0,0,10);
				magnifier.mouseChildren = false;
		        createMagnifier(null, true);
		
		        _root.holder.addChild(magnifier); //bmp,  
		
		       
				_root.addEventListener("tick", tick);
		        //stage.on("stagemousedown", startDrag);
				initMagnify();
				_root.MoneyHotSpots.addEventListener("mousemove", smallBillInteract);
				_root.MoneyHotSpots.addEventListener("rollover", smallBillInteract);
				_root.MoneyHotSpots.addEventListener("rollout", smallBillOut);
		}
		
		function initMagnify() {
			// start the magnifier out over the 10M section of the bill
			_initialView = true;
			var pOut = new createjs.Point(_root.MagnifyLense.x, _root.MagnifyLense.y); //move the magnifier to 'off' position
				_root.pos = pOut;  
				 magnifier.set(pOut);
				_root.MagnifyLense.set(pOut);
			
				tick(stage);
				stage.update();
		}
			
		function smallBillInteract(event) {
			if (_root.Instruct.alpha != 0) createjs.Tween.get(_root.Instruct).wait(2000).to({alpha:0}, 1200, Ease.circOut); //headline fade
				//console.log("smallBillInteract");
				startDrag(event);
		}
		function smallBillOut(event) {
			endDrag();
		}
		
		var magnifyOffset = 25; // move the magnfify off the mouse slightly for better readability
		// Drag interactions (mainly to support mobile)
		function startDrag(event) {
			
			if (_root._inSection == true) return; //don't allow for zoom if we are in a section
		       
		        _root.moveListener = stage.on("stagemousemove", doDrag);
		        _root.pos = new createjs.Point(event.stageX, event.stageY -magnifyOffset);
		}
		function doDrag(event) {
		        _root.pos.setValues(event.stageX, event.stageY-magnifyOffset);
		}
		function endDrag() {
		        stage.off("stagemousemove", _root.moveListener);
		        stage.off("stagemousemove", _root.endListener);
		        _root.moveListener = _root.endListener = _root.pos = null;
				var pOut = new createjs.Point(-100, -100); //move the magnifier to 'off' position
				_root.pos = pOut;  
				 magnifier.set(pOut);
				_root.MagnifyLense.set(pOut);
		}
		
		// Only update the actual content on tick
		function tick(event) {
		        // Position the magnifier at the mouse's stage position.
		        var p = _root.pos || new createjs.Point(_root.mouseX, _root.mouseY);
				if (_initialView) {
					_initialView = false;
				} else if (p.x == magnifier.x && p.y == magnifier.y) { 
					return; 
				}
		        magnifier.set(p);
				_root.MagnifyLense.set(p);
		
		        var newScale = 1;
		        
		        var mx = new createjs.Matrix2D();
		        mx.translate((-p.x + bmp.x)/scale*newScale, (-p.y + bmp.y)/scale*newScale);
		        mx.scale(newScale,newScale);
		        bitmapFill.matrix = mx;
		
		        stage.update();
		}
		
		// Create different magnifier shapes
		    function createMagnifier(type, update) {
		        if (type == null) { type = "circle"; }
		        var g = magnifier.graphics.clear().f("#d4d4c8");
		
		        var r = radius;
		        switch (type) {
		            case "circle":
		                g.dc(0,0,r/2);
		                bitmapFill = g.bf(image, "no-repeat").command;
		                g.dc(0,0,r/2);
		                break;
		
		            default: return;
		        }
		
		        // When changed on mobile, a refresh is required
		        if (update != false) {
		            magnifier.x = magnifier.y = 0;
		            tick();
		        }
		    }
			//***** End Magnify Elements ****/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// CTA
	this.CTA = new lib.b_CTA();
	this.CTA.setTransform(911,220,1,1,0,0,0,44,13);
	new cjs.ButtonHelper(this.CTA, 0, 1, 2, false, new lib.b_CTA(), 3);

	this.timeline.addTween(cjs.Tween.get(this.CTA).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EhLsgTcMCXZAAAMAAAAm5MiXZAAAg");
	this.shape.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// instruct
	this.instruct_mc = new lib.g_clickHover();
	this.instruct_mc.setTransform(502,53.5,1,1,0,0,0,41,19.5);

	this.timeline.addTween(cjs.Tween.get(this.instruct_mc).wait(1));

	// magnify lense
	this.magnifyLense = new lib.m_magnfiyGlass();
	this.magnifyLense.setTransform(306,62);

	this.timeline.addTween(cjs.Tween.get(this.magnifyLense).wait(1));

	// lense holder
	this.holder = new lib.m_blank();

	this.timeline.addTween(cjs.Tween.get(this.holder).wait(1));

	// dollar with spots
	this.moneyHotSpots = new lib.MoneyHotSpots();
	this.moneyHotSpots.setTransform(194,-16);

	this.timeline.addTween(cjs.Tween.get(this.moneyHotSpots).wait(1));

	// bkg exit
	this.bkgExit = new lib.b_blank();
	this.bkgExit.setTransform(475,151.5,36.611,13.796);
	new cjs.ButtonHelper(this.bkgExit, 0, 1, 2, false, new lib.b_blank(), 3);

	this.timeline.addTween(cjs.Tween.get(this.bkgExit).wait(1));

	// headline
	this.headline = new lib.m_headline();
	this.headline.setTransform(488,-30);

	this.timeline.addTween(cjs.Tween.get(this.headline).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(266.9,20.5,1432.6,515.6);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;